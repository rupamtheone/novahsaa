import React, { useState } from 'react';
import { useAuth } from '../hooks/useAuth';

interface TaskCardProps {
  task: any;
  onUpdate: (taskData: any) => void;
  onDelete: (id: string) => void;
  projects: any[];
}

const TaskCard: React.FC<TaskCardProps> = ({ task, onUpdate, onDelete, projects }) => {
  const { user } = useAuth();
  const [showDetails, setShowDetails] = useState(false);
  const [isEditing, setIsEditing] = useState(false);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'in_progress': return 'bg-blue-100 text-blue-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'bg-red-100 text-red-800';
      case 'high': return 'bg-orange-100 text-orange-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const handleStatusChange = (newStatus: string) => {
    onUpdate({ id: task.id, status: newStatus });
  };

  const handleQuickEdit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    onUpdate({
      id: task.id,
      title: formData.get('title'),
      description: formData.get('description'),
      priority: formData.get('priority'),
      dueDate: formData.get('dueDate') || null,
    });
    setIsEditing(false);
  };

  const project = projects.find(p => p.id === task.projectId);

  return (
    <div className="bg-white border rounded-lg p-4 hover:shadow-md transition-shadow">
      {/* Task Header */}
      <div className="flex items-start justify-between mb-3">
        <div className="flex-1">
          {isEditing ? (
            <form onSubmit={handleQuickEdit} className="space-y-3">
              <input
                name="title"
                defaultValue={task.title}
                className="w-full text-sm font-medium border rounded px-2 py-1"
                required
              />
              <textarea
                name="description"
                defaultValue={task.description || ''}
                className="w-full text-xs border rounded px-2 py-1"
                rows={2}
              />
              <div className="grid grid-cols-2 gap-2">
                <select
                  name="priority"
                  defaultValue={task.priority}
                  className="text-xs border rounded px-2 py-1"
                >
                  <option value="low">Low</option>
                  <option value="medium">Medium</option>
                  <option value="high">High</option>
                  <option value="urgent">Urgent</option>
                </select>
                <input
                  name="dueDate"
                  type="date"
                  defaultValue={task.dueDate ? task.dueDate.split('T')[0] : ''}
                  className="text-xs border rounded px-2 py-1"
                />
              </div>
              <div className="flex space-x-2">
                <button
                  type="submit"
                  className="bg-blue-600 text-white px-3 py-1 rounded text-xs hover:bg-blue-700"
                >
                  Save
                </button>
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="bg-gray-300 text-gray-700 px-3 py-1 rounded text-xs hover:bg-gray-400"
                >
                  Cancel
                </button>
              </div>
            </form>
          ) : (
            <>
              <h3 
                className="font-medium text-gray-900 text-sm mb-1 cursor-pointer hover:text-blue-600"
                onClick={() => setShowDetails(!showDetails)}
              >
                {task.title}
              </h3>
              {task.description && (
                <p className="text-xs text-gray-600 mb-2 line-clamp-2">
                  {task.description}
                </p>
              )}
            </>
          )}
        </div>

        {!isEditing && (
          <div className="flex items-center space-x-1 ml-2">
            <button
              onClick={() => setIsEditing(true)}
              className="text-gray-400 hover:text-gray-600 text-xs"
            >
              ✏️
            </button>
            <button
              onClick={() => onDelete(task.id)}
              className="text-gray-400 hover:text-red-600 text-xs"
            >
              🗑️
            </button>
          </div>
        )}
      </div>

      {/* Task Tags */}
      {!isEditing && (
        <div className="flex items-center flex-wrap gap-1 mb-3">
          <span className={`px-2 py-1 text-xs rounded-full ${getStatusColor(task.status)}`}>
            {task.status?.replace('_', ' ')}
          </span>
          <span className={`px-2 py-1 text-xs rounded-full ${getPriorityColor(task.priority)}`}>
            {task.priority}
          </span>
          {project && (
            <span className="px-2 py-1 text-xs rounded-full bg-purple-100 text-purple-800">
              {project.name}
            </span>
          )}
        </div>
      )}

      {/* Due Date */}
      {!isEditing && task.dueDate && (
        <div className="text-xs text-gray-500 mb-3">
          Due: {new Date(task.dueDate).toLocaleDateString()}
        </div>
      )}

      {/* Status Actions */}
      {!isEditing && (
        <div className="flex space-x-1">
          {task.status === 'pending' && (
            <button
              onClick={() => handleStatusChange('in_progress')}
              className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs hover:bg-blue-200"
            >
              Start
            </button>
          )}
          {task.status === 'in_progress' && (
            <button
              onClick={() => handleStatusChange('completed')}
              className="bg-green-100 text-green-800 px-2 py-1 rounded text-xs hover:bg-green-200"
            >
              Complete
            </button>
          )}
          {task.status === 'completed' && (
            <button
              onClick={() => handleStatusChange('in_progress')}
              className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded text-xs hover:bg-yellow-200"
            >
              Reopen
            </button>
          )}
        </div>
      )}

      {/* Expanded Details */}
      {showDetails && !isEditing && (
        <div className="mt-4 pt-3 border-t border-gray-100">
          <div className="space-y-2 text-xs text-gray-600">
            <div>
              <span className="font-medium">Created:</span> {new Date(task.createdAt).toLocaleString()}
            </div>
            {task.updatedAt !== task.createdAt && (
              <div>
                <span className="font-medium">Updated:</span> {new Date(task.updatedAt).toLocaleString()}
              </div>
            )}
            {task.assignedTo && (
              <div>
                <span className="font-medium">Assigned to:</span> {task.assignedTo}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default TaskCard;

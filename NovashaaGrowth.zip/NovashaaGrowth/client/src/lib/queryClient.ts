import axios from 'axios';

export const apiRequest = async (url: string, options: any = {}) => {
  try {
    const response = await axios({
      url,
      ...options,
    });
    return response.data;
  } catch (error: any) {
    if (error.response?.status === 401) {
      throw new Error(`401: ${error.response.data?.message || 'Unauthorized'}`);
    }
    throw new Error(error.response?.data?.message || error.message || 'Request failed');
  }
};

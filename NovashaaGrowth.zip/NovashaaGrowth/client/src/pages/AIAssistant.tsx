import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '../lib/queryClient';
import { useAuth } from '../hooks/useAuth';
import { useToast } from '../hooks/use-toast';
import { isUnauthorizedError } from '../lib/authUtils';
import { 
  Brain, 
  Sparkles, 
  MessageSquare, 
  Hash, 
  FileText, 
  TrendingUp,
  Lightbulb,
  Star,
  ThumbsUp,
  ThumbsDown,
  Copy,
  Download,
  BarChart3
} from 'lucide-react';

interface AiSuggestion {
  id: string;
  type: string;
  prompt: string;
  suggestion: string;
  platform: string;
  rating?: number;
  isUsed: boolean;
  createdAt: string;
}

const AIAssistant: React.FC = () => {
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [selectedType, setSelectedType] = useState('caption');
  const [prompt, setPrompt] = useState('');
  const [selectedPlatform, setPlatform] = useState('instagram');
  const [activeTab, setActiveTab] = useState('generate');

  // Fetch AI suggestions
  const { data: suggestions = [], isLoading } = useQuery<AiSuggestion[]>({
    queryKey: ['/api/ai-suggestions'],
    queryFn: async () => {
      try {
        return await apiRequest('/api/ai-suggestions');
      } catch (error: any) {
        if (isUnauthorizedError(error)) {
          toast({
            title: "Unauthorized",
            description: "You are logged out. Logging in again...",
            variant: "destructive",
          });
          setTimeout(() => {
            window.location.href = "/api/login";
          }, 500);
        }
        throw error;
      }
    },
  });

  // Generate AI suggestion mutation
  const generateSuggestion = useMutation({
    mutationFn: async (data: { type: string; prompt: string; platform: string }) => {
      return await apiRequest('/api/ai-suggestions/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/ai-suggestions'] });
      setPrompt('');
      toast({
        title: "AI Suggestion Generated!",
        description: "Your content suggestion is ready.",
      });
    },
    onError: (error: any) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to generate AI suggestion.",
        variant: "destructive",
      });
    },
  });

  // Rate suggestion mutation
  const rateSuggestion = useMutation({
    mutationFn: async ({ id, rating, isUsed }: { id: string; rating: number; isUsed?: boolean }) => {
      return await apiRequest(`/api/ai-suggestions/${id}/rate`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rating, isUsed }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/ai-suggestions'] });
    },
  });

  const handleGenerate = () => {
    if (!prompt.trim()) {
      toast({
        title: "Error",
        description: "Please enter a prompt for AI generation.",
        variant: "destructive",
      });
      return;
    }

    generateSuggestion.mutate({
      type: selectedType,
      prompt: prompt.trim(),
      platform: selectedPlatform,
    });
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied!",
      description: "Content copied to clipboard.",
    });
  };

  const handleRating = (id: string, rating: number) => {
    rateSuggestion.mutate({ id, rating });
  };

  const handleUse = (id: string) => {
    rateSuggestion.mutate({ id, rating: 5, isUsed: true });
    toast({
      title: "Content Marked as Used!",
      description: "This suggestion has been marked as used.",
    });
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Please log in to access AI Assistant</h1>
          <button 
            onClick={() => window.location.href = '/api/login'}
            className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700"
          >
            Log In
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <Brain className="h-8 w-8 text-purple-600" />
            <h1 className="text-3xl font-bold text-gray-900">AI Business Assistant</h1>
          </div>
          <p className="text-gray-600">
            Generate smart content suggestions, captions, hashtags, and business insights powered by AI.
          </p>
        </div>

        {/* Navigation Tabs */}
        <div className="flex space-x-1 bg-gray-100 rounded-lg p-1 mb-8">
          <button
            onClick={() => setActiveTab('generate')}
            className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
              activeTab === 'generate'
                ? 'bg-white text-purple-600 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Sparkles className="h-4 w-4 inline mr-2" />
            Generate Content
          </button>
          <button
            onClick={() => setActiveTab('suggestions')}
            className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
              activeTab === 'suggestions'
                ? 'bg-white text-purple-600 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Lightbulb className="h-4 w-4 inline mr-2" />
            Suggestions Library
          </button>
          <button
            onClick={() => setActiveTab('analytics')}
            className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
              activeTab === 'analytics'
                ? 'bg-white text-purple-600 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <BarChart3 className="h-4 w-4 inline mr-2" />
            AI Insights
          </button>
        </div>

        {/* Content Generation Tab */}
        {activeTab === 'generate' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Generation Form */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-xl font-semibold mb-6 flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-purple-600" />
                Generate AI Content
              </h2>
              
              {/* Content Type Selection */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  Content Type
                </label>
                <div className="grid grid-cols-3 gap-3">
                  <button
                    onClick={() => setSelectedType('caption')}
                    className={`p-3 rounded-lg border text-center transition-colors ${
                      selectedType === 'caption'
                        ? 'border-purple-500 bg-purple-50 text-purple-700'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <MessageSquare className="h-6 w-6 mx-auto mb-1" />
                    <span className="text-sm font-medium">Caption</span>
                  </button>
                  <button
                    onClick={() => setSelectedType('hashtag')}
                    className={`p-3 rounded-lg border text-center transition-colors ${
                      selectedType === 'hashtag'
                        ? 'border-purple-500 bg-purple-50 text-purple-700'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <Hash className="h-6 w-6 mx-auto mb-1" />
                    <span className="text-sm font-medium">Hashtags</span>
                  </button>
                  <button
                    onClick={() => setSelectedType('content')}
                    className={`p-3 rounded-lg border text-center transition-colors ${
                      selectedType === 'content'
                        ? 'border-purple-500 bg-purple-50 text-purple-700'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <FileText className="h-6 w-6 mx-auto mb-1" />
                    <span className="text-sm font-medium">Content Ideas</span>
                  </button>
                </div>
              </div>

              {/* Platform Selection */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  Platform
                </label>
                <select
                  value={selectedPlatform}
                  onChange={(e) => setPlatform(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                >
                  <option value="instagram">Instagram</option>
                  <option value="facebook">Facebook</option>
                  <option value="linkedin">LinkedIn</option>
                  <option value="twitter">Twitter</option>
                  <option value="tiktok">TikTok</option>
                </select>
              </div>

              {/* Prompt Input */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  Describe your content idea
                </label>
                <textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="e.g., Product launch announcement for our new app feature..."
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 h-24 focus:ring-2 focus:ring-purple-500 focus:border-transparent resize-none"
                />
              </div>

              {/* Generate Button */}
              <button
                onClick={handleGenerate}
                disabled={generateSuggestion.isPending || !prompt.trim()}
                className="w-full bg-purple-600 text-white py-3 px-4 rounded-lg hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {generateSuggestion.isPending ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                    Generating...
                  </>
                ) : (
                  <>
                    <Sparkles className="h-4 w-4" />
                    Generate AI Content
                  </>
                )}
              </button>
            </div>

            {/* Recent Suggestions Preview */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-xl font-semibold mb-6 flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-green-600" />
                Recent Suggestions
              </h2>
              
              {isLoading ? (
                <div className="space-y-4">
                  {[...Array(3)].map((_, i) => (
                    <div key={i} className="animate-pulse">
                      <div className="h-4 bg-gray-200 rounded w-1/4 mb-2"></div>
                      <div className="h-12 bg-gray-200 rounded"></div>
                    </div>
                  ))}
                </div>
              ) : suggestions.length === 0 ? (
                <div className="text-center py-8">
                  <Lightbulb className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500">Generate your first AI suggestion to get started!</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {suggestions.slice(0, 3).map((suggestion) => (
                    <div key={suggestion.id} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="text-xs bg-purple-100 text-purple-700 px-2 py-1 rounded-full">
                          {suggestion.type}
                        </span>
                        <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded-full">
                          {suggestion.platform}
                        </span>
                      </div>
                      <p className="text-sm text-gray-700 mb-3">{suggestion.suggestion}</p>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => copyToClipboard(suggestion.suggestion)}
                            className="text-xs text-gray-600 hover:text-gray-800 flex items-center gap-1"
                          >
                            <Copy className="h-3 w-3" />
                            Copy
                          </button>
                        </div>
                        <div className="flex items-center gap-1">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <button
                              key={star}
                              onClick={() => handleRating(suggestion.id, star)}
                              className={`h-4 w-4 ${
                                suggestion.rating && star <= suggestion.rating
                                  ? 'text-yellow-400'
                                  : 'text-gray-300'
                              }`}
                            >
                              <Star className="h-full w-full fill-current" />
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Suggestions Library Tab */}
        {activeTab === 'suggestions' && (
          <div className="bg-white rounded-lg shadow-sm">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-xl font-semibold flex items-center gap-2">
                <Lightbulb className="h-5 w-5 text-yellow-600" />
                Suggestions Library
              </h2>
              <p className="text-gray-600 mt-1">All your AI-generated content suggestions</p>
            </div>
            
            <div className="p-6">
              {isLoading ? (
                <div className="space-y-4">
                  {[...Array(5)].map((_, i) => (
                    <div key={i} className="animate-pulse border border-gray-200 rounded-lg p-4">
                      <div className="flex gap-4 mb-3">
                        <div className="h-4 bg-gray-200 rounded w-16"></div>
                        <div className="h-4 bg-gray-200 rounded w-20"></div>
                      </div>
                      <div className="h-16 bg-gray-200 rounded mb-3"></div>
                      <div className="h-4 bg-gray-200 rounded w-1/3"></div>
                    </div>
                  ))}
                </div>
              ) : suggestions.length === 0 ? (
                <div className="text-center py-12">
                  <Brain className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No suggestions yet</h3>
                  <p className="text-gray-500 mb-6">Generate your first AI suggestion to get started!</p>
                  <button
                    onClick={() => setActiveTab('generate')}
                    className="bg-purple-600 text-white px-6 py-2 rounded-lg hover:bg-purple-700"
                  >
                    Generate Content
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  {suggestions.map((suggestion) => (
                    <div key={suggestion.id} className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-center gap-2">
                          <span className="text-sm bg-purple-100 text-purple-700 px-3 py-1 rounded-full font-medium">
                            {suggestion.type}
                          </span>
                          <span className="text-sm bg-blue-100 text-blue-700 px-3 py-1 rounded-full font-medium">
                            {suggestion.platform}
                          </span>
                          {suggestion.isUsed && (
                            <span className="text-sm bg-green-100 text-green-700 px-3 py-1 rounded-full font-medium">
                              Used
                            </span>
                          )}
                        </div>
                        <span className="text-sm text-gray-500">
                          {new Date(suggestion.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                      
                      <div className="mb-4">
                        <p className="text-sm text-gray-600 mb-2">
                          <strong>Prompt:</strong> {suggestion.prompt}
                        </p>
                        <div className="bg-gray-50 rounded-lg p-4">
                          <p className="text-gray-800">{suggestion.suggestion}</p>
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <button
                            onClick={() => copyToClipboard(suggestion.suggestion)}
                            className="flex items-center gap-2 text-sm text-gray-600 hover:text-gray-800 px-3 py-1 rounded border hover:bg-gray-50"
                          >
                            <Copy className="h-4 w-4" />
                            Copy
                          </button>
                          {!suggestion.isUsed && (
                            <button
                              onClick={() => handleUse(suggestion.id)}
                              className="flex items-center gap-2 text-sm text-green-600 hover:text-green-800 px-3 py-1 rounded border border-green-200 hover:bg-green-50"
                            >
                              <ThumbsUp className="h-4 w-4" />
                              Mark as Used
                            </button>
                          )}
                        </div>
                        
                        <div className="flex items-center gap-1">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <button
                              key={star}
                              onClick={() => handleRating(suggestion.id, star)}
                              className={`h-5 w-5 ${
                                suggestion.rating && star <= suggestion.rating
                                  ? 'text-yellow-400'
                                  : 'text-gray-300'
                              } hover:text-yellow-500`}
                            >
                              <Star className="h-full w-full fill-current" />
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* AI Insights Tab */}
        {activeTab === 'analytics' && (
          <div className="bg-white rounded-lg shadow-sm">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-xl font-semibold flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-blue-600" />
                AI Content Insights
              </h2>
              <p className="text-gray-600 mt-1">Analytics and insights about your AI-generated content</p>
            </div>
            
            <div className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div className="bg-gradient-to-r from-purple-500 to-purple-600 rounded-lg p-6 text-white">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-purple-100">Total Suggestions</p>
                      <p className="text-3xl font-bold">{suggestions.length}</p>
                    </div>
                    <Sparkles className="h-12 w-12 text-purple-200" />
                  </div>
                </div>
                
                <div className="bg-gradient-to-r from-green-500 to-green-600 rounded-lg p-6 text-white">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-green-100">Used Content</p>
                      <p className="text-3xl font-bold">{suggestions.filter(s => s.isUsed).length}</p>
                    </div>
                    <ThumbsUp className="h-12 w-12 text-green-200" />
                  </div>
                </div>
                
                <div className="bg-gradient-to-r from-blue-500 to-blue-600 rounded-lg p-6 text-white">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-blue-100">Avg Rating</p>
                      <p className="text-3xl font-bold">
                        {suggestions.filter(s => s.rating).length > 0 
                          ? (suggestions.filter(s => s.rating).reduce((acc, s) => acc + (s.rating || 0), 0) / suggestions.filter(s => s.rating).length).toFixed(1)
                          : '0.0'
                        }
                      </p>
                    </div>
                    <Star className="h-12 w-12 text-blue-200" />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="border border-gray-200 rounded-lg p-6">
                  <h3 className="text-lg font-semibold mb-4">Content Type Breakdown</h3>
                  <div className="space-y-3">
                    {['caption', 'hashtag', 'content'].map((type) => {
                      const count = suggestions.filter(s => s.type === type).length;
                      const percentage = suggestions.length > 0 ? (count / suggestions.length) * 100 : 0;
                      return (
                        <div key={type} className="flex items-center justify-between">
                          <span className="capitalize text-gray-700">{type}</span>
                          <div className="flex items-center gap-3">
                            <div className="w-24 bg-gray-200 rounded-full h-2">
                              <div 
                                className="bg-purple-600 h-2 rounded-full" 
                                style={{ width: `${percentage}%` }}
                              ></div>
                            </div>
                            <span className="text-sm text-gray-600 w-12">{count}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="border border-gray-200 rounded-lg p-6">
                  <h3 className="text-lg font-semibold mb-4">Platform Distribution</h3>
                  <div className="space-y-3">
                    {['instagram', 'facebook', 'linkedin', 'twitter', 'tiktok'].map((platform) => {
                      const count = suggestions.filter(s => s.platform === platform).length;
                      const percentage = suggestions.length > 0 ? (count / suggestions.length) * 100 : 0;
                      return (
                        <div key={platform} className="flex items-center justify-between">
                          <span className="capitalize text-gray-700">{platform}</span>
                          <div className="flex items-center gap-3">
                            <div className="w-24 bg-gray-200 rounded-full h-2">
                              <div 
                                className="bg-blue-600 h-2 rounded-full" 
                                style={{ width: `${percentage}%` }}
                              ></div>
                            </div>
                            <span className="text-sm text-gray-600 w-12">{count}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AIAssistant;
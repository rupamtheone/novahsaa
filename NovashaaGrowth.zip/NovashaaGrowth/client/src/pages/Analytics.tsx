import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '../lib/queryClient';
import { useAuth } from '../hooks/useAuth';
import { useToast } from '../hooks/use-toast';
import { isUnauthorizedError } from '../lib/authUtils';
import { 
  BarChart3,
  TrendingUp,
  TrendingDown,
  DollarSign,
  Users,
  Target,
  Calendar,
  Download,
  Filter,
  Eye,
  Share2,
  MessageCircle,
  BookOpen,
  Trophy,
  ArrowUpRight,
  ArrowDownRight,
  PieChart,
  LineChart,
  Activity,
  Clock,
  Zap,
  Star,
  FileText,
  Globe,
  CheckCircle
} from 'lucide-react';

interface AnalyticsData {
  overview: {
    totalProjects: number;
    activeCampaigns: number;
    totalTasks: number;
    completedTasks: number;
    socialMediaPosts: number;
    workshopsAttended: number;
    networkingConnections: number;
    achievementsUnlocked: number;
  };
  performance: {
    projectsCompleted: number;
    taskCompletionRate: number;
    campaignROI: number;
    socialEngagement: number;
    learningProgress: number;
    networkingScore: number;
  };
  trends: {
    daily: Array<{ date: string; tasks: number; campaigns: number; social: number }>;
    weekly: Array<{ week: string; productivity: number; engagement: number }>;
    monthly: Array<{ month: string; growth: number; revenue: number }>;
  };
  socialMedia: {
    platforms: Array<{ platform: string; posts: number; engagement: number; reach: number }>;
    topPerforming: Array<{ title: string; platform: string; engagement: number; date: string }>;
  };
  campaigns: {
    active: number;
    completed: number;
    totalBudget: number;
    totalSpent: number;
    avgROI: number;
    topPerforming: Array<{ name: string; roi: number; status: string }>;
  };
}

const Analytics: React.FC = () => {
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  
  const [selectedPeriod, setSelectedPeriod] = useState('30d');
  const [selectedMetric, setSelectedMetric] = useState('overview');

  // Fetch analytics data
  const { data: analytics, isLoading: loadingAnalytics } = useQuery<AnalyticsData>({
    queryKey: ['/api/analytics', selectedPeriod],
    queryFn: async () => {
      try {
        return await apiRequest(`/api/analytics?period=${selectedPeriod}`);
      } catch (error: any) {
        if (isUnauthorizedError(error)) {
          toast({
            title: "Unauthorized",
            description: "You are logged out. Logging in again...",
            variant: "destructive",
          });
          setTimeout(() => {
            window.location.href = "/api/login";
          }, 500);
        }
        throw error;
      }
    },
  });

  const periods = [
    { value: '7d', label: 'Last 7 days' },
    { value: '30d', label: 'Last 30 days' },
    { value: '90d', label: 'Last 3 months' },
    { value: '1y', label: 'Last year' },
  ];

  const metrics = [
    { id: 'overview', label: 'Overview', icon: <BarChart3 className="h-4 w-4" /> },
    { id: 'projects', label: 'Projects', icon: <Target className="h-4 w-4" /> },
    { id: 'social', label: 'Social Media', icon: <Share2 className="h-4 w-4" /> },
    { id: 'campaigns', label: 'Campaigns', icon: <TrendingUp className="h-4 w-4" /> },
    { id: 'learning', label: 'Learning', icon: <BookOpen className="h-4 w-4" /> },
    { id: 'networking', label: 'Networking', icon: <Users className="h-4 w-4" /> },
  ];

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  const formatPercentage = (value: number) => {
    return `${value.toFixed(1)}%`;
  };

  const getTrendIcon = (value: number, isReverse = false) => {
    const isPositive = isReverse ? value < 0 : value > 0;
    return isPositive ? (
      <ArrowUpRight className="h-4 w-4 text-green-600" />
    ) : (
      <ArrowDownRight className="h-4 w-4 text-red-600" />
    );
  };

  const getTrendColor = (value: number, isReverse = false) => {
    const isPositive = isReverse ? value < 0 : value > 0;
    return isPositive ? 'text-green-600' : 'text-red-600';
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Please log in to access Analytics</h1>
          <button 
            onClick={() => window.location.href = '/api/login'}
            className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700"
          >
            Log In
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <BarChart3 className="h-8 w-8 text-blue-600" />
                <h1 className="text-3xl font-bold text-gray-900">Analytics Dashboard</h1>
              </div>
              <p className="text-gray-600">
                Comprehensive insights into your business growth and platform usage.
              </p>
            </div>
            <div className="flex gap-3">
              <select
                value={selectedPeriod}
                onChange={(e) => setSelectedPeriod(e.target.value)}
                className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                {periods.map(period => (
                  <option key={period.value} value={period.value}>{period.label}</option>
                ))}
              </select>
              <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 flex items-center gap-2">
                <Download className="h-4 w-4" />
                Export Report
              </button>
            </div>
          </div>
        </div>

        {/* Metric Navigation */}
        <div className="flex flex-wrap gap-2 mb-8">
          {metrics.map((metric) => (
            <button
              key={metric.id}
              onClick={() => setSelectedMetric(metric.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                selectedMetric === metric.id
                  ? 'bg-blue-600 text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-50 border border-gray-300'
              }`}
            >
              {metric.icon}
              {metric.label}
            </button>
          ))}
        </div>

        {loadingAnalytics ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="bg-white rounded-lg shadow-sm p-6 animate-pulse">
                <div className="flex items-center justify-between mb-4">
                  <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                  <div className="h-8 w-8 bg-gray-200 rounded"></div>
                </div>
                <div className="h-8 bg-gray-200 rounded mb-2"></div>
                <div className="h-4 bg-gray-200 rounded w-1/3"></div>
              </div>
            ))}
          </div>
        ) : analytics ? (
          <>
            {/* Overview Metrics */}
            {selectedMetric === 'overview' && (
              <>
                {/* Key Performance Indicators */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                  <div className="bg-gradient-to-r from-blue-500 to-blue-600 rounded-lg p-6 text-white">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-blue-100">Total Projects</p>
                        <p className="text-3xl font-bold">{analytics.overview.totalProjects}</p>
                      </div>
                      <Target className="h-12 w-12 text-blue-200" />
                    </div>
                    <div className="flex items-center mt-4">
                      {getTrendIcon(12)}
                      <span className="ml-1 text-blue-100">+12% vs last period</span>
                    </div>
                  </div>
                  
                  <div className="bg-gradient-to-r from-green-500 to-green-600 rounded-lg p-6 text-white">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-green-100">Task Completion</p>
                        <p className="text-3xl font-bold">
                          {analytics.performance ? formatPercentage(analytics.performance.taskCompletionRate) : '0%'}
                        </p>
                      </div>
                      <TrendingUp className="h-12 w-12 text-green-200" />
                    </div>
                    <div className="flex items-center mt-4">
                      {getTrendIcon(8)}
                      <span className="ml-1 text-green-100">+8% vs last period</span>
                    </div>
                  </div>
                  
                  <div className="bg-gradient-to-r from-purple-500 to-purple-600 rounded-lg p-6 text-white">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-purple-100">Campaign ROI</p>
                        <p className="text-3xl font-bold">
                          {analytics.performance ? formatPercentage(analytics.performance.campaignROI) : '0%'}
                        </p>
                      </div>
                      <DollarSign className="h-12 w-12 text-purple-200" />
                    </div>
                    <div className="flex items-center mt-4">
                      {getTrendIcon(15)}
                      <span className="ml-1 text-purple-100">+15% vs last period</span>
                    </div>
                  </div>
                  
                  <div className="bg-gradient-to-r from-orange-500 to-orange-600 rounded-lg p-6 text-white">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-orange-100">Social Engagement</p>
                        <p className="text-3xl font-bold">
                          {analytics.performance ? formatPercentage(analytics.performance.socialEngagement) : '0%'}
                        </p>
                      </div>
                      <Activity className="h-12 w-12 text-orange-200" />
                    </div>
                    <div className="flex items-center mt-4">
                      {getTrendIcon(22)}
                      <span className="ml-1 text-orange-100">+22% vs last period</span>
                    </div>
                  </div>
                </div>

                {/* Activity Overview */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                  <div className="bg-white rounded-lg shadow-sm p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-semibold text-gray-900">Active Campaigns</h3>
                      <Target className="h-5 w-5 text-red-600" />
                    </div>
                    <div className="text-2xl font-bold text-gray-900 mb-2">
                      {analytics.overview.activeCampaigns}
                    </div>
                    <p className="text-gray-600 text-sm">Running campaigns</p>
                  </div>

                  <div className="bg-white rounded-lg shadow-sm p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-semibold text-gray-900">Social Posts</h3>
                      <Share2 className="h-5 w-5 text-blue-600" />
                    </div>
                    <div className="text-2xl font-bold text-gray-900 mb-2">
                      {analytics.overview.socialMediaPosts}
                    </div>
                    <p className="text-gray-600 text-sm">Published this period</p>
                  </div>

                  <div className="bg-white rounded-lg shadow-sm p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-semibold text-gray-900">Workshops</h3>
                      <BookOpen className="h-5 w-5 text-indigo-600" />
                    </div>
                    <div className="text-2xl font-bold text-gray-900 mb-2">
                      {analytics.overview.workshopsAttended}
                    </div>
                    <p className="text-gray-600 text-sm">Attended workshops</p>
                  </div>

                  <div className="bg-white rounded-lg shadow-sm p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-semibold text-gray-900">Achievements</h3>
                      <Trophy className="h-5 w-5 text-yellow-600" />
                    </div>
                    <div className="text-2xl font-bold text-gray-900 mb-2">
                      {analytics.overview.achievementsUnlocked}
                    </div>
                    <p className="text-gray-600 text-sm">Unlocked achievements</p>
                  </div>
                </div>

                {/* Performance Trends */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="bg-white rounded-lg shadow-sm p-6">
                    <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                      <LineChart className="h-5 w-5 text-blue-600" />
                      Daily Activity Trends
                    </h3>
                    <div className="h-64 flex items-center justify-center bg-gray-50 rounded-lg">
                      <div className="text-center">
                        <LineChart className="h-12 w-12 text-gray-400 mx-auto mb-3" />
                        <p className="text-gray-500">Activity trend chart will be displayed here</p>
                        <p className="text-gray-400 text-sm">Tasks, campaigns, and social media activity over time</p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white rounded-lg shadow-sm p-6">
                    <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                      <PieChart className="h-5 w-5 text-purple-600" />
                      Time Distribution
                    </h3>
                    <div className="h-64 flex items-center justify-center bg-gray-50 rounded-lg">
                      <div className="text-center">
                        <PieChart className="h-12 w-12 text-gray-400 mx-auto mb-3" />
                        <p className="text-gray-500">Time distribution chart will be displayed here</p>
                        <p className="text-gray-400 text-sm">How you spend time across different platform features</p>
                      </div>
                    </div>
                  </div>
                </div>
              </>
            )}

            {/* Social Media Analytics */}
            {selectedMetric === 'social' && analytics.socialMedia && (
              <>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                  {analytics.socialMedia.platforms.map((platform) => (
                    <div key={platform.platform} className="bg-white rounded-lg shadow-sm p-6">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="font-semibold text-gray-900 capitalize">{platform.platform}</h3>
                        <Share2 className="h-5 w-5 text-blue-600" />
                      </div>
                      <div className="space-y-3">
                        <div>
                          <div className="text-2xl font-bold text-gray-900">{platform.posts}</div>
                          <div className="text-gray-600 text-sm">Posts published</div>
                        </div>
                        <div>
                          <div className="text-lg font-semibold text-green-600">{formatPercentage(platform.engagement)}</div>
                          <div className="text-gray-600 text-sm">Engagement rate</div>
                        </div>
                        <div>
                          <div className="text-lg font-semibold text-blue-600">{platform.reach.toLocaleString()}</div>
                          <div className="text-gray-600 text-sm">Total reach</div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="bg-white rounded-lg shadow-sm p-6">
                  <h3 className="text-lg font-semibold mb-4">Top Performing Posts</h3>
                  {analytics.socialMedia.topPerforming.length === 0 ? (
                    <div className="text-center py-8">
                      <Star className="h-12 w-12 text-gray-400 mx-auto mb-3" />
                      <p className="text-gray-500">No social media posts to analyze yet.</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {analytics.socialMedia.topPerforming.map((post, index) => (
                        <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <div className="flex-1">
                            <h4 className="font-medium text-gray-900">{post.title}</h4>
                            <div className="flex items-center gap-4 text-sm text-gray-600">
                              <span className="capitalize">{post.platform}</span>
                              <span>{new Date(post.date).toLocaleDateString()}</span>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="font-semibold text-green-600">{formatPercentage(post.engagement)}</div>
                            <div className="text-gray-600 text-sm">engagement</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </>
            )}

            {/* Campaign Analytics */}
            {selectedMetric === 'campaigns' && analytics.campaigns && (
              <>
                <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-6 mb-8">
                  <div className="bg-white rounded-lg shadow-sm p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-semibold text-gray-900">Active</h3>
                      <Activity className="h-5 w-5 text-green-600" />
                    </div>
                    <div className="text-2xl font-bold text-gray-900">{analytics.campaigns.active}</div>
                  </div>

                  <div className="bg-white rounded-lg shadow-sm p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-semibold text-gray-900">Completed</h3>
                      <CheckCircle className="h-5 w-5 text-blue-600" />
                    </div>
                    <div className="text-2xl font-bold text-gray-900">{analytics.campaigns.completed}</div>
                  </div>

                  <div className="bg-white rounded-lg shadow-sm p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-semibold text-gray-900">Total Budget</h3>
                      <DollarSign className="h-5 w-5 text-purple-600" />
                    </div>
                    <div className="text-lg font-bold text-gray-900">{formatCurrency(analytics.campaigns.totalBudget)}</div>
                  </div>

                  <div className="bg-white rounded-lg shadow-sm p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-semibold text-gray-900">Total Spent</h3>
                      <TrendingDown className="h-5 w-5 text-red-600" />
                    </div>
                    <div className="text-lg font-bold text-gray-900">{formatCurrency(analytics.campaigns.totalSpent)}</div>
                  </div>

                  <div className="bg-white rounded-lg shadow-sm p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-semibold text-gray-900">Avg ROI</h3>
                      <TrendingUp className="h-5 w-5 text-yellow-600" />
                    </div>
                    <div className="text-lg font-bold text-green-600">{formatPercentage(analytics.campaigns.avgROI)}</div>
                  </div>
                </div>

                <div className="bg-white rounded-lg shadow-sm p-6">
                  <h3 className="text-lg font-semibold mb-4">Top Performing Campaigns</h3>
                  {analytics.campaigns.topPerforming.length === 0 ? (
                    <div className="text-center py-8">
                      <Target className="h-12 w-12 text-gray-400 mx-auto mb-3" />
                      <p className="text-gray-500">No campaigns to analyze yet.</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {analytics.campaigns.topPerforming.map((campaign, index) => (
                        <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <div className="flex-1">
                            <h4 className="font-medium text-gray-900">{campaign.name}</h4>
                            <span className={`text-xs px-2 py-1 rounded-full ${
                              campaign.status === 'active' ? 'bg-green-100 text-green-800' :
                              campaign.status === 'completed' ? 'bg-blue-100 text-blue-800' :
                              'bg-gray-100 text-gray-800'
                            }`}>
                              {campaign.status}
                            </span>
                          </div>
                          <div className="text-right">
                            <div className="font-semibold text-green-600">{formatPercentage(campaign.roi)}</div>
                            <div className="text-gray-600 text-sm">ROI</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </>
            )}

            {/* Other metric views would be similar */}
            {['projects', 'learning', 'networking'].includes(selectedMetric) && (
              <div className="bg-white rounded-lg shadow-sm p-12">
                <div className="text-center">
                  <BarChart3 className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">
                    {metrics.find(m => m.id === selectedMetric)?.label} Analytics
                  </h3>
                  <p className="text-gray-500">
                    Detailed analytics for {selectedMetric} will be displayed here with comprehensive metrics and insights.
                  </p>
                </div>
              </div>
            )}
          </>
        ) : (
          <div className="bg-white rounded-lg shadow-sm p-12">
            <div className="text-center">
              <BarChart3 className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No Analytics Data</h3>
              <p className="text-gray-500">Start using the platform to generate analytics insights.</p>
            </div>
          </div>
        )}

        {/* Quick Insights */}
        <div className="mt-8 bg-white rounded-lg shadow-sm p-6">
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Zap className="h-5 w-5 text-yellow-600" />
            Quick Insights & Recommendations
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="border border-blue-200 rounded-lg p-4 bg-blue-50">
              <h4 className="font-medium text-blue-900 mb-2">📈 Productivity Boost</h4>
              <p className="text-blue-800 text-sm">
                Your task completion rate increased by 15% this week. Keep up the momentum!
              </p>
            </div>
            
            <div className="border border-green-200 rounded-lg p-4 bg-green-50">
              <h4 className="font-medium text-green-900 mb-2">🎯 Campaign Success</h4>
              <p className="text-green-800 text-sm">
                Your latest social media campaign achieved 22% above average engagement.
              </p>
            </div>
            
            <div className="border border-purple-200 rounded-lg p-4 bg-purple-50">
              <h4 className="font-medium text-purple-900 mb-2">🏆 Achievement Ready</h4>
              <p className="text-purple-800 text-sm">
                You're 2 workshops away from unlocking the "Learning Champion" achievement!
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Analytics;
import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '../hooks/useAuth';
import { useToast } from '../hooks/use-toast';
import { isUnauthorizedError } from '../lib/authUtils';
import { apiRequest } from '../lib/queryClient';
import FileUpload from '../components/FileUpload';

const BrandAssets: React.FC = () => {
  const { user, isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showUploadForm, setShowUploadForm] = useState(false);
  const [filter, setFilter] = useState({ category: '', projectId: '', approved: '' });
  const [selectedAsset, setSelectedAsset] = useState<any>(null);

  // Redirect if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Fetch brand assets and projects
  const { data: assets = [], isLoading: assetsLoading } = useQuery({
    queryKey: ['/api/brand-assets'],
    queryFn: () => apiRequest('/api/brand-assets'),
    enabled: isAuthenticated,
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => window.location.href = "/api/login", 500);
      }
    }
  });

  const { data: projects = [] } = useQuery({
    queryKey: ['/api/projects'],
    queryFn: () => apiRequest('/api/projects'),
    enabled: isAuthenticated,
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => window.location.href = "/api/login", 500);
      }
    }
  });

  // Upload asset mutation
  const uploadAssetMutation = useMutation({
    mutationFn: (formData: FormData) => apiRequest('/api/brand-assets', {
      method: 'POST',
      data: formData,
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    }),
    onSuccess: () => {
      queryClient.invalidateQueries(['/api/brand-assets']);
      setShowUploadForm(false);
      toast({
        title: "Success",
        description: "Asset uploaded successfully",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => window.location.href = "/api/login", 500);
        return;
      }
      toast({
        title: "Error",
        description: error.message || "Failed to upload asset",
        variant: "destructive",
      });
    }
  });

  // Update asset mutation
  const updateAssetMutation = useMutation({
    mutationFn: ({ id, ...assetData }: any) => apiRequest(`/api/brand-assets/${id}`, {
      method: 'PUT',
      data: assetData,
    }),
    onSuccess: () => {
      queryClient.invalidateQueries(['/api/brand-assets']);
      toast({
        title: "Success",
        description: "Asset updated successfully",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => window.location.href = "/api/login", 500);
        return;
      }
      toast({
        title: "Error",
        description: error.message || "Failed to update asset",
        variant: "destructive",
      });
    }
  });

  const handleUpload = (formData: FormData) => {
    uploadAssetMutation.mutate(formData);
  };

  const handleApprovalToggle = (id: string, isApproved: boolean) => {
    updateAssetMutation.mutate({ id, isApproved: !isApproved });
  };

  // Filter assets
  const filteredAssets = assets.filter((asset: any) => {
    if (filter.category && asset.category !== filter.category) return false;
    if (filter.projectId && asset.projectId !== filter.projectId) return false;
    if (filter.approved === 'true' && !asset.isApproved) return false;
    if (filter.approved === 'false' && asset.isApproved) return false;
    return true;
  });

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'logo': return '🎨';
      case 'image': return '🖼️';
      case 'video': return '🎥';
      case 'document': return '📄';
      default: return '📁';
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  if (isLoading || assetsLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-900"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Brand Assets</h1>
        <button
          onClick={() => setShowUploadForm(!showUploadForm)}
          className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700"
        >
          Upload Asset
        </button>
      </div>

      {/* Stats */}
      <div className="grid md:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="text-2xl font-bold text-gray-600">{assets.length}</div>
          <p className="text-sm font-medium text-gray-500">Total Assets</p>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="text-2xl font-bold text-green-600">
            {assets.filter((a: any) => a.isApproved).length}
          </div>
          <p className="text-sm font-medium text-gray-500">Approved</p>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="text-2xl font-bold text-yellow-600">
            {assets.filter((a: any) => !a.isApproved).length}
          </div>
          <p className="text-sm font-medium text-gray-500">Pending Approval</p>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="text-2xl font-bold text-purple-600">
            {new Set(assets.map((a: any) => a.projectId).filter(Boolean)).size}
          </div>
          <p className="text-sm font-medium text-gray-500">Projects</p>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg shadow p-4">
        <div className="grid md:grid-cols-3 gap-4">
          <select
            value={filter.category}
            onChange={(e) => setFilter({ ...filter, category: e.target.value })}
            className="border rounded-md px-3 py-2"
          >
            <option value="">All Categories</option>
            <option value="logo">Logos</option>
            <option value="image">Images</option>
            <option value="video">Videos</option>
            <option value="document">Documents</option>
          </select>

          <select
            value={filter.projectId}
            onChange={(e) => setFilter({ ...filter, projectId: e.target.value })}
            className="border rounded-md px-3 py-2"
          >
            <option value="">All Projects</option>
            {projects.map((project: any) => (
              <option key={project.id} value={project.id}>
                {project.name}
              </option>
            ))}
          </select>

          <select
            value={filter.approved}
            onChange={(e) => setFilter({ ...filter, approved: e.target.value })}
            className="border rounded-md px-3 py-2"
          >
            <option value="">All Status</option>
            <option value="true">Approved</option>
            <option value="false">Pending</option>
          </select>
        </div>
      </div>

      {/* Upload Form */}
      {showUploadForm && (
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-lg font-medium mb-4">Upload Brand Asset</h2>
          <FileUpload
            onUpload={handleUpload}
            accept="image/*,video/*,.pdf,.doc,.docx"
            maxSize={50 * 1024 * 1024} // 50MB
            additionalFields={
              <div className="grid md:grid-cols-3 gap-4 mt-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Asset Name *
                  </label>
                  <input
                    type="text"
                    name="name"
                    required
                    className="w-full border rounded-md px-3 py-2"
                    placeholder="Enter asset name"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Category
                  </label>
                  <select name="category" className="w-full border rounded-md px-3 py-2">
                    <option value="">Select Category</option>
                    <option value="logo">Logo</option>
                    <option value="image">Image</option>
                    <option value="video">Video</option>
                    <option value="document">Document</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Project
                  </label>
                  <select name="projectId" className="w-full border rounded-md px-3 py-2">
                    <option value="">No Project</option>
                    {projects.map((project: any) => (
                      <option key={project.id} value={project.id}>
                        {project.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="md:col-span-3">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Description
                  </label>
                  <textarea
                    name="description"
                    rows={3}
                    className="w-full border rounded-md px-3 py-2"
                    placeholder="Enter asset description"
                  />
                </div>
              </div>
            }
            onCancel={() => setShowUploadForm(false)}
          />
        </div>
      )}

      {/* Assets Grid */}
      <div className="bg-white rounded-lg shadow">
        <div className="px-6 py-4 border-b border-gray-200">
          <h2 className="text-lg font-medium text-gray-900">Asset Library</h2>
        </div>
        <div className="p-6">
          {filteredAssets.length === 0 ? (
            <p className="text-gray-500 text-center py-8">No assets found</p>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredAssets.map((asset: any) => (
                <div key={asset.id} className="border rounded-lg overflow-hidden">
                  {/* Asset Preview */}
                  <div className="aspect-square bg-gray-100 flex items-center justify-center">
                    {asset.mimeType?.startsWith('image/') ? (
                      <img
                        src={`/${asset.filePath}`}
                        alt={asset.name}
                        className="w-full h-full object-cover"
                      />
                    ) : asset.mimeType?.startsWith('video/') ? (
                      <video
                        src={`/${asset.filePath}`}
                        className="w-full h-full object-cover"
                        controls={false}
                      />
                    ) : (
                      <div className="text-6xl text-gray-400">
                        {getCategoryIcon(asset.category)}
                      </div>
                    )}
                  </div>

                  {/* Asset Info */}
                  <div className="p-4">
                    <h3 className="font-medium text-gray-900 mb-1 truncate">
                      {asset.name}
                    </h3>
                    
                    <p className="text-xs text-gray-500 mb-2">
                      {asset.category || 'Uncategorized'} • {formatFileSize(asset.fileSize || 0)}
                    </p>

                    {asset.description && (
                      <p className="text-sm text-gray-600 mb-3 line-clamp-2">
                        {asset.description}
                      </p>
                    )}

                    {/* Status and Actions */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        {asset.isApproved ? (
                          <span className="px-2 py-1 text-xs rounded-full bg-green-100 text-green-800">
                            Approved
                          </span>
                        ) : (
                          <span className="px-2 py-1 text-xs rounded-full bg-yellow-100 text-yellow-800">
                            Pending
                          </span>
                        )}
                      </div>

                      <div className="flex items-center space-x-1">
                        <a
                          href={`/${asset.filePath}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-600 hover:text-blue-800 text-xs px-2 py-1"
                        >
                          View
                        </a>
                        
                        {(user?.role === 'admin' || user?.role === 'staff') && (
                          <button
                            onClick={() => handleApprovalToggle(asset.id, asset.isApproved)}
                            className={`text-xs px-2 py-1 rounded ${
                              asset.isApproved
                                ? 'text-yellow-700 hover:text-yellow-900'
                                : 'text-green-700 hover:text-green-900'
                            }`}
                          >
                            {asset.isApproved ? 'Unapprove' : 'Approve'}
                          </button>
                        )}
                      </div>
                    </div>

                    <div className="text-xs text-gray-400 mt-2">
                      Uploaded {new Date(asset.createdAt).toLocaleDateString()}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default BrandAssets;

import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '../lib/queryClient';
import { useAuth } from '../hooks/useAuth';
import { useToast } from '../hooks/use-toast';
import { isUnauthorizedError } from '../lib/authUtils';
import { 
  Target, 
  Calendar,
  Clock,
  DollarSign,
  TrendingUp,
  CheckCircle,
  AlertCircle,
  Play,
  Pause,
  Plus,
  Edit,
  BarChart3,
  Users,
  Eye,
  Filter,
  Search,
  Timeline,
  Milestone as MilestoneIcon,
  Flag,
  Award,
  Progress,
  Download,
  FileText,
  Zap
} from 'lucide-react';

interface Campaign {
  id: string;
  name: string;
  description: string;
  projectId: string;
  status: string;
  startDate: string;
  endDate: string;
  budget: number;
  spent: number;
  roi?: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

interface CampaignMilestone {
  id: string;
  campaignId: string;
  title: string;
  description: string;
  targetDate: string;
  completedDate?: string;
  status: string;
  progress: number;
  createdAt: string;
  updatedAt: string;
}

const CampaignManagement: React.FC = () => {
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [activeTab, setActiveTab] = useState('campaigns');
  const [selectedCampaign, setSelectedCampaign] = useState<Campaign | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showMilestoneModal, setShowMilestoneModal] = useState(false);
  const [filter, setFilter] = useState({ status: 'all', project: 'all' });
  const [campaignForm, setCampaignForm] = useState({
    name: '',
    description: '',
    projectId: '',
    startDate: '',
    endDate: '',
    budget: '',
    status: 'active'
  });
  const [milestoneForm, setMilestoneForm] = useState({
    title: '',
    description: '',
    targetDate: '',
    status: 'pending',
    progress: 0
  });

  // Fetch campaigns
  const { data: campaigns = [], isLoading: loadingCampaigns } = useQuery<Campaign[]>({
    queryKey: ['/api/campaigns'],
    queryFn: async () => {
      try {
        return await apiRequest('/api/campaigns');
      } catch (error: any) {
        if (isUnauthorizedError(error)) {
          toast({
            title: "Unauthorized",
            description: "You are logged out. Logging in again...",
            variant: "destructive",
          });
          setTimeout(() => {
            window.location.href = "/api/login";
          }, 500);
        }
        throw error;
      }
    },
  });

  // Fetch milestones for selected campaign
  const { data: milestones = [] } = useQuery<CampaignMilestone[]>({
    queryKey: ['/api/campaigns', selectedCampaign?.id, 'milestones'],
    queryFn: () => apiRequest(`/api/campaigns/${selectedCampaign?.id}/milestones`),
    enabled: !!selectedCampaign?.id,
  });

  // Fetch projects for form
  const { data: projects = [] } = useQuery({
    queryKey: ['/api/projects'],
    queryFn: () => apiRequest('/api/projects'),
  });

  // Create campaign mutation
  const createCampaign = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest('/api/campaigns', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...data,
          budget: parseInt(data.budget),
        }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/campaigns'] });
      setShowCreateModal(false);
      setCampaignForm({
        name: '',
        description: '',
        projectId: '',
        startDate: '',
        endDate: '',
        budget: '',
        status: 'active'
      });
      toast({
        title: "Campaign Created!",
        description: "Your campaign has been created successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: "Failed to create campaign.",
        variant: "destructive",
      });
    },
  });

  // Create milestone mutation
  const createMilestone = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest(`/api/campaigns/${selectedCampaign?.id}/milestones`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/campaigns', selectedCampaign?.id, 'milestones'] });
      setShowMilestoneModal(false);
      setMilestoneForm({
        title: '',
        description: '',
        targetDate: '',
        status: 'pending',
        progress: 0
      });
      toast({
        title: "Milestone Created!",
        description: "Campaign milestone has been added.",
      });
    },
  });

  // Update milestone progress
  const updateMilestone = useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: any }) => {
      return await apiRequest(`/api/campaign-milestones/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/campaigns', selectedCampaign?.id, 'milestones'] });
      toast({
        title: "Milestone Updated!",
        description: "Milestone progress has been updated.",
      });
    },
  });

  const filteredCampaigns = campaigns.filter(campaign => {
    const statusMatch = filter.status === 'all' || campaign.status === filter.status;
    const projectMatch = filter.project === 'all' || campaign.projectId === filter.project;
    return statusMatch && projectMatch;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'completed': return 'bg-blue-100 text-blue-800';
      case 'paused': return 'bg-yellow-100 text-yellow-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getMilestoneStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'in_progress': return 'bg-blue-100 text-blue-800';
      case 'pending': return 'bg-gray-100 text-gray-800';
      case 'overdue': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const calculateProgress = (campaign: Campaign) => {
    if (campaign.budget === 0) return 0;
    return Math.min((campaign.spent / campaign.budget) * 100, 100);
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Please log in to access Campaign Management</h1>
          <button 
            onClick={() => window.location.href = '/api/login'}
            className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700"
          >
            Log In
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <Target className="h-8 w-8 text-red-600" />
                <h1 className="text-3xl font-bold text-gray-900">Campaign Management</h1>
              </div>
              <p className="text-gray-600">
                Plan, track, and optimize your marketing campaigns with milestone tracking and ROI analysis.
              </p>
            </div>
            <button
              onClick={() => setShowCreateModal(true)}
              className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 flex items-center gap-2"
            >
              <Plus className="h-4 w-4" />
              New Campaign
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex space-x-1 bg-gray-100 rounded-lg p-1 mb-8">
          <button
            onClick={() => setActiveTab('campaigns')}
            className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
              activeTab === 'campaigns'
                ? 'bg-white text-red-600 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Target className="h-4 w-4 inline mr-2" />
            Campaigns
          </button>
          <button
            onClick={() => setActiveTab('timeline')}
            className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
              activeTab === 'timeline'
                ? 'bg-white text-red-600 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Timeline className="h-4 w-4 inline mr-2" />
            Timeline View
          </button>
          <button
            onClick={() => setActiveTab('analytics')}
            className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
              activeTab === 'analytics'
                ? 'bg-white text-red-600 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <BarChart3 className="h-4 w-4 inline mr-2" />
            Analytics
          </button>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4 text-gray-500" />
              <span className="text-sm font-medium text-gray-700">Filters:</span>
            </div>
            <select
              value={filter.status}
              onChange={(e) => setFilter({...filter, status: e.target.value})}
              className="border border-gray-300 rounded-lg px-3 py-1 text-sm focus:ring-2 focus:ring-red-500 focus:border-transparent"
            >
              <option value="all">All Status</option>
              <option value="active">Active</option>
              <option value="completed">Completed</option>
              <option value="paused">Paused</option>
              <option value="cancelled">Cancelled</option>
            </select>
            <select
              value={filter.project}
              onChange={(e) => setFilter({...filter, project: e.target.value})}
              className="border border-gray-300 rounded-lg px-3 py-1 text-sm focus:ring-2 focus:ring-red-500 focus:border-transparent"
            >
              <option value="all">All Projects</option>
              {projects.map((project: any) => (
                <option key={project.id} value={project.id}>{project.name}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Campaigns Tab */}
        {activeTab === 'campaigns' && (
          <div>
            {loadingCampaigns ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="bg-white rounded-lg shadow-sm p-6 animate-pulse">
                    <div className="h-6 bg-gray-200 rounded mb-4"></div>
                    <div className="h-4 bg-gray-200 rounded mb-3 w-3/4"></div>
                    <div className="h-16 bg-gray-200 rounded mb-4"></div>
                    <div className="flex gap-2">
                      <div className="h-8 bg-gray-200 rounded flex-1"></div>
                      <div className="h-8 bg-gray-200 rounded w-16"></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : filteredCampaigns.length === 0 ? (
              <div className="text-center py-12">
                <Target className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No campaigns found</h3>
                <p className="text-gray-500 mb-6">Create your first marketing campaign to get started!</p>
                <button
                  onClick={() => setShowCreateModal(true)}
                  className="bg-red-600 text-white px-6 py-3 rounded-lg hover:bg-red-700 flex items-center gap-2 mx-auto"
                >
                  <Plus className="h-4 w-4" />
                  Create Campaign
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredCampaigns.map((campaign) => (
                  <div key={campaign.id} className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow">
                    <div className="p-6">
                      {/* Header */}
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="font-semibold text-gray-900 truncate">{campaign.name}</h3>
                        <span className={`text-xs px-2 py-1 rounded-full ${getStatusColor(campaign.status)}`}>
                          {campaign.status}
                        </span>
                      </div>

                      {/* Description */}
                      <p className="text-gray-600 text-sm mb-4 line-clamp-2">{campaign.description}</p>

                      {/* Budget Progress */}
                      <div className="mb-4">
                        <div className="flex items-center justify-between text-sm mb-2">
                          <span className="text-gray-600">Budget Progress</span>
                          <span className="font-medium">
                            {formatCurrency(campaign.spent)} / {formatCurrency(campaign.budget)}
                          </span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-red-600 h-2 rounded-full transition-all duration-300" 
                            style={{ width: `${calculateProgress(campaign)}%` }}
                          ></div>
                        </div>
                        <div className="text-xs text-gray-500 mt-1">
                          {calculateProgress(campaign).toFixed(1)}% spent
                        </div>
                      </div>

                      {/* Timeline */}
                      <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
                        <div>
                          <div className="text-gray-600">Start Date</div>
                          <div className="font-medium">{new Date(campaign.startDate).toLocaleDateString()}</div>
                        </div>
                        <div>
                          <div className="text-gray-600">End Date</div>
                          <div className="font-medium">{new Date(campaign.endDate).toLocaleDateString()}</div>
                        </div>
                      </div>

                      {/* ROI */}
                      {campaign.roi && (
                        <div className="mb-4 p-3 bg-green-50 rounded-lg">
                          <div className="flex items-center gap-2">
                            <TrendingUp className="h-4 w-4 text-green-600" />
                            <span className="text-sm text-green-800">ROI: {campaign.roi}</span>
                          </div>
                        </div>
                      )}

                      {/* Actions */}
                      <div className="flex gap-2">
                        <button
                          onClick={() => setSelectedCampaign(campaign)}
                          className="flex-1 bg-red-600 text-white py-2 px-3 rounded-lg hover:bg-red-700 text-sm flex items-center justify-center gap-1"
                        >
                          <Eye className="h-4 w-4" />
                          View Details
                        </button>
                        <button className="border border-gray-300 text-gray-700 py-2 px-3 rounded-lg hover:bg-gray-50 text-sm">
                          <Edit className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Timeline View Tab */}
        {activeTab === 'timeline' && (
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h3 className="text-lg font-semibold mb-6 flex items-center gap-2">
              <Timeline className="h-5 w-5 text-red-600" />
              Campaign Timeline
            </h3>
            
            {filteredCampaigns.length === 0 ? (
              <div className="text-center py-12">
                <Timeline className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">No campaigns to display in timeline.</p>
              </div>
            ) : (
              <div className="space-y-6">
                {filteredCampaigns.map((campaign, index) => (
                  <div key={campaign.id} className="relative">
                    {/* Timeline Line */}
                    {index !== filteredCampaigns.length - 1 && (
                      <div className="absolute left-6 top-12 w-0.5 h-16 bg-gray-200"></div>
                    )}
                    
                    <div className="flex items-start gap-4">
                      {/* Timeline Dot */}
                      <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                        campaign.status === 'active' ? 'bg-green-100 text-green-600' :
                        campaign.status === 'completed' ? 'bg-blue-100 text-blue-600' :
                        campaign.status === 'paused' ? 'bg-yellow-100 text-yellow-600' :
                        'bg-gray-100 text-gray-600'
                      }`}>
                        <Target className="h-6 w-6" />
                      </div>
                      
                      {/* Campaign Details */}
                      <div className="flex-1 bg-gray-50 rounded-lg p-4">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-semibold text-gray-900">{campaign.name}</h4>
                          <span className={`text-xs px-2 py-1 rounded-full ${getStatusColor(campaign.status)}`}>
                            {campaign.status}
                          </span>
                        </div>
                        
                        <p className="text-gray-600 text-sm mb-3">{campaign.description}</p>
                        
                        <div className="grid grid-cols-3 gap-4 text-sm">
                          <div>
                            <span className="text-gray-500">Start:</span>
                            <div className="font-medium">{new Date(campaign.startDate).toLocaleDateString()}</div>
                          </div>
                          <div>
                            <span className="text-gray-500">End:</span>
                            <div className="font-medium">{new Date(campaign.endDate).toLocaleDateString()}</div>
                          </div>
                          <div>
                            <span className="text-gray-500">Budget:</span>
                            <div className="font-medium">{formatCurrency(campaign.budget)}</div>
                          </div>
                        </div>
                        
                        <div className="mt-3">
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-red-600 h-2 rounded-full" 
                              style={{ width: `${calculateProgress(campaign)}%` }}
                            ></div>
                          </div>
                          <div className="text-xs text-gray-500 mt-1">
                            {formatCurrency(campaign.spent)} spent ({calculateProgress(campaign).toFixed(1)}%)
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Analytics Tab */}
        {activeTab === 'analytics' && (
          <div className="space-y-6">
            {/* Overview Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="bg-gradient-to-r from-red-500 to-red-600 rounded-lg p-6 text-white">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-red-100">Total Campaigns</p>
                    <p className="text-3xl font-bold">{campaigns.length}</p>
                  </div>
                  <Target className="h-12 w-12 text-red-200" />
                </div>
              </div>
              
              <div className="bg-gradient-to-r from-green-500 to-green-600 rounded-lg p-6 text-white">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-green-100">Active</p>
                    <p className="text-3xl font-bold">
                      {campaigns.filter(c => c.status === 'active').length}
                    </p>
                  </div>
                  <Play className="h-12 w-12 text-green-200" />
                </div>
              </div>
              
              <div className="bg-gradient-to-r from-blue-500 to-blue-600 rounded-lg p-6 text-white">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-blue-100">Total Budget</p>
                    <p className="text-3xl font-bold">
                      {formatCurrency(campaigns.reduce((acc, c) => acc + c.budget, 0))}
                    </p>
                  </div>
                  <DollarSign className="h-12 w-12 text-blue-200" />
                </div>
              </div>
              
              <div className="bg-gradient-to-r from-purple-500 to-purple-600 rounded-lg p-6 text-white">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-purple-100">Total Spent</p>
                    <p className="text-3xl font-bold">
                      {formatCurrency(campaigns.reduce((acc, c) => acc + c.spent, 0))}
                    </p>
                  </div>
                  <TrendingUp className="h-12 w-12 text-purple-200" />
                </div>
              </div>
            </div>

            {/* Campaign Status Distribution */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-semibold mb-4">Campaign Status Distribution</h3>
              <div className="space-y-3">
                {['active', 'completed', 'paused', 'cancelled'].map((status) => {
                  const count = campaigns.filter(c => c.status === status).length;
                  const percentage = campaigns.length > 0 ? (count / campaigns.length) * 100 : 0;
                  
                  return (
                    <div key={status} className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <span className={`w-3 h-3 rounded-full ${
                          status === 'active' ? 'bg-green-500' :
                          status === 'completed' ? 'bg-blue-500' :
                          status === 'paused' ? 'bg-yellow-500' :
                          'bg-red-500'
                        }`}></span>
                        <span className="capitalize text-gray-700">{status}</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="w-32 bg-gray-200 rounded-full h-2">
                          <div 
                            className={`h-2 rounded-full ${
                              status === 'active' ? 'bg-green-500' :
                              status === 'completed' ? 'bg-blue-500' :
                              status === 'paused' ? 'bg-yellow-500' :
                              'bg-red-500'
                            }`}
                            style={{ width: `${percentage}%` }}
                          ></div>
                        </div>
                        <span className="text-sm text-gray-600 w-12">{count}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Budget Analysis */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-semibold mb-4">Budget Analysis</h3>
              <div className="space-y-4">
                {campaigns.map((campaign) => (
                  <div key={campaign.id} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-gray-900">{campaign.name}</span>
                      <span className="text-sm text-gray-600">
                        {formatCurrency(campaign.spent)} / {formatCurrency(campaign.budget)}
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-red-600 h-2 rounded-full" 
                        style={{ width: `${calculateProgress(campaign)}%` }}
                      ></div>
                    </div>
                    <div className="text-xs text-gray-500 mt-1">
                      {calculateProgress(campaign).toFixed(1)}% utilized
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Campaign Detail Modal */}
      {selectedCampaign && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-6xl w-full max-h-screen overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-2xl font-bold text-gray-900">{selectedCampaign.name}</h2>
                  <div className="flex items-center gap-4 mt-2">
                    <span className={`text-sm px-3 py-1 rounded-full ${getStatusColor(selectedCampaign.status)}`}>
                      {selectedCampaign.status}
                    </span>
                    <span className="text-gray-600">
                      {new Date(selectedCampaign.startDate).toLocaleDateString()} - {new Date(selectedCampaign.endDate).toLocaleDateString()}
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setShowMilestoneModal(true)}
                    className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 flex items-center gap-2"
                  >
                    <Plus className="h-4 w-4" />
                    Add Milestone
                  </button>
                  <button
                    onClick={() => setSelectedCampaign(null)}
                    className="text-gray-400 hover:text-gray-600 text-2xl"
                  >
                    ×
                  </button>
                </div>
              </div>
            </div>

            <div className="p-6">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Campaign Info */}
                <div className="lg:col-span-2">
                  <div className="mb-6">
                    <h3 className="text-lg font-semibold mb-3">Campaign Details</h3>
                    <p className="text-gray-700 mb-4">{selectedCampaign.description}</p>
                    
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-gray-600">Budget:</span>
                        <div className="font-medium text-lg">{formatCurrency(selectedCampaign.budget)}</div>
                      </div>
                      <div>
                        <span className="text-gray-600">Spent:</span>
                        <div className="font-medium text-lg">{formatCurrency(selectedCampaign.spent)}</div>
                      </div>
                      <div>
                        <span className="text-gray-600">Remaining:</span>
                        <div className="font-medium text-lg">{formatCurrency(selectedCampaign.budget - selectedCampaign.spent)}</div>
                      </div>
                      <div>
                        <span className="text-gray-600">Progress:</span>
                        <div className="font-medium text-lg">{calculateProgress(selectedCampaign).toFixed(1)}%</div>
                      </div>
                    </div>

                    <div className="mt-4">
                      <div className="w-full bg-gray-200 rounded-full h-3">
                        <div 
                          className="bg-red-600 h-3 rounded-full transition-all duration-300" 
                          style={{ width: `${calculateProgress(selectedCampaign)}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>

                  {/* Milestones */}
                  <div>
                    <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                      <MilestoneIcon className="h-5 w-5 text-red-600" />
                      Campaign Milestones
                    </h3>
                    
                    {milestones.length === 0 ? (
                      <div className="text-center py-8 bg-gray-50 rounded-lg">
                        <MilestoneIcon className="h-12 w-12 text-gray-400 mx-auto mb-3" />
                        <p className="text-gray-500 mb-4">No milestones set for this campaign.</p>
                        <button
                          onClick={() => setShowMilestoneModal(true)}
                          className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700"
                        >
                          Add First Milestone
                        </button>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {milestones.map((milestone, index) => (
                          <div key={milestone.id} className="border border-gray-200 rounded-lg p-4 relative">
                            {/* Timeline connection */}
                            {index !== milestones.length - 1 && (
                              <div className="absolute left-6 top-12 w-0.5 h-8 bg-gray-200"></div>
                            )}
                            
                            <div className="flex items-start gap-4">
                              {/* Milestone status dot */}
                              <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                                milestone.status === 'completed' ? 'bg-green-100 text-green-600' :
                                milestone.status === 'in_progress' ? 'bg-blue-100 text-blue-600' :
                                'bg-gray-100 text-gray-600'
                              }`}>
                                {milestone.status === 'completed' ? (
                                  <CheckCircle className="h-6 w-6" />
                                ) : milestone.status === 'in_progress' ? (
                                  <Progress className="h-6 w-6" />
                                ) : (
                                  <Flag className="h-6 w-6" />
                                )}
                              </div>
                              
                              <div className="flex-1">
                                <div className="flex items-center justify-between mb-2">
                                  <h4 className="font-semibold text-gray-900">{milestone.title}</h4>
                                  <span className={`text-xs px-2 py-1 rounded-full ${getMilestoneStatusColor(milestone.status)}`}>
                                    {milestone.status.replace('_', ' ')}
                                  </span>
                                </div>
                                
                                <p className="text-gray-600 text-sm mb-3">{milestone.description}</p>
                                
                                <div className="flex items-center justify-between text-sm">
                                  <span className="text-gray-500">
                                    Target: {new Date(milestone.targetDate).toLocaleDateString()}
                                  </span>
                                  <div className="flex items-center gap-2">
                                    <span className="text-gray-500">Progress:</span>
                                    <div className="w-20 bg-gray-200 rounded-full h-2">
                                      <div 
                                        className="bg-red-600 h-2 rounded-full" 
                                        style={{ width: `${milestone.progress}%` }}
                                      ></div>
                                    </div>
                                    <span className="text-xs font-medium">{milestone.progress}%</span>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {/* Sidebar */}
                <div>
                  <div className="bg-gray-50 rounded-lg p-6 mb-6">
                    <h3 className="text-lg font-semibold mb-4">Quick Actions</h3>
                    <div className="space-y-3">
                      <button className="w-full bg-red-600 text-white py-2 px-4 rounded-lg hover:bg-red-700 flex items-center justify-center gap-2">
                        <Edit className="h-4 w-4" />
                        Edit Campaign
                      </button>
                      <button className="w-full border border-gray-300 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-50 flex items-center justify-center gap-2">
                        <BarChart3 className="h-4 w-4" />
                        View Analytics
                      </button>
                      <button className="w-full border border-gray-300 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-50 flex items-center justify-center gap-2">
                        <Download className="h-4 w-4" />
                        Export Report
                      </button>
                    </div>
                  </div>

                  {/* Campaign Stats */}
                  <div className="bg-gray-50 rounded-lg p-6">
                    <h3 className="text-lg font-semibold mb-4">Campaign Stats</h3>
                    <div className="space-y-4">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Duration:</span>
                        <span className="font-medium">
                          {Math.ceil((new Date(selectedCampaign.endDate).getTime() - new Date(selectedCampaign.startDate).getTime()) / (1000 * 60 * 60 * 24))} days
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Milestones:</span>
                        <span className="font-medium">{milestones.length}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Completed:</span>
                        <span className="font-medium">
                          {milestones.filter(m => m.status === 'completed').length}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">In Progress:</span>
                        <span className="font-medium">
                          {milestones.filter(m => m.status === 'in_progress').length}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Create Campaign Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-2xl w-full max-h-screen overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-gray-900">Create New Campaign</h2>
                <button
                  onClick={() => setShowCreateModal(false)}
                  className="text-gray-400 hover:text-gray-600 text-2xl"
                >
                  ×
                </button>
              </div>
            </div>

            <div className="p-6">
              <form onSubmit={(e) => {
                e.preventDefault();
                createCampaign.mutate(campaignForm);
              }} className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Campaign Name
                  </label>
                  <input
                    type="text"
                    required
                    value={campaignForm.name}
                    onChange={(e) => setCampaignForm({...campaignForm, name: e.target.value})}
                    placeholder="e.g., Q1 Product Launch Campaign"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-red-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Description
                  </label>
                  <textarea
                    required
                    value={campaignForm.description}
                    onChange={(e) => setCampaignForm({...campaignForm, description: e.target.value})}
                    placeholder="Describe the campaign goals and strategy..."
                    rows={4}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-red-500 focus:border-transparent resize-none"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Project
                  </label>
                  <select
                    value={campaignForm.projectId}
                    onChange={(e) => setCampaignForm({...campaignForm, projectId: e.target.value})}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-red-500 focus:border-transparent"
                  >
                    <option value="">Select project (optional)</option>
                    {projects.map((project: any) => (
                      <option key={project.id} value={project.id}>{project.name}</option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Start Date
                    </label>
                    <input
                      type="date"
                      required
                      value={campaignForm.startDate}
                      onChange={(e) => setCampaignForm({...campaignForm, startDate: e.target.value})}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-red-500 focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      End Date
                    </label>
                    <input
                      type="date"
                      required
                      value={campaignForm.endDate}
                      onChange={(e) => setCampaignForm({...campaignForm, endDate: e.target.value})}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-red-500 focus:border-transparent"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Budget ($)
                    </label>
                    <input
                      type="number"
                      required
                      value={campaignForm.budget}
                      onChange={(e) => setCampaignForm({...campaignForm, budget: e.target.value})}
                      placeholder="10000"
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-red-500 focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Status
                    </label>
                    <select
                      value={campaignForm.status}
                      onChange={(e) => setCampaignForm({...campaignForm, status: e.target.value})}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-red-500 focus:border-transparent"
                    >
                      <option value="active">Active</option>
                      <option value="paused">Paused</option>
                      <option value="completed">Completed</option>
                    </select>
                  </div>
                </div>

                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={() => setShowCreateModal(false)}
                    className="flex-1 border border-gray-300 text-gray-700 py-3 px-4 rounded-lg hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={createCampaign.isPending}
                    className="flex-1 bg-red-600 text-white py-3 px-4 rounded-lg hover:bg-red-700 disabled:opacity-50"
                  >
                    {createCampaign.isPending ? 'Creating...' : 'Create Campaign'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Create Milestone Modal */}
      {showMilestoneModal && selectedCampaign && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-xl w-full">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold text-gray-900">Add Campaign Milestone</h2>
                <button
                  onClick={() => setShowMilestoneModal(false)}
                  className="text-gray-400 hover:text-gray-600 text-2xl"
                >
                  ×
                </button>
              </div>
            </div>

            <div className="p-6">
              <form onSubmit={(e) => {
                e.preventDefault();
                createMilestone.mutate(milestoneForm);
              }} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Milestone Title
                  </label>
                  <input
                    type="text"
                    required
                    value={milestoneForm.title}
                    onChange={(e) => setMilestoneForm({...milestoneForm, title: e.target.value})}
                    placeholder="e.g., Launch Landing Page"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-red-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Description
                  </label>
                  <textarea
                    value={milestoneForm.description}
                    onChange={(e) => setMilestoneForm({...milestoneForm, description: e.target.value})}
                    placeholder="Describe this milestone..."
                    rows={3}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-red-500 focus:border-transparent resize-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Target Date
                    </label>
                    <input
                      type="date"
                      required
                      value={milestoneForm.targetDate}
                      onChange={(e) => setMilestoneForm({...milestoneForm, targetDate: e.target.value})}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-red-500 focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Status
                    </label>
                    <select
                      value={milestoneForm.status}
                      onChange={(e) => setMilestoneForm({...milestoneForm, status: e.target.value})}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-red-500 focus:border-transparent"
                    >
                      <option value="pending">Pending</option>
                      <option value="in_progress">In Progress</option>
                      <option value="completed">Completed</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Progress ({milestoneForm.progress}%)
                  </label>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={milestoneForm.progress}
                    onChange={(e) => setMilestoneForm({...milestoneForm, progress: parseInt(e.target.value)})}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-gray-500 mt-1">
                    <span>0%</span>
                    <span>50%</span>
                    <span>100%</span>
                  </div>
                </div>

                <div className="flex gap-3 pt-4">
                  <button
                    type="button"
                    onClick={() => setShowMilestoneModal(false)}
                    className="flex-1 border border-gray-300 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={createMilestone.isPending}
                    className="flex-1 bg-red-600 text-white py-2 px-4 rounded-lg hover:bg-red-700 disabled:opacity-50"
                  >
                    {createMilestone.isPending ? 'Creating...' : 'Add Milestone'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CampaignManagement;
import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '../lib/queryClient';
import { useAuth } from '../hooks/useAuth';
import { useToast } from '../hooks/use-toast';
import { isUnauthorizedError } from '../lib/authUtils';
import { 
  Calendar,
  Clock,
  Eye,
  Heart,
  MessageCircle,
  Share2,
  TrendingUp,
  BarChart3,
  Image as ImageIcon,
  Video,
  Sparkles,
  Download,
  Copy,
  Filter,
  Plus,
  Instagram,
  Facebook,
  Linkedin,
  Twitter,
  Upload,
  Hash,
  Layout,
  PieChart,
  Users,
  Target,
  Zap,
  FileText
} from 'lucide-react';

interface SocialMediaContent {
  id: string;
  title: string;
  content: string;
  platform: string;
  scheduledFor: string;
  status: string;
  mediaUrl?: string;
  hashtags?: string;
  createdAt: string;
  projectId?: string;
}

interface PostTemplate {
  id: string;
  name: string;
  description: string;
  content: string;
  platform: string;
  category: string;
  usageCount: number;
  variables?: string;
  createdAt: string;
}

interface SocialMediaAnalytics {
  id: string;
  contentId: string;
  platform: string;
  reach: number;
  impressions: number;
  engagement: number;
  likes: number;
  shares: number;
  comments: number;
  clicks: number;
  recordedAt: string;
}

const EnhancedSocialMedia: React.FC = () => {
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [activeTab, setActiveTab] = useState('content');
  const [selectedPlatform, setPlatform] = useState('all');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showTemplateModal, setShowTemplateModal] = useState(false);
  const [selectedContent, setSelectedContent] = useState<SocialMediaContent | null>(null);
  const [contentForm, setContentForm] = useState({
    title: '',
    content: '',
    platform: 'instagram',
    scheduledFor: '',
    hashtags: '',
    projectId: ''
  });
  const [templateForm, setTemplateForm] = useState({
    name: '',
    description: '',
    content: '',
    platform: 'instagram',
    category: 'general'
  });

  // Fetch social media content
  const { data: content = [], isLoading: loadingContent } = useQuery<SocialMediaContent[]>({
    queryKey: ['/api/social-media'],
    queryFn: async () => {
      try {
        return await apiRequest('/api/social-media');
      } catch (error: any) {
        if (isUnauthorizedError(error)) {
          toast({
            title: "Unauthorized",
            description: "You are logged out. Logging in again...",
            variant: "destructive",
          });
          setTimeout(() => {
            window.location.href = "/api/login";
          }, 500);
        }
        throw error;
      }
    },
  });

  // Fetch post templates
  const { data: templates = [] } = useQuery<PostTemplate[]>({
    queryKey: ['/api/post-templates', selectedPlatform],
    queryFn: () => apiRequest(`/api/post-templates${selectedPlatform !== 'all' ? `?platform=${selectedPlatform}` : ''}`),
  });

  // Fetch projects for form
  const { data: projects = [] } = useQuery({
    queryKey: ['/api/projects'],
    queryFn: () => apiRequest('/api/projects'),
  });

  // Create content mutation
  const createContent = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest('/api/social-media', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/social-media'] });
      setShowCreateModal(false);
      setContentForm({
        title: '',
        content: '',
        platform: 'instagram',
        scheduledFor: '',
        hashtags: '',
        projectId: ''
      });
      toast({
        title: "Content Created!",
        description: "Your social media content has been scheduled.",
      });
    },
    onError: (error: any) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create content.",
        variant: "destructive",
      });
    },
  });

  // Create template mutation
  const createTemplate = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest('/api/post-templates', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/post-templates'] });
      setShowTemplateModal(false);
      setTemplateForm({
        name: '',
        description: '',
        content: '',
        platform: 'instagram',
        category: 'general'
      });
      toast({
        title: "Template Created!",
        description: "Your post template has been saved.",
      });
    },
  });

  // Generate AI content
  const generateAIContent = useMutation({
    mutationFn: async (data: { type: string; prompt: string; platform: string }) => {
      return await apiRequest('/api/ai-suggestions/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
    },
    onSuccess: (data) => {
      setContentForm(prev => ({
        ...prev,
        content: data.suggestion
      }));
      toast({
        title: "AI Content Generated!",
        description: "AI has created content for your post.",
      });
    },
  });

  const filteredContent = content.filter(item => 
    selectedPlatform === 'all' || item.platform === selectedPlatform
  );

  const getPlatformIcon = (platform: string) => {
    switch (platform) {
      case 'instagram': return <Instagram className="h-4 w-4" />;
      case 'facebook': return <Facebook className="h-4 w-4" />;
      case 'linkedin': return <Linkedin className="h-4 w-4" />;
      case 'twitter': return <Twitter className="h-4 w-4" />;
      default: return <Share2 className="h-4 w-4" />;
    }
  };

  const getPlatformColor = (platform: string) => {
    switch (platform) {
      case 'instagram': return 'bg-gradient-to-r from-purple-500 to-pink-500';
      case 'facebook': return 'bg-blue-600';
      case 'linkedin': return 'bg-blue-700';
      case 'twitter': return 'bg-sky-500';
      default: return 'bg-gray-600';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'published': return 'bg-green-100 text-green-800';
      case 'scheduled': return 'bg-blue-100 text-blue-800';
      case 'draft': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Please log in to access Social Media Planner</h1>
          <button 
            onClick={() => window.location.href = '/api/login'}
            className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700"
          >
            Log In
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <Share2 className="h-8 w-8 text-blue-600" />
                <h1 className="text-3xl font-bold text-gray-900">Enhanced Social Media Planner</h1>
              </div>
              <p className="text-gray-600">
                Create, schedule, and analyze your social media content with AI-powered features.
              </p>
            </div>
            <div className="flex gap-3">
              <button
                onClick={() => setShowTemplateModal(true)}
                className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 flex items-center gap-2"
              >
                <Layout className="h-4 w-4" />
                New Template
              </button>
              <button
                onClick={() => setShowCreateModal(true)}
                className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 flex items-center gap-2"
              >
                <Plus className="h-4 w-4" />
                Create Content
              </button>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex space-x-1 bg-gray-100 rounded-lg p-1 mb-8">
          <button
            onClick={() => setActiveTab('content')}
            className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
              activeTab === 'content'
                ? 'bg-white text-blue-600 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Calendar className="h-4 w-4 inline mr-2" />
            Content Calendar
          </button>
          <button
            onClick={() => setActiveTab('templates')}
            className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
              activeTab === 'templates'
                ? 'bg-white text-blue-600 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Layout className="h-4 w-4 inline mr-2" />
            Templates
          </button>
          <button
            onClick={() => setActiveTab('analytics')}
            className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
              activeTab === 'analytics'
                ? 'bg-white text-blue-600 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <BarChart3 className="h-4 w-4 inline mr-2" />
            Analytics
          </button>
          <button
            onClick={() => setActiveTab('ai-insights')}
            className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
              activeTab === 'ai-insights'
                ? 'bg-white text-blue-600 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Sparkles className="h-4 w-4 inline mr-2" />
            AI Insights
          </button>
        </div>

        {/* Platform Filter */}
        <div className="mb-6">
          <div className="flex items-center gap-4">
            <span className="text-sm font-medium text-gray-700">Filter by platform:</span>
            <div className="flex gap-2">
              {['all', 'instagram', 'facebook', 'linkedin', 'twitter'].map((platform) => (
                <button
                  key={platform}
                  onClick={() => setPlatform(platform)}
                  className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                    selectedPlatform === platform
                      ? 'bg-blue-600 text-white'
                      : 'bg-white text-gray-700 hover:bg-gray-50 border border-gray-300'
                  }`}
                >
                  {platform === 'all' ? 'All Platforms' : (
                    <div className="flex items-center gap-1">
                      {getPlatformIcon(platform)}
                      <span className="capitalize">{platform}</span>
                    </div>
                  )}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Content Calendar Tab */}
        {activeTab === 'content' && (
          <div>
            {loadingContent ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="bg-white rounded-lg shadow-sm p-6 animate-pulse">
                    <div className="flex items-center gap-2 mb-4">
                      <div className="h-6 w-6 bg-gray-200 rounded"></div>
                      <div className="h-4 bg-gray-200 rounded w-20"></div>
                    </div>
                    <div className="h-6 bg-gray-200 rounded mb-3"></div>
                    <div className="h-16 bg-gray-200 rounded mb-4"></div>
                    <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                  </div>
                ))}
              </div>
            ) : filteredContent.length === 0 ? (
              <div className="text-center py-12">
                <Calendar className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No content scheduled</h3>
                <p className="text-gray-500 mb-6">Create your first social media post to get started!</p>
                <button
                  onClick={() => setShowCreateModal(true)}
                  className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 flex items-center gap-2 mx-auto"
                >
                  <Plus className="h-4 w-4" />
                  Create Content
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredContent.map((item) => (
                  <div key={item.id} className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow">
                    <div className="p-6">
                      {/* Header */}
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-2">
                          <div className={`p-2 rounded-lg text-white ${getPlatformColor(item.platform)}`}>
                            {getPlatformIcon(item.platform)}
                          </div>
                          <span className="font-medium capitalize">{item.platform}</span>
                        </div>
                        <span className={`text-xs px-2 py-1 rounded-full ${getStatusColor(item.status)}`}>
                          {item.status}
                        </span>
                      </div>

                      {/* Content */}
                      <h3 className="font-semibold text-gray-900 mb-2">{item.title}</h3>
                      <p className="text-gray-600 text-sm mb-4 line-clamp-3">{item.content}</p>

                      {/* Hashtags */}
                      {item.hashtags && (
                        <div className="mb-4">
                          <p className="text-blue-600 text-sm">{item.hashtags}</p>
                        </div>
                      )}

                      {/* Schedule Info */}
                      <div className="flex items-center gap-4 text-sm text-gray-500 mb-4">
                        <div className="flex items-center gap-1">
                          <Clock className="h-4 w-4" />
                          <span>{new Date(item.scheduledFor).toLocaleDateString()}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Calendar className="h-4 w-4" />
                          <span>{new Date(item.scheduledFor).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="flex gap-2">
                        <button
                          onClick={() => setSelectedContent(item)}
                          className="flex-1 bg-blue-600 text-white py-2 px-3 rounded-lg hover:bg-blue-700 text-sm flex items-center justify-center gap-1"
                        >
                          <Eye className="h-4 w-4" />
                          View
                        </button>
                        <button className="flex-1 border border-gray-300 text-gray-700 py-2 px-3 rounded-lg hover:bg-gray-50 text-sm flex items-center justify-center gap-1">
                          <BarChart3 className="h-4 w-4" />
                          Analytics
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Templates Tab */}
        {activeTab === 'templates' && (
          <div>
            {templates.length === 0 ? (
              <div className="text-center py-12">
                <Layout className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No templates yet</h3>
                <p className="text-gray-500 mb-6">Create reusable post templates to save time!</p>
                <button
                  onClick={() => setShowTemplateModal(true)}
                  className="bg-purple-600 text-white px-6 py-3 rounded-lg hover:bg-purple-700 flex items-center gap-2 mx-auto"
                >
                  <Plus className="h-4 w-4" />
                  Create Template
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {templates.map((template) => (
                  <div key={template.id} className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow">
                    <div className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-2">
                          <div className={`p-2 rounded-lg text-white ${getPlatformColor(template.platform)}`}>
                            {getPlatformIcon(template.platform)}
                          </div>
                          <span className="font-medium capitalize">{template.platform}</span>
                        </div>
                        <span className="text-xs bg-purple-100 text-purple-700 px-2 py-1 rounded-full">
                          {template.category}
                        </span>
                      </div>

                      <h3 className="font-semibold text-gray-900 mb-2">{template.name}</h3>
                      <p className="text-gray-600 text-sm mb-4">{template.description}</p>

                      <div className="bg-gray-50 rounded-lg p-3 mb-4">
                        <p className="text-sm text-gray-700 line-clamp-3">{template.content}</p>
                      </div>

                      <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                        <span>Used {template.usageCount} times</span>
                        <span>{new Date(template.createdAt).toLocaleDateString()}</span>
                      </div>

                      <div className="flex gap-2">
                        <button
                          onClick={() => {
                            setContentForm(prev => ({
                              ...prev,
                              content: template.content,
                              platform: template.platform
                            }));
                            setShowCreateModal(true);
                          }}
                          className="flex-1 bg-purple-600 text-white py-2 px-3 rounded-lg hover:bg-purple-700 text-sm flex items-center justify-center gap-1"
                        >
                          <Zap className="h-4 w-4" />
                          Use Template
                        </button>
                        <button
                          onClick={() => {
                            navigator.clipboard.writeText(template.content);
                            toast({
                              title: "Copied!",
                              description: "Template content copied to clipboard.",
                            });
                          }}
                          className="border border-gray-300 text-gray-700 py-2 px-3 rounded-lg hover:bg-gray-50 text-sm flex items-center justify-center gap-1"
                        >
                          <Copy className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Analytics Tab */}
        {activeTab === 'analytics' && (
          <div className="space-y-6">
            {/* Overview Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="bg-gradient-to-r from-blue-500 to-blue-600 rounded-lg p-6 text-white">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-blue-100">Total Posts</p>
                    <p className="text-3xl font-bold">{content.length}</p>
                  </div>
                  <FileText className="h-12 w-12 text-blue-200" />
                </div>
              </div>
              
              <div className="bg-gradient-to-r from-green-500 to-green-600 rounded-lg p-6 text-white">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-green-100">Published</p>
                    <p className="text-3xl font-bold">
                      {content.filter(c => c.status === 'published').length}
                    </p>
                  </div>
                  <Eye className="h-12 w-12 text-green-200" />
                </div>
              </div>
              
              <div className="bg-gradient-to-r from-purple-500 to-purple-600 rounded-lg p-6 text-white">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-purple-100">Scheduled</p>
                    <p className="text-3xl font-bold">
                      {content.filter(c => c.status === 'scheduled').length}
                    </p>
                  </div>
                  <Clock className="h-12 w-12 text-purple-200" />
                </div>
              </div>
              
              <div className="bg-gradient-to-r from-orange-500 to-orange-600 rounded-lg p-6 text-white">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-orange-100">Templates</p>
                    <p className="text-3xl font-bold">{templates.length}</p>
                  </div>
                  <Layout className="h-12 w-12 text-orange-200" />
                </div>
              </div>
            </div>

            {/* Platform Distribution */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-semibold mb-4">Platform Distribution</h3>
              <div className="space-y-3">
                {['instagram', 'facebook', 'linkedin', 'twitter'].map((platform) => {
                  const count = content.filter(c => c.platform === platform).length;
                  const percentage = content.length > 0 ? (count / content.length) * 100 : 0;
                  
                  return (
                    <div key={platform} className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-lg text-white ${getPlatformColor(platform)}`}>
                          {getPlatformIcon(platform)}
                        </div>
                        <span className="capitalize text-gray-700">{platform}</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="w-32 bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-blue-600 h-2 rounded-full" 
                            style={{ width: `${percentage}%` }}
                          ></div>
                        </div>
                        <span className="text-sm text-gray-600 w-12">{count}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Engagement Metrics Placeholder */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-semibold mb-4">Engagement Overview</h3>
              <p className="text-gray-500 text-center py-8">
                Connect your social media accounts to view detailed engagement analytics including likes, shares, comments, and reach.
              </p>
            </div>
          </div>
        )}

        {/* AI Insights Tab */}
        {activeTab === 'ai-insights' && (
          <div className="space-y-6">
            <div className="bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg p-8 text-white">
              <div className="flex items-center gap-4 mb-4">
                <Sparkles className="h-8 w-8" />
                <h2 className="text-2xl font-bold">AI Content Insights</h2>
              </div>
              <p className="text-purple-100">
                Get intelligent recommendations for your social media strategy based on performance data and trends.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-white rounded-lg shadow-sm p-6">
                <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <Target className="h-5 w-5 text-blue-600" />
                  Content Recommendations
                </h3>
                <div className="space-y-4">
                  <div className="border border-gray-200 rounded-lg p-4">
                    <h4 className="font-medium text-gray-900 mb-2">Optimal Posting Times</h4>
                    <p className="text-sm text-gray-600 mb-3">
                      Based on your audience activity, the best times to post are:
                    </p>
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div className="bg-blue-50 p-2 rounded">
                        <strong>Weekdays:</strong> 9 AM - 11 AM
                      </div>
                      <div className="bg-blue-50 p-2 rounded">
                        <strong>Weekends:</strong> 2 PM - 4 PM
                      </div>
                    </div>
                  </div>

                  <div className="border border-gray-200 rounded-lg p-4">
                    <h4 className="font-medium text-gray-900 mb-2">Trending Hashtags</h4>
                    <p className="text-sm text-gray-600 mb-3">
                      Consider using these trending hashtags in your industry:
                    </p>
                    <div className="flex flex-wrap gap-1">
                      {['#startup', '#innovation', '#tech', '#business', '#growth', '#digitalmarketing'].map((tag) => (
                        <span key={tag} className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded-full">
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow-sm p-6">
                <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-green-600" />
                  Performance Insights
                </h3>
                <div className="space-y-4">
                  <div className="border border-gray-200 rounded-lg p-4">
                    <h4 className="font-medium text-gray-900 mb-2">Content Performance</h4>
                    <p className="text-sm text-gray-600 mb-3">
                      Your most engaging content types:
                    </p>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Video Content</span>
                        <div className="flex items-center gap-2">
                          <div className="w-16 bg-gray-200 rounded-full h-2">
                            <div className="bg-green-600 h-2 rounded-full w-4/5"></div>
                          </div>
                          <span className="text-xs text-gray-600">85%</span>
                        </div>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Images</span>
                        <div className="flex items-center gap-2">
                          <div className="w-16 bg-gray-200 rounded-full h-2">
                            <div className="bg-blue-600 h-2 rounded-full w-3/5"></div>
                          </div>
                          <span className="text-xs text-gray-600">65%</span>
                        </div>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Text Posts</span>
                        <div className="flex items-center gap-2">
                          <div className="w-16 bg-gray-200 rounded-full h-2">
                            <div className="bg-purple-600 h-2 rounded-full w-2/5"></div>
                          </div>
                          <span className="text-xs text-gray-600">45%</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="border border-gray-200 rounded-lg p-4">
                    <h4 className="font-medium text-gray-900 mb-2">AI Suggestion</h4>
                    <p className="text-sm text-gray-600">
                      💡 Try posting more video content during peak hours (9-11 AM) to maximize engagement. 
                      Videos get 85% more engagement than other content types.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Create Content Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-2xl w-full max-h-screen overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-gray-900">Create Social Media Content</h2>
                <button
                  onClick={() => setShowCreateModal(false)}
                  className="text-gray-400 hover:text-gray-600 text-2xl"
                >
                  ×
                </button>
              </div>
            </div>

            <div className="p-6">
              <form onSubmit={(e) => {
                e.preventDefault();
                createContent.mutate(contentForm);
              }} className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Platform
                    </label>
                    <select
                      value={contentForm.platform}
                      onChange={(e) => setContentForm({...contentForm, platform: e.target.value})}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      <option value="instagram">Instagram</option>
                      <option value="facebook">Facebook</option>
                      <option value="linkedin">LinkedIn</option>
                      <option value="twitter">Twitter</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Project
                    </label>
                    <select
                      value={contentForm.projectId}
                      onChange={(e) => setContentForm({...contentForm, projectId: e.target.value})}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      <option value="">Select project (optional)</option>
                      {projects.map((project: any) => (
                        <option key={project.id} value={project.id}>{project.name}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Title
                  </label>
                  <input
                    type="text"
                    required
                    value={contentForm.title}
                    onChange={(e) => setContentForm({...contentForm, title: e.target.value})}
                    placeholder="Enter post title..."
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="block text-sm font-medium text-gray-700">
                      Content
                    </label>
                    <button
                      type="button"
                      onClick={() => {
                        const prompt = `Create engaging content for ${contentForm.platform} about ${contentForm.title}`;
                        generateAIContent.mutate({
                          type: 'content',
                          prompt,
                          platform: contentForm.platform
                        });
                      }}
                      disabled={generateAIContent.isPending}
                      className="text-purple-600 hover:text-purple-700 text-sm flex items-center gap-1"
                    >
                      <Sparkles className="h-4 w-4" />
                      {generateAIContent.isPending ? 'Generating...' : 'Generate with AI'}
                    </button>
                  </div>
                  <textarea
                    required
                    value={contentForm.content}
                    onChange={(e) => setContentForm({...contentForm, content: e.target.value})}
                    placeholder="Write your post content..."
                    rows={6}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Hashtags
                  </label>
                  <input
                    type="text"
                    value={contentForm.hashtags}
                    onChange={(e) => setContentForm({...contentForm, hashtags: e.target.value})}
                    placeholder="#startup #business #growth"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Schedule For
                  </label>
                  <input
                    type="datetime-local"
                    required
                    value={contentForm.scheduledFor}
                    onChange={(e) => setContentForm({...contentForm, scheduledFor: e.target.value})}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={() => setShowCreateModal(false)}
                    className="flex-1 border border-gray-300 text-gray-700 py-3 px-4 rounded-lg hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={createContent.isPending}
                    className="flex-1 bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 disabled:opacity-50"
                  >
                    {createContent.isPending ? 'Creating...' : 'Schedule Post'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Create Template Modal */}
      {showTemplateModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-2xl w-full max-h-screen overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-gray-900">Create Post Template</h2>
                <button
                  onClick={() => setShowTemplateModal(false)}
                  className="text-gray-400 hover:text-gray-600 text-2xl"
                >
                  ×
                </button>
              </div>
            </div>

            <div className="p-6">
              <form onSubmit={(e) => {
                e.preventDefault();
                createTemplate.mutate(templateForm);
              }} className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Template Name
                    </label>
                    <input
                      type="text"
                      required
                      value={templateForm.name}
                      onChange={(e) => setTemplateForm({...templateForm, name: e.target.value})}
                      placeholder="e.g., Product Launch Announcement"
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Category
                    </label>
                    <select
                      value={templateForm.category}
                      onChange={(e) => setTemplateForm({...templateForm, category: e.target.value})}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    >
                      <option value="general">General</option>
                      <option value="promotion">Promotion</option>
                      <option value="engagement">Engagement</option>
                      <option value="announcement">Announcement</option>
                      <option value="educational">Educational</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Platform
                  </label>
                  <select
                    value={templateForm.platform}
                    onChange={(e) => setTemplateForm({...templateForm, platform: e.target.value})}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  >
                    <option value="instagram">Instagram</option>
                    <option value="facebook">Facebook</option>
                    <option value="linkedin">LinkedIn</option>
                    <option value="twitter">Twitter</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Description
                  </label>
                  <input
                    type="text"
                    required
                    value={templateForm.description}
                    onChange={(e) => setTemplateForm({...templateForm, description: e.target.value})}
                    placeholder="Describe when to use this template..."
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Template Content
                  </label>
                  <textarea
                    required
                    value={templateForm.content}
                    onChange={(e) => setTemplateForm({...templateForm, content: e.target.value})}
                    placeholder="Write your template content. Use {{variable}} for dynamic content..."
                    rows={8}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-purple-500 focus:border-transparent resize-none"
                  />
                  <p className="text-sm text-gray-500 mt-1">
                    Use variables like {{product_name}} or {{company}} to make templates reusable.
                  </p>
                </div>

                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={() => setShowTemplateModal(false)}
                    className="flex-1 border border-gray-300 text-gray-700 py-3 px-4 rounded-lg hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={createTemplate.isPending}
                    className="flex-1 bg-purple-600 text-white py-3 px-4 rounded-lg hover:bg-purple-700 disabled:opacity-50"
                  >
                    {createTemplate.isPending ? 'Creating...' : 'Create Template'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default EnhancedSocialMedia;
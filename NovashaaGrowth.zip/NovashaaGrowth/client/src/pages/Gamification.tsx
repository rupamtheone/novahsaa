import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '../lib/queryClient';
import { useAuth } from '../hooks/useAuth';
import { useToast } from '../hooks/use-toast';
import { isUnauthorizedError } from '../lib/authUtils';
import { 
  Trophy,
  Award,
  Star,
  Target,
  TrendingUp,
  Medal,
  Crown,
  Zap,
  Fire,
  Gift,
  Users,
  Calendar,
  CheckCircle,
  BarChart3,
  ArrowUp,
  ArrowDown,
  Sparkles,
  Gem,
  Flag,
  ThumbsUp,
  Eye,
  Download
} from 'lucide-react';

interface Achievement {
  id: string;
  name: string;
  description: string;
  category: string;
  type: string;
  target: number;
  points: number;
  badgeIcon: string;
  isActive: boolean;
  createdAt: string;
}

interface UserAchievement {
  id: string;
  userId: string;
  achievementId: string;
  progress: number;
  isCompleted: boolean;
  completedAt?: string;
  pointsAwarded: number;
  createdAt: string;
}

interface UserStats {
  totalPoints: number;
  level: number;
  rank: number;
  completedAchievements: number;
  streakDays: number;
  weeklyPoints: number;
  monthlyPoints: number;
}

interface LeaderboardEntry {
  userId: string;
  userEmail: string;
  userName: string;
  totalPoints: number;
  level: number;
  rank: number;
  recentActivity: string;
}

const Gamification: React.FC = () => {
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [activeTab, setActiveTab] = useState('achievements');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [leaderboardPeriod, setLeaderboardPeriod] = useState('all-time');

  // Fetch achievements
  const { data: achievements = [], isLoading: loadingAchievements } = useQuery<Achievement[]>({
    queryKey: ['/api/achievements'],
    queryFn: async () => {
      try {
        return await apiRequest('/api/achievements');
      } catch (error: any) {
        if (isUnauthorizedError(error)) {
          toast({
            title: "Unauthorized",
            description: "You are logged out. Logging in again...",
            variant: "destructive",
          });
          setTimeout(() => {
            window.location.href = "/api/login";
          }, 500);
        }
        throw error;
      }
    },
  });

  // Fetch user achievements
  const { data: userAchievements = [] } = useQuery<UserAchievement[]>({
    queryKey: ['/api/user-achievements'],
    queryFn: () => apiRequest('/api/user-achievements'),
  });

  // Fetch user stats
  const { data: userStats } = useQuery<UserStats>({
    queryKey: ['/api/user-stats'],
    queryFn: () => apiRequest('/api/user-stats'),
  });

  // Fetch leaderboard
  const { data: leaderboard = [] } = useQuery<LeaderboardEntry[]>({
    queryKey: ['/api/leaderboard', leaderboardPeriod],
    queryFn: () => apiRequest(`/api/leaderboard?period=${leaderboardPeriod}`),
  });

  const categories = [
    { value: 'all', label: 'All Categories', icon: <Trophy className="h-4 w-4" /> },
    { value: 'tasks', label: 'Task Management', icon: <CheckCircle className="h-4 w-4" /> },
    { value: 'social', label: 'Social Media', icon: <Sparkles className="h-4 w-4" /> },
    { value: 'campaigns', label: 'Campaigns', icon: <Target className="h-4 w-4" /> },
    { value: 'networking', label: 'Networking', icon: <Users className="h-4 w-4" /> },
    { value: 'learning', label: 'Learning', icon: <Award className="h-4 w-4" /> },
    { value: 'engagement', label: 'Engagement', icon: <Fire className="h-4 w-4" /> },
  ];

  const filteredAchievements = achievements.filter(achievement =>
    selectedCategory === 'all' || achievement.category === selectedCategory
  );

  const getUserAchievement = (achievementId: string) => {
    return userAchievements.find(ua => ua.achievementId === achievementId);
  };

  const getAchievementIcon = (badgeIcon: string) => {
    const iconMap: { [key: string]: React.ReactNode } = {
      trophy: <Trophy className="h-6 w-6" />,
      medal: <Medal className="h-6 w-6" />,
      star: <Star className="h-6 w-6" />,
      crown: <Crown className="h-6 w-6" />,
      award: <Award className="h-6 w-6" />,
      target: <Target className="h-6 w-6" />,
      fire: <Fire className="h-6 w-6" />,
      zap: <Zap className="h-6 w-6" />,
      gem: <Gem className="h-6 w-6" />,
      flag: <Flag className="h-6 w-6" />,
    };
    return iconMap[badgeIcon] || <Trophy className="h-6 w-6" />;
  };

  const getLevelProgress = (points: number) => {
    const pointsPerLevel = 1000;
    const currentLevel = Math.floor(points / pointsPerLevel) + 1;
    const pointsInCurrentLevel = points % pointsPerLevel;
    const progressPercentage = (pointsInCurrentLevel / pointsPerLevel) * 100;
    
    return {
      level: currentLevel,
      progress: progressPercentage,
      pointsToNext: pointsPerLevel - pointsInCurrentLevel,
    };
  };

  const getRankSuffix = (rank: number) => {
    if (rank % 100 >= 11 && rank % 100 <= 13) return 'th';
    switch (rank % 10) {
      case 1: return 'st';
      case 2: return 'nd';
      case 3: return 'rd';
      default: return 'th';
    }
  };

  const getCategoryColor = (category: string) => {
    const colors = {
      tasks: 'bg-blue-100 text-blue-800',
      social: 'bg-purple-100 text-purple-800',
      campaigns: 'bg-red-100 text-red-800',
      networking: 'bg-green-100 text-green-800',
      learning: 'bg-yellow-100 text-yellow-800',
      engagement: 'bg-pink-100 text-pink-800',
    };
    return colors[category as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Please log in to access Achievements</h1>
          <button 
            onClick={() => window.location.href = '/api/login'}
            className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700"
          >
            Log In
          </button>
        </div>
      </div>
    );
  }

  const levelInfo = userStats ? getLevelProgress(userStats.totalPoints) : { level: 1, progress: 0, pointsToNext: 1000 };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <Trophy className="h-8 w-8 text-yellow-600" />
            <h1 className="text-3xl font-bold text-gray-900">Achievements & Progress</h1>
          </div>
          <p className="text-gray-600">
            Track your progress, earn achievements, and compete with others to level up your business journey.
          </p>
        </div>

        {/* User Stats Overview */}
        {userStats && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div className="bg-gradient-to-r from-yellow-500 to-yellow-600 rounded-lg p-6 text-white">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-yellow-100">Level</p>
                  <p className="text-3xl font-bold">{levelInfo.level}</p>
                </div>
                <Crown className="h-12 w-12 text-yellow-200" />
              </div>
              <div className="mt-4">
                <div className="w-full bg-yellow-400 rounded-full h-2">
                  <div 
                    className="bg-white h-2 rounded-full transition-all duration-300" 
                    style={{ width: `${levelInfo.progress}%` }}
                  ></div>
                </div>
                <p className="text-yellow-100 text-sm mt-1">
                  {levelInfo.pointsToNext} points to next level
                </p>
              </div>
            </div>
            
            <div className="bg-gradient-to-r from-blue-500 to-blue-600 rounded-lg p-6 text-white">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-100">Total Points</p>
                  <p className="text-3xl font-bold">{userStats.totalPoints.toLocaleString()}</p>
                </div>
                <Star className="h-12 w-12 text-blue-200" />
              </div>
            </div>
            
            <div className="bg-gradient-to-r from-green-500 to-green-600 rounded-lg p-6 text-white">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-100">Global Rank</p>
                  <p className="text-3xl font-bold">
                    {userStats.rank}{getRankSuffix(userStats.rank)}
                  </p>
                </div>
                <Trophy className="h-12 w-12 text-green-200" />
              </div>
            </div>
            
            <div className="bg-gradient-to-r from-purple-500 to-purple-600 rounded-lg p-6 text-white">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-purple-100">Achievements</p>
                  <p className="text-3xl font-bold">{userStats.completedAchievements}</p>
                </div>
                <Award className="h-12 w-12 text-purple-200" />
              </div>
            </div>
          </div>
        )}

        {/* Navigation Tabs */}
        <div className="flex space-x-1 bg-gray-100 rounded-lg p-1 mb-8">
          <button
            onClick={() => setActiveTab('achievements')}
            className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
              activeTab === 'achievements'
                ? 'bg-white text-yellow-600 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Trophy className="h-4 w-4 inline mr-2" />
            Achievements
          </button>
          <button
            onClick={() => setActiveTab('leaderboard')}
            className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
              activeTab === 'leaderboard'
                ? 'bg-white text-yellow-600 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Crown className="h-4 w-4 inline mr-2" />
            Leaderboard
          </button>
          <button
            onClick={() => setActiveTab('progress')}
            className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
              activeTab === 'progress'
                ? 'bg-white text-yellow-600 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <BarChart3 className="h-4 w-4 inline mr-2" />
            Progress
          </button>
          <button
            onClick={() => setActiveTab('rewards')}
            className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
              activeTab === 'rewards'
                ? 'bg-white text-yellow-600 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Gift className="h-4 w-4 inline mr-2" />
            Rewards
          </button>
        </div>

        {/* Achievements Tab */}
        {activeTab === 'achievements' && (
          <div>
            {/* Category Filter */}
            <div className="mb-6">
              <div className="flex flex-wrap gap-2">
                {categories.map((category) => (
                  <button
                    key={category.value}
                    onClick={() => setSelectedCategory(category.value)}
                    className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                      selectedCategory === category.value
                        ? 'bg-yellow-600 text-white'
                        : 'bg-white text-gray-700 hover:bg-gray-50 border border-gray-300'
                    }`}
                  >
                    {category.icon}
                    {category.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Achievements Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {loadingAchievements ? (
                Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="bg-white rounded-lg shadow-sm p-6 animate-pulse">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="h-12 w-12 bg-gray-200 rounded-full"></div>
                      <div className="flex-1">
                        <div className="h-4 bg-gray-200 rounded mb-2"></div>
                        <div className="h-3 bg-gray-200 rounded w-2/3"></div>
                      </div>
                    </div>
                    <div className="h-16 bg-gray-200 rounded mb-4"></div>
                    <div className="h-2 bg-gray-200 rounded"></div>
                  </div>
                ))
              ) : filteredAchievements.length === 0 ? (
                <div className="col-span-full text-center py-12">
                  <Trophy className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No achievements found</h3>
                  <p className="text-gray-500">Try selecting a different category.</p>
                </div>
              ) : (
                filteredAchievements.map((achievement) => {
                  const userAchievement = getUserAchievement(achievement.id);
                  const isCompleted = userAchievement?.isCompleted || false;
                  const progress = userAchievement?.progress || 0;
                  const progressPercentage = Math.min((progress / achievement.target) * 100, 100);

                  return (
                    <div
                      key={achievement.id}
                      className={`bg-white rounded-lg shadow-sm p-6 border-l-4 transition-all duration-300 ${
                        isCompleted
                          ? 'border-yellow-500 bg-yellow-50'
                          : 'border-gray-200 hover:shadow-md'
                      }`}
                    >
                      {/* Achievement Header */}
                      <div className="flex items-center gap-3 mb-4">
                        <div className={`p-3 rounded-full ${
                          isCompleted
                            ? 'bg-yellow-100 text-yellow-600'
                            : 'bg-gray-100 text-gray-600'
                        }`}>
                          {getAchievementIcon(achievement.badgeIcon)}
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold text-gray-900">{achievement.name}</h3>
                          <span className={`text-xs px-2 py-1 rounded-full ${getCategoryColor(achievement.category)}`}>
                            {achievement.category}
                          </span>
                        </div>
                        {isCompleted && (
                          <CheckCircle className="h-6 w-6 text-yellow-600" />
                        )}
                      </div>

                      {/* Description */}
                      <p className="text-gray-600 text-sm mb-4">{achievement.description}</p>

                      {/* Progress */}
                      <div className="mb-4">
                        <div className="flex items-center justify-between text-sm mb-2">
                          <span className="text-gray-600">Progress</span>
                          <span className="font-medium">
                            {progress.toLocaleString()} / {achievement.target.toLocaleString()}
                          </span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className={`h-2 rounded-full transition-all duration-300 ${
                              isCompleted ? 'bg-yellow-500' : 'bg-blue-500'
                            }`}
                            style={{ width: `${progressPercentage}%` }}
                          ></div>
                        </div>
                      </div>

                      {/* Points */}
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1">
                          <Star className="h-4 w-4 text-yellow-500" />
                          <span className="text-sm font-medium text-gray-900">
                            {achievement.points} points
                          </span>
                        </div>
                        {isCompleted && userAchievement?.completedAt && (
                          <span className="text-xs text-gray-500">
                            Completed {new Date(userAchievement.completedAt).toLocaleDateString()}
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        )}

        {/* Leaderboard Tab */}
        {activeTab === 'leaderboard' && (
          <div>
            {/* Period Filter */}
            <div className="mb-6">
              <div className="flex gap-2">
                {[
                  { value: 'all-time', label: 'All Time' },
                  { value: 'monthly', label: 'This Month' },
                  { value: 'weekly', label: 'This Week' },
                ].map((period) => (
                  <button
                    key={period.value}
                    onClick={() => setLeaderboardPeriod(period.value)}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                      leaderboardPeriod === period.value
                        ? 'bg-yellow-600 text-white'
                        : 'bg-white text-gray-700 hover:bg-gray-50 border border-gray-300'
                    }`}
                  >
                    {period.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Leaderboard */}
            <div className="bg-white rounded-lg shadow-sm overflow-hidden">
              <div className="p-6 border-b border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                  <Crown className="h-5 w-5 text-yellow-600" />
                  Top Performers
                </h3>
              </div>
              
              {leaderboard.length === 0 ? (
                <div className="text-center py-12">
                  <Crown className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500">No leaderboard data available yet.</p>
                </div>
              ) : (
                <div className="divide-y divide-gray-200">
                  {leaderboard.map((entry, index) => (
                    <div
                      key={entry.userId}
                      className={`p-6 flex items-center gap-4 ${
                        entry.userId === user?.id ? 'bg-yellow-50' : ''
                      }`}
                    >
                      {/* Rank */}
                      <div className="flex items-center justify-center w-8">
                        {index < 3 ? (
                          <div className={`p-2 rounded-full ${
                            index === 0 ? 'bg-yellow-100 text-yellow-600' :
                            index === 1 ? 'bg-gray-100 text-gray-600' :
                            'bg-orange-100 text-orange-600'
                          }`}>
                            {index === 0 ? <Crown className="h-4 w-4" /> :
                             index === 1 ? <Medal className="h-4 w-4" /> :
                             <Award className="h-4 w-4" />}
                          </div>
                        ) : (
                          <span className="text-lg font-bold text-gray-600">
                            {entry.rank}
                          </span>
                        )}
                      </div>

                      {/* User Info */}
                      <div className="flex-1">
                        <div className="flex items-center gap-3">
                          <div className="h-10 w-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-semibold">
                            {entry.userName.charAt(0).toUpperCase()}
                          </div>
                          <div>
                            <h4 className="font-medium text-gray-900">
                              {entry.userName}
                              {entry.userId === user?.id && (
                                <span className="ml-2 text-xs bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full">
                                  You
                                </span>
                              )}
                            </h4>
                            <p className="text-sm text-gray-600">{entry.userEmail}</p>
                          </div>
                        </div>
                      </div>

                      {/* Stats */}
                      <div className="text-right">
                        <div className="font-bold text-lg text-gray-900">
                          {entry.totalPoints.toLocaleString()}
                        </div>
                        <div className="text-sm text-gray-600">
                          Level {entry.level}
                        </div>
                      </div>

                      {/* Trend */}
                      <div className="w-8">
                        {index > 0 && (
                          <ArrowDown className="h-4 w-4 text-red-500" />
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Progress Tab */}
        {activeTab === 'progress' && (
          <div className="space-y-6">
            {/* Progress Overview */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white rounded-lg shadow-sm p-6">
                <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <Fire className="h-5 w-5 text-orange-600" />
                  Current Streak
                </h3>
                <div className="text-3xl font-bold text-orange-600 mb-2">
                  {userStats?.streakDays || 0} days
                </div>
                <p className="text-gray-600 text-sm">
                  Keep your momentum going! Complete tasks daily to maintain your streak.
                </p>
              </div>

              <div className="bg-white rounded-lg shadow-sm p-6">
                <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-blue-600" />
                  Weekly Progress
                </h3>
                <div className="text-3xl font-bold text-blue-600 mb-2">
                  {userStats?.weeklyPoints || 0}
                </div>
                <p className="text-gray-600 text-sm">
                  Points earned this week. Great job staying active!
                </p>
              </div>

              <div className="bg-white rounded-lg shadow-sm p-6">
                <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-green-600" />
                  Monthly Growth
                </h3>
                <div className="text-3xl font-bold text-green-600 mb-2">
                  {userStats?.monthlyPoints || 0}
                </div>
                <p className="text-gray-600 text-sm">
                  Total points this month. You're on track for success!
                </p>
              </div>
            </div>

            {/* Recent Achievements */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <Award className="h-5 w-5 text-purple-600" />
                Recent Achievements
              </h3>
              
              {userAchievements.filter(ua => ua.isCompleted).length === 0 ? (
                <div className="text-center py-8">
                  <Award className="h-12 w-12 text-gray-400 mx-auto mb-3" />
                  <p className="text-gray-500">No achievements completed yet. Keep working to unlock your first achievement!</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {userAchievements
                    .filter(ua => ua.isCompleted)
                    .sort((a, b) => new Date(b.completedAt!).getTime() - new Date(a.completedAt!).getTime())
                    .slice(0, 5)
                    .map((userAchievement) => {
                      const achievement = achievements.find(a => a.id === userAchievement.achievementId);
                      if (!achievement) return null;

                      return (
                        <div key={userAchievement.id} className="flex items-center gap-3 p-3 bg-yellow-50 rounded-lg">
                          <div className="p-2 bg-yellow-100 text-yellow-600 rounded-full">
                            {getAchievementIcon(achievement.badgeIcon)}
                          </div>
                          <div className="flex-1">
                            <h4 className="font-medium text-gray-900">{achievement.name}</h4>
                            <p className="text-sm text-gray-600">
                              Completed {new Date(userAchievement.completedAt!).toLocaleDateString()}
                            </p>
                          </div>
                          <div className="text-right">
                            <div className="flex items-center gap-1">
                              <Star className="h-4 w-4 text-yellow-500" />
                              <span className="font-medium text-gray-900">+{userAchievement.pointsAwarded}</span>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Rewards Tab */}
        {activeTab === 'rewards' && (
          <div className="space-y-6">
            {/* Available Rewards */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-semibold mb-6 flex items-center gap-2">
                <Gift className="h-5 w-5 text-pink-600" />
                Available Rewards
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[
                  {
                    id: '1',
                    name: 'Business Course Access',
                    description: 'Unlock premium business strategy courses',
                    cost: 5000,
                    type: 'course',
                    icon: <Award className="h-6 w-6" />,
                    color: 'bg-blue-500'
                  },
                  {
                    id: '2',
                    name: 'Profile Badge',
                    description: 'Show off your achievements with a special badge',
                    cost: 2500,
                    type: 'badge',
                    icon: <Medal className="h-6 w-6" />,
                    color: 'bg-purple-500'
                  },
                  {
                    id: '3',
                    name: 'Priority Support',
                    description: 'Get priority customer support for 30 days',
                    cost: 3000,
                    type: 'support',
                    icon: <Zap className="h-6 w-6" />,
                    color: 'bg-orange-500'
                  },
                  {
                    id: '4',
                    name: 'Advanced Analytics',
                    description: 'Unlock advanced analytics and insights',
                    cost: 4000,
                    type: 'feature',
                    icon: <BarChart3 className="h-6 w-6" />,
                    color: 'bg-green-500'
                  },
                ].map((reward) => {
                  const canAfford = (userStats?.totalPoints || 0) >= reward.cost;
                  
                  return (
                    <div
                      key={reward.id}
                      className={`border-2 rounded-lg p-6 transition-all ${
                        canAfford
                          ? 'border-green-200 bg-green-50'
                          : 'border-gray-200 bg-gray-50'
                      }`}
                    >
                      <div className="flex items-center gap-3 mb-4">
                        <div className={`p-3 rounded-full text-white ${reward.color}`}>
                          {reward.icon}
                        </div>
                        <div className="flex-1">
                          <h4 className="font-semibold text-gray-900">{reward.name}</h4>
                          <div className="flex items-center gap-1 mt-1">
                            <Star className="h-4 w-4 text-yellow-500" />
                            <span className="text-sm font-medium text-gray-900">
                              {reward.cost.toLocaleString()} points
                            </span>
                          </div>
                        </div>
                      </div>
                      
                      <p className="text-gray-600 text-sm mb-4">{reward.description}</p>
                      
                      <button
                        disabled={!canAfford}
                        className={`w-full py-2 px-4 rounded-lg text-sm font-medium transition-colors ${
                          canAfford
                            ? 'bg-green-600 text-white hover:bg-green-700'
                            : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                        }`}
                      >
                        {canAfford ? 'Redeem Reward' : 'Not Enough Points'}
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Point History */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-blue-600" />
                Points History
              </h3>
              
              <div className="text-center py-8">
                <BarChart3 className="h-12 w-12 text-gray-400 mx-auto mb-3" />
                <p className="text-gray-500">
                  Points history and detailed analytics will be displayed here.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Gamification;
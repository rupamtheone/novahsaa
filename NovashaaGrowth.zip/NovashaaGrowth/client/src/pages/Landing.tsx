import React from 'react';

const Landing: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-purple-900 to-indigo-900 flex items-center justify-center">
      <div className="max-w-4xl mx-auto px-6 text-center">
        <div className="mb-8">
          <h1 className="text-6xl font-bold text-white mb-6">
            Novashaa
          </h1>
          <p className="text-xl text-gray-200 mb-8 leading-relaxed">
            All-in-one platform for startups to manage tasks, campaigns, social media, 
            branding, and staff collaboration. Streamline your growth journey.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-12">
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 text-white">
            <div className="text-3xl mb-4">🎯</div>
            <h3 className="text-lg font-semibold mb-2">Task Management</h3>
            <p className="text-sm text-gray-300">
              Organize projects, assign tasks, track progress with intuitive workflows
            </p>
          </div>
          
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 text-white">
            <div className="text-3xl mb-4">📱</div>
            <h3 className="text-lg font-semibold mb-2">Social Media Planning</h3>
            <p className="text-sm text-gray-300">
              Plan, schedule, and manage your social media content across platforms
            </p>
          </div>
          
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 text-white">
            <div className="text-3xl mb-4">🎨</div>
            <h3 className="text-lg font-semibold mb-2">Brand Assets</h3>
            <p className="text-sm text-gray-300">
              Centralized hub for all your brand assets, logos, and creative materials
            </p>
          </div>
        </div>

        <div className="space-y-4">
          <a
            href="/api/login"
            className="inline-block bg-white text-blue-900 px-8 py-4 rounded-lg font-semibold text-lg hover:bg-gray-100 transition-colors duration-200 shadow-lg"
          >
            Get Started
          </a>
          <p className="text-sm text-gray-300">
            Join thousands of startups growing with Novashaa
          </p>
        </div>
      </div>
    </div>
  );
};

export default Landing;

import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '../lib/queryClient';
import { useAuth } from '../hooks/useAuth';
import { useToast } from '../hooks/use-toast';
import { isUnauthorizedError } from '../lib/authUtils';
import { 
  Users, 
  Star, 
  MapPin, 
  Clock, 
  DollarSign, 
  Award, 
  Eye, 
  MessageCircle,
  CheckCircle,
  Filter,
  Search,
  Plus,
  UserPlus,
  Briefcase,
  Globe,
  TrendingUp
} from 'lucide-react';

interface Freelancer {
  id: string;
  userId: string;
  title: string;
  bio: string;
  skills: string;
  hourlyRate: number;
  availability: string;
  portfolioUrl?: string;
  experience: number;
  rating: number;
  totalReviews: number;
  completedProjects: number;
  isVerified: boolean;
  createdAt: string;
}

interface FreelancerReview {
  id: string;
  rating: number;
  review: string;
  reviewerId: string;
  createdAt: string;
}

interface Task {
  id: string;
  title: string;
  description: string;
  status: string;
  priority: string;
  projectId: string;
}

const Marketplace: React.FC = () => {
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [activeTab, setActiveTab] = useState('browse');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSkill, setSelectedSkill] = useState('');
  const [selectedFreelancer, setSelectedFreelancer] = useState<Freelancer | null>(null);
  const [showCreateProfile, setShowCreateProfile] = useState(false);
  const [profileForm, setProfileForm] = useState({
    title: '',
    bio: '',
    skills: '',
    hourlyRate: '',
    experience: '',
    portfolioUrl: '',
    availability: 'available'
  });

  // Fetch freelancers
  const { data: freelancers = [], isLoading: loadingFreelancers } = useQuery<Freelancer[]>({
    queryKey: ['/api/freelancers'],
    queryFn: async () => {
      try {
        return await apiRequest('/api/freelancers');
      } catch (error: any) {
        if (isUnauthorizedError(error)) {
          toast({
            title: "Unauthorized",
            description: "You are logged out. Logging in again...",
            variant: "destructive",
          });
          setTimeout(() => {
            window.location.href = "/api/login";
          }, 500);
        }
        throw error;
      }
    },
  });

  // Fetch tasks for assignment
  const { data: tasks = [] } = useQuery<Task[]>({
    queryKey: ['/api/tasks'],
    queryFn: () => apiRequest('/api/tasks'),
  });

  // Fetch reviews for selected freelancer
  const { data: reviews = [] } = useQuery<FreelancerReview[]>({
    queryKey: ['/api/freelancers', selectedFreelancer?.id, 'reviews'],
    queryFn: () => apiRequest(`/api/freelancers/${selectedFreelancer?.id}/reviews`),
    enabled: !!selectedFreelancer?.id,
  });

  // Create freelancer profile mutation
  const createProfile = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest('/api/freelancers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...data,
          skills: data.skills.split(',').map((s: string) => s.trim()),
          hourlyRate: parseInt(data.hourlyRate),
          experience: parseInt(data.experience),
        }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/freelancers'] });
      setShowCreateProfile(false);
      setProfileForm({
        title: '',
        bio: '',
        skills: '',
        hourlyRate: '',
        experience: '',
        portfolioUrl: '',
        availability: 'available'
      });
      toast({
        title: "Profile Created!",
        description: "Your freelancer profile has been created successfully.",
      });
    },
    onError: (error: any) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create freelancer profile.",
        variant: "destructive",
      });
    },
  });

  // Assign task to freelancer mutation
  const assignTask = useMutation({
    mutationFn: async ({ taskId, freelancerId }: { taskId: string; freelancerId: string }) => {
      return await apiRequest(`/api/tasks/${taskId}/assign/${freelancerId}`, {
        method: 'PUT',
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      toast({
        title: "Task Assigned!",
        description: "Task has been assigned to the freelancer successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: "Failed to assign task.",
        variant: "destructive",
      });
    },
  });

  const filteredFreelancers = freelancers.filter(freelancer => {
    const matchesSearch = freelancer.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         freelancer.bio.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesSkill = !selectedSkill || 
                        (freelancer.skills && JSON.parse(freelancer.skills).includes(selectedSkill));
    return matchesSearch && matchesSkill;
  });

  const allSkills = Array.from(new Set(
    freelancers.flatMap(f => f.skills ? JSON.parse(f.skills) : [])
  ));

  const getRatingStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating / 100);
    const hasHalfStar = (rating % 100) >= 50;
    
    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />);
    }
    if (hasHalfStar) {
      stars.push(<Star key="half" className="h-4 w-4 fill-yellow-200 text-yellow-400" />);
    }
    for (let i = stars.length; i < 5; i++) {
      stars.push(<Star key={i} className="h-4 w-4 text-gray-300" />);
    }
    
    return stars;
  };

  const getAvailabilityColor = (availability: string) => {
    switch (availability) {
      case 'available': return 'bg-green-100 text-green-800';
      case 'busy': return 'bg-yellow-100 text-yellow-800';
      case 'unavailable': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Please log in to access Marketplace</h1>
          <button 
            onClick={() => window.location.href = '/api/login'}
            className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700"
          >
            Log In
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <Users className="h-8 w-8 text-blue-600" />
                <h1 className="text-3xl font-bold text-gray-900">Freelancer Marketplace</h1>
              </div>
              <p className="text-gray-600">
                Connect with talented freelancers and grow your business network.
              </p>
            </div>
            <button
              onClick={() => setShowCreateProfile(true)}
              className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 flex items-center gap-2"
            >
              <UserPlus className="h-4 w-4" />
              Create Profile
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex space-x-1 bg-gray-100 rounded-lg p-1 mb-8">
          <button
            onClick={() => setActiveTab('browse')}
            className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
              activeTab === 'browse'
                ? 'bg-white text-blue-600 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Search className="h-4 w-4 inline mr-2" />
            Browse Freelancers
          </button>
          <button
            onClick={() => setActiveTab('network')}
            className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
              activeTab === 'network'
                ? 'bg-white text-blue-600 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Globe className="h-4 w-4 inline mr-2" />
            My Network
          </button>
          <button
            onClick={() => setActiveTab('insights')}
            className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
              activeTab === 'insights'
                ? 'bg-white text-blue-600 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <TrendingUp className="h-4 w-4 inline mr-2" />
            Market Insights
          </button>
        </div>

        {/* Browse Freelancers Tab */}
        {activeTab === 'browse' && (
          <div>
            {/* Search and Filters */}
            <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="md:col-span-2">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                    <input
                      type="text"
                      placeholder="Search freelancers by name, skills, or expertise..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                </div>
                <div>
                  <select
                    value={selectedSkill}
                    onChange={(e) => setSelectedSkill(e.target.value)}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="">All Skills</option>
                    {allSkills.map(skill => (
                      <option key={skill} value={skill}>{skill}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            {/* Freelancer Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {loadingFreelancers ? (
                Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="bg-white rounded-lg shadow-sm p-6 animate-pulse">
                    <div className="flex items-center gap-4 mb-4">
                      <div className="h-12 w-12 bg-gray-200 rounded-full"></div>
                      <div className="flex-1">
                        <div className="h-4 bg-gray-200 rounded mb-2"></div>
                        <div className="h-3 bg-gray-200 rounded w-2/3"></div>
                      </div>
                    </div>
                    <div className="h-16 bg-gray-200 rounded mb-4"></div>
                    <div className="h-4 bg-gray-200 rounded mb-2"></div>
                    <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                  </div>
                ))
              ) : filteredFreelancers.length === 0 ? (
                <div className="col-span-full text-center py-12">
                  <Users className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No freelancers found</h3>
                  <p className="text-gray-500">Try adjusting your search criteria.</p>
                </div>
              ) : (
                filteredFreelancers.map((freelancer) => (
                  <div key={freelancer.id} className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow">
                    <div className="p-6">
                      {/* Header */}
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-center gap-3">
                          <div className="h-12 w-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-semibold">
                            {freelancer.title.charAt(0).toUpperCase()}
                          </div>
                          <div>
                            <h3 className="font-semibold text-gray-900">{freelancer.title}</h3>
                            <div className="flex items-center gap-2">
                              <div className="flex items-center">
                                {getRatingStars(freelancer.rating)}
                              </div>
                              <span className="text-sm text-gray-600">
                                ({freelancer.totalReviews} reviews)
                              </span>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          {freelancer.isVerified && (
                            <Award className="h-5 w-5 text-blue-600" />
                          )}
                          <span className={`text-xs px-2 py-1 rounded-full ${getAvailabilityColor(freelancer.availability)}`}>
                            {freelancer.availability}
                          </span>
                        </div>
                      </div>

                      {/* Bio */}
                      <p className="text-gray-600 text-sm mb-4 line-clamp-3">
                        {freelancer.bio}
                      </p>

                      {/* Skills */}
                      <div className="mb-4">
                        <div className="flex flex-wrap gap-1">
                          {freelancer.skills && JSON.parse(freelancer.skills).slice(0, 3).map((skill: string) => (
                            <span
                              key={skill}
                              className="text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded-full"
                            >
                              {skill}
                            </span>
                          ))}
                          {freelancer.skills && JSON.parse(freelancer.skills).length > 3 && (
                            <span className="text-xs text-gray-500">
                              +{JSON.parse(freelancer.skills).length - 3} more
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Stats */}
                      <div className="grid grid-cols-3 gap-4 mb-4 text-center">
                        <div>
                          <div className="text-lg font-semibold text-gray-900">
                            ${freelancer.hourlyRate}
                          </div>
                          <div className="text-xs text-gray-600">per hour</div>
                        </div>
                        <div>
                          <div className="text-lg font-semibold text-gray-900">
                            {freelancer.experience}
                          </div>
                          <div className="text-xs text-gray-600">years exp</div>
                        </div>
                        <div>
                          <div className="text-lg font-semibold text-gray-900">
                            {freelancer.completedProjects}
                          </div>
                          <div className="text-xs text-gray-600">projects</div>
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="flex gap-2">
                        <button
                          onClick={() => setSelectedFreelancer(freelancer)}
                          className="flex-1 bg-blue-600 text-white py-2 px-3 rounded-lg hover:bg-blue-700 text-sm flex items-center justify-center gap-2"
                        >
                          <Eye className="h-4 w-4" />
                          View Profile
                        </button>
                        <button className="flex-1 border border-gray-300 text-gray-700 py-2 px-3 rounded-lg hover:bg-gray-50 text-sm flex items-center justify-center gap-2">
                          <MessageCircle className="h-4 w-4" />
                          Message
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* Market Insights Tab */}
        {activeTab === 'insights' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="bg-gradient-to-r from-blue-500 to-blue-600 rounded-lg p-6 text-white">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-blue-100">Total Freelancers</p>
                    <p className="text-3xl font-bold">{freelancers.length}</p>
                  </div>
                  <Users className="h-12 w-12 text-blue-200" />
                </div>
              </div>
              
              <div className="bg-gradient-to-r from-green-500 to-green-600 rounded-lg p-6 text-white">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-green-100">Available Now</p>
                    <p className="text-3xl font-bold">
                      {freelancers.filter(f => f.availability === 'available').length}
                    </p>
                  </div>
                  <CheckCircle className="h-12 w-12 text-green-200" />
                </div>
              </div>
              
              <div className="bg-gradient-to-r from-purple-500 to-purple-600 rounded-lg p-6 text-white">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-purple-100">Avg Rate</p>
                    <p className="text-3xl font-bold">
                      ${freelancers.length > 0 
                        ? Math.round(freelancers.reduce((acc, f) => acc + f.hourlyRate, 0) / freelancers.length)
                        : 0
                      }
                    </p>
                  </div>
                  <DollarSign className="h-12 w-12 text-purple-200" />
                </div>
              </div>
              
              <div className="bg-gradient-to-r from-orange-500 to-orange-600 rounded-lg p-6 text-white">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-orange-100">Top Rated</p>
                    <p className="text-3xl font-bold">
                      {freelancers.filter(f => f.rating >= 400).length}
                    </p>
                  </div>
                  <Star className="h-12 w-12 text-orange-200" />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-white rounded-lg shadow-sm p-6">
                <h3 className="text-lg font-semibold mb-4">Popular Skills</h3>
                <div className="space-y-3">
                  {allSkills.slice(0, 10).map((skill) => {
                    const count = freelancers.filter(f => 
                      f.skills && JSON.parse(f.skills).includes(skill)
                    ).length;
                    const percentage = freelancers.length > 0 ? (count / freelancers.length) * 100 : 0;
                    
                    return (
                      <div key={skill} className="flex items-center justify-between">
                        <span className="text-gray-700">{skill}</span>
                        <div className="flex items-center gap-3">
                          <div className="w-24 bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-blue-600 h-2 rounded-full" 
                              style={{ width: `${percentage}%` }}
                            ></div>
                          </div>
                          <span className="text-sm text-gray-600 w-12">{count}</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="bg-white rounded-lg shadow-sm p-6">
                <h3 className="text-lg font-semibold mb-4">Experience Distribution</h3>
                <div className="space-y-3">
                  {[
                    { label: '0-2 years', min: 0, max: 2 },
                    { label: '3-5 years', min: 3, max: 5 },
                    { label: '6-10 years', min: 6, max: 10 },
                    { label: '10+ years', min: 11, max: 100 }
                  ].map((range) => {
                    const count = freelancers.filter(f => 
                      f.experience >= range.min && f.experience <= range.max
                    ).length;
                    const percentage = freelancers.length > 0 ? (count / freelancers.length) * 100 : 0;
                    
                    return (
                      <div key={range.label} className="flex items-center justify-between">
                        <span className="text-gray-700">{range.label}</span>
                        <div className="flex items-center gap-3">
                          <div className="w-24 bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-green-600 h-2 rounded-full" 
                              style={{ width: `${percentage}%` }}
                            ></div>
                          </div>
                          <span className="text-sm text-gray-600 w-12">{count}</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Freelancer Detail Modal */}
      {selectedFreelancer && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-4xl w-full max-h-screen overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="h-16 w-16 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white text-xl font-semibold">
                    {selectedFreelancer.title.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold text-gray-900">{selectedFreelancer.title}</h2>
                    <div className="flex items-center gap-2">
                      <div className="flex items-center">
                        {getRatingStars(selectedFreelancer.rating)}
                      </div>
                      <span className="text-gray-600">
                        ({selectedFreelancer.totalReviews} reviews)
                      </span>
                      {selectedFreelancer.isVerified && (
                        <Award className="h-5 w-5 text-blue-600" />
                      )}
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => setSelectedFreelancer(null)}
                  className="text-gray-400 hover:text-gray-600 text-2xl"
                >
                  ×
                </button>
              </div>
            </div>

            <div className="p-6">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                  <div className="mb-6">
                    <h3 className="text-lg font-semibold mb-3">About</h3>
                    <p className="text-gray-700">{selectedFreelancer.bio}</p>
                  </div>

                  <div className="mb-6">
                    <h3 className="text-lg font-semibold mb-3">Skills</h3>
                    <div className="flex flex-wrap gap-2">
                      {selectedFreelancer.skills && JSON.parse(selectedFreelancer.skills).map((skill: string) => (
                        <span
                          key={skill}
                          className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm"
                        >
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="mb-6">
                    <h3 className="text-lg font-semibold mb-3">Reviews</h3>
                    {reviews.length === 0 ? (
                      <p className="text-gray-500">No reviews yet.</p>
                    ) : (
                      <div className="space-y-4">
                        {reviews.slice(0, 3).map((review) => (
                          <div key={review.id} className="border border-gray-200 rounded-lg p-4">
                            <div className="flex items-center gap-2 mb-2">
                              {getRatingStars(review.rating * 100)}
                              <span className="text-sm text-gray-600">
                                {new Date(review.createdAt).toLocaleDateString()}
                              </span>
                            </div>
                            <p className="text-gray-700">{review.review}</p>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                <div>
                  <div className="bg-gray-50 rounded-lg p-6 mb-6">
                    <h3 className="text-lg font-semibold mb-4">Quick Stats</h3>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Hourly Rate:</span>
                        <span className="font-semibold">${selectedFreelancer.hourlyRate}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Experience:</span>
                        <span className="font-semibold">{selectedFreelancer.experience} years</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Completed:</span>
                        <span className="font-semibold">{selectedFreelancer.completedProjects} projects</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Availability:</span>
                        <span className={`px-2 py-1 rounded-full text-xs ${getAvailabilityColor(selectedFreelancer.availability)}`}>
                          {selectedFreelancer.availability}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <button className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 flex items-center justify-center gap-2">
                      <MessageCircle className="h-4 w-4" />
                      Send Message
                    </button>
                    
                    {tasks.length > 0 && (
                      <div>
                        <select 
                          className="w-full border border-gray-300 rounded-lg px-3 py-2 mb-2"
                          onChange={(e) => {
                            if (e.target.value) {
                              assignTask.mutate({
                                taskId: e.target.value,
                                freelancerId: selectedFreelancer.id
                              });
                            }
                          }}
                        >
                          <option value="">Assign a task...</option>
                          {tasks.filter(t => t.status !== 'completed').map(task => (
                            <option key={task.id} value={task.id}>
                              {task.title}
                            </option>
                          ))}
                        </select>
                      </div>
                    )}

                    {selectedFreelancer.portfolioUrl && (
                      <a
                        href={selectedFreelancer.portfolioUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-full border border-gray-300 text-gray-700 py-3 px-4 rounded-lg hover:bg-gray-50 flex items-center justify-center gap-2"
                      >
                        <Globe className="h-4 w-4" />
                        View Portfolio
                      </a>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Create Profile Modal */}
      {showCreateProfile && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-2xl w-full max-h-screen overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-gray-900">Create Freelancer Profile</h2>
                <button
                  onClick={() => setShowCreateProfile(false)}
                  className="text-gray-400 hover:text-gray-600 text-2xl"
                >
                  ×
                </button>
              </div>
            </div>

            <div className="p-6">
              <form onSubmit={(e) => {
                e.preventDefault();
                createProfile.mutate(profileForm);
              }} className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Professional Title
                  </label>
                  <input
                    type="text"
                    required
                    value={profileForm.title}
                    onChange={(e) => setProfileForm({...profileForm, title: e.target.value})}
                    placeholder="e.g., Full Stack Developer"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Bio
                  </label>
                  <textarea
                    required
                    value={profileForm.bio}
                    onChange={(e) => setProfileForm({...profileForm, bio: e.target.value})}
                    placeholder="Describe your experience and what you can offer..."
                    rows={4}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Hourly Rate ($)
                    </label>
                    <input
                      type="number"
                      required
                      value={profileForm.hourlyRate}
                      onChange={(e) => setProfileForm({...profileForm, hourlyRate: e.target.value})}
                      placeholder="50"
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Experience (years)
                    </label>
                    <input
                      type="number"
                      required
                      value={profileForm.experience}
                      onChange={(e) => setProfileForm({...profileForm, experience: e.target.value})}
                      placeholder="5"
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Skills (comma-separated)
                  </label>
                  <input
                    type="text"
                    required
                    value={profileForm.skills}
                    onChange={(e) => setProfileForm({...profileForm, skills: e.target.value})}
                    placeholder="React, Node.js, TypeScript, MongoDB"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Portfolio URL (optional)
                  </label>
                  <input
                    type="url"
                    value={profileForm.portfolioUrl}
                    onChange={(e) => setProfileForm({...profileForm, portfolioUrl: e.target.value})}
                    placeholder="https://myportfolio.com"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Availability
                  </label>
                  <select
                    value={profileForm.availability}
                    onChange={(e) => setProfileForm({...profileForm, availability: e.target.value})}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="available">Available</option>
                    <option value="busy">Busy</option>
                    <option value="unavailable">Unavailable</option>
                  </select>
                </div>

                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={() => setShowCreateProfile(false)}
                    className="flex-1 border border-gray-300 text-gray-700 py-3 px-4 rounded-lg hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={createProfile.isPending}
                    className="flex-1 bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 disabled:opacity-50"
                  >
                    {createProfile.isPending ? 'Creating...' : 'Create Profile'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Marketplace;
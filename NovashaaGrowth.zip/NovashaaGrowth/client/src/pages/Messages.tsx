import React, { useState, useEffect, useRef } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '../lib/queryClient';
import { useAuth } from '../hooks/useAuth';
import { useToast } from '../hooks/use-toast';
import { isUnauthorizedError } from '../lib/authUtils';
import { 
  MessageCircle,
  Send,
  Search,
  Users,
  Plus,
  Phone,
  Video,
  MoreVertical,
  Pin,
  Archive,
  Trash2,
  Edit,
  Reply,
  Forward,
  Smile,
  Paperclip,
  Image as ImageIcon,
  File,
  Check,
  CheckCheck,
  Clock,
  Circle,
  User
} from 'lucide-react';

interface Message {
  id: string;
  content: string;
  senderId: string;
  recipientId: string;
  conversationId: string;
  messageType: string;
  readAt?: string;
  editedAt?: string;
  replyToId?: string;
  attachments?: string;
  createdAt: string;
  updatedAt: string;
}

interface Conversation {
  id: string;
  type: string;
  name?: string;
  description?: string;
  participants: string;
  lastMessageAt: string;
  isArchived: boolean;
  isPinned: boolean;
  createdAt: string;
}

interface MessageUser {
  id: string;
  email: string;
  firstName?: string;
  lastName?: string;
  profileImageUrl?: string;
}

const Messages: React.FC = () => {
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(null);
  const [newMessage, setNewMessage] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [showNewChatModal, setShowNewChatModal] = useState(false);
  const [selectedUsers, setSelectedUsers] = useState<string[]>([]);
  const [chatName, setChatName] = useState('');
  const [chatType, setChatType] = useState<'direct' | 'group'>('direct');

  // Fetch conversations
  const { data: conversations = [], isLoading: loadingConversations } = useQuery<Conversation[]>({
    queryKey: ['/api/conversations'],
    queryFn: async () => {
      try {
        return await apiRequest('/api/conversations');
      } catch (error: any) {
        if (isUnauthorizedError(error)) {
          toast({
            title: "Unauthorized",
            description: "You are logged out. Logging in again...",
            variant: "destructive",
          });
          setTimeout(() => {
            window.location.href = "/api/login";
          }, 500);
        }
        throw error;
      }
    },
  });

  // Fetch messages for selected conversation
  const { data: messages = [], isLoading: loadingMessages } = useQuery<Message[]>({
    queryKey: ['/api/messages', selectedConversation?.id],
    queryFn: () => apiRequest(`/api/conversations/${selectedConversation?.id}/messages`),
    enabled: !!selectedConversation?.id,
    refetchInterval: 5000, // Poll for new messages every 5 seconds
  });

  // Fetch users for new chat
  const { data: users = [] } = useQuery<MessageUser[]>({
    queryKey: ['/api/users'],
    queryFn: () => apiRequest('/api/users'),
    enabled: showNewChatModal,
  });

  // Send message mutation
  const sendMessage = useMutation({
    mutationFn: async (data: { content: string; recipientId?: string; conversationId?: string }) => {
      return await apiRequest('/api/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/messages', selectedConversation?.id] });
      queryClient.invalidateQueries({ queryKey: ['/api/conversations'] });
      setNewMessage('');
      scrollToBottom();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: "Failed to send message.",
        variant: "destructive",
      });
    },
  });

  // Create conversation mutation
  const createConversation = useMutation({
    mutationFn: async (data: { type: string; participants: string[]; name?: string }) => {
      return await apiRequest('/api/conversations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
    },
    onSuccess: (newConversation) => {
      queryClient.invalidateQueries({ queryKey: ['/api/conversations'] });
      setSelectedConversation(newConversation);
      setShowNewChatModal(false);
      setSelectedUsers([]);
      setChatName('');
      toast({
        title: "Chat Created!",
        description: "New conversation has been started.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: "Failed to create conversation.",
        variant: "destructive",
      });
    },
  });

  // Mark messages as read mutation
  const markAsRead = useMutation({
    mutationFn: async (conversationId: string) => {
      return await apiRequest(`/api/conversations/${conversationId}/mark-read`, {
        method: 'POST',
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/conversations'] });
    },
  });

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    if (messages.length > 0) {
      scrollToBottom();
    }
  }, [messages]);

  useEffect(() => {
    if (selectedConversation) {
      markAsRead.mutate(selectedConversation.id);
    }
  }, [selectedConversation]);

  const handleSendMessage = () => {
    if (!newMessage.trim() || !selectedConversation) return;

    sendMessage.mutate({
      content: newMessage.trim(),
      conversationId: selectedConversation.id,
    });
  };

  const handleCreateChat = () => {
    if (chatType === 'direct' && selectedUsers.length !== 1) {
      toast({
        title: "Error",
        description: "Please select exactly one user for direct chat.",
        variant: "destructive",
      });
      return;
    }

    if (chatType === 'group' && (selectedUsers.length < 2 || !chatName.trim())) {
      toast({
        title: "Error",
        description: "Please select at least 2 users and provide a group name.",
        variant: "destructive",
      });
      return;
    }

    createConversation.mutate({
      type: chatType,
      participants: selectedUsers,
      name: chatType === 'group' ? chatName : undefined,
    });
  };

  const filteredConversations = conversations.filter(conv =>
    conv.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    searchQuery === ''
  );

  const getConversationName = (conversation: Conversation) => {
    if (conversation.name) return conversation.name;
    // For direct chats, show the other participant's name
    const participants = JSON.parse(conversation.participants);
    const otherParticipant = participants.find((p: string) => p !== user?.id);
    const otherUser = users.find(u => u.id === otherParticipant);
    return otherUser ? `${otherUser.firstName} ${otherUser.lastName}` : 'Unknown User';
  };

  const getMessageSender = (senderId: string) => {
    if (senderId === user?.id) return 'You';
    const sender = users.find(u => u.id === senderId);
    return sender ? `${sender.firstName} ${sender.lastName}` : 'Unknown';
  };

  const formatMessageTime = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const isToday = date.toDateString() === now.toDateString();
    
    if (isToday) {
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } else {
      return date.toLocaleDateString();
    }
  };

  const getMessageStatus = (message: Message) => {
    if (message.senderId !== user?.id) return null;
    
    if (message.readAt) {
      return <CheckCheck className="h-4 w-4 text-blue-500" />;
    } else {
      return <Check className="h-4 w-4 text-gray-400" />;
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Please log in to access Messages</h1>
          <button 
            onClick={() => window.location.href = '/api/login'}
            className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700"
          >
            Log In
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <div className="w-80 bg-white border-r border-gray-200 flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-xl font-semibold text-gray-900 flex items-center gap-2">
              <MessageCircle className="h-6 w-6 text-blue-600" />
              Messages
            </h1>
            <button
              onClick={() => setShowNewChatModal(true)}
              className="bg-blue-600 text-white p-2 rounded-lg hover:bg-blue-700"
            >
              <Plus className="h-4 w-4" />
            </button>
          </div>
          
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <input
              type="text"
              placeholder="Search conversations..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
            />
          </div>
        </div>

        {/* Conversations List */}
        <div className="flex-1 overflow-y-auto">
          {loadingConversations ? (
            <div className="p-4 space-y-3">
              {Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="animate-pulse">
                  <div className="flex items-center gap-3 p-3">
                    <div className="h-10 w-10 bg-gray-200 rounded-full"></div>
                    <div className="flex-1">
                      <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                      <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : filteredConversations.length === 0 ? (
            <div className="p-8 text-center">
              <MessageCircle className="h-12 w-12 text-gray-400 mx-auto mb-3" />
              <p className="text-gray-500 mb-4">No conversations yet</p>
              <button
                onClick={() => setShowNewChatModal(true)}
                className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 text-sm"
              >
                Start a conversation
              </button>
            </div>
          ) : (
            <div className="space-y-1">
              {filteredConversations.map((conversation) => (
                <div
                  key={conversation.id}
                  onClick={() => setSelectedConversation(conversation)}
                  className={`p-3 hover:bg-gray-50 cursor-pointer border-l-4 transition-colors ${
                    selectedConversation?.id === conversation.id
                      ? 'bg-blue-50 border-blue-500'
                      : 'border-transparent'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="relative">
                      <div className="h-10 w-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-semibold">
                        {conversation.type === 'group' ? (
                          <Users className="h-5 w-5" />
                        ) : (
                          getConversationName(conversation).charAt(0).toUpperCase()
                        )}
                      </div>
                      {conversation.isPinned && (
                        <Pin className="absolute -top-1 -right-1 h-3 w-3 text-blue-600 fill-current" />
                      )}
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <h3 className="font-medium text-gray-900 truncate">
                          {getConversationName(conversation)}
                        </h3>
                        <span className="text-xs text-gray-500">
                          {formatMessageTime(conversation.lastMessageAt)}
                        </span>
                      </div>
                      
                      <p className="text-sm text-gray-500 truncate">
                        {conversation.type === 'group' ? `${JSON.parse(conversation.participants).length} members` : 'Direct message'}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col">
        {selectedConversation ? (
          <>
            {/* Chat Header */}
            <div className="bg-white border-b border-gray-200 p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-semibold">
                    {selectedConversation.type === 'group' ? (
                      <Users className="h-5 w-5" />
                    ) : (
                      getConversationName(selectedConversation).charAt(0).toUpperCase()
                    )}
                  </div>
                  <div>
                    <h2 className="font-semibold text-gray-900">
                      {getConversationName(selectedConversation)}
                    </h2>
                    <p className="text-sm text-gray-500">
                      {selectedConversation.type === 'group' 
                        ? `${JSON.parse(selectedConversation.participants).length} members`
                        : 'Online'
                      }
                    </p>
                  </div>
                </div>
                
                <div className="flex items-center gap-2">
                  <button className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-lg">
                    <Phone className="h-4 w-4" />
                  </button>
                  <button className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-lg">
                    <Video className="h-4 w-4" />
                  </button>
                  <button className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-lg">
                    <MoreVertical className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {loadingMessages ? (
                <div className="space-y-4">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <div key={i} className="animate-pulse">
                      <div className={`flex ${i % 2 === 0 ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-xs ${i % 2 === 0 ? 'bg-gray-200' : 'bg-gray-100'} rounded-lg p-3`}>
                          <div className="h-4 bg-gray-300 rounded w-3/4 mb-2"></div>
                          <div className="h-3 bg-gray-300 rounded w-1/2"></div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : messages.length === 0 ? (
                <div className="text-center py-8">
                  <MessageCircle className="h-12 w-12 text-gray-400 mx-auto mb-3" />
                  <p className="text-gray-500">No messages yet. Start the conversation!</p>
                </div>
              ) : (
                messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex ${message.senderId === user?.id ? 'justify-end' : 'justify-start'}`}
                  >
                    <div className={`max-w-xs lg:max-w-md ${
                      message.senderId === user?.id
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-100 text-gray-900'
                    } rounded-lg p-3`}>
                      {selectedConversation.type === 'group' && message.senderId !== user?.id && (
                        <p className="text-xs font-medium mb-1 opacity-70">
                          {getMessageSender(message.senderId)}
                        </p>
                      )}
                      
                      <p className="text-sm">{message.content}</p>
                      
                      <div className="flex items-center justify-between mt-2">
                        <span className="text-xs opacity-70">
                          {formatMessageTime(message.createdAt)}
                        </span>
                        {getMessageStatus(message)}
                      </div>
                      
                      {message.editedAt && (
                        <p className="text-xs opacity-70 mt-1">edited</p>
                      )}
                    </div>
                  </div>
                ))
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Message Input */}
            <div className="bg-white border-t border-gray-200 p-4">
              <div className="flex items-center gap-3">
                <button className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-lg">
                  <Paperclip className="h-4 w-4" />
                </button>
                <button className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-lg">
                  <ImageIcon className="h-4 w-4" />
                </button>
                
                <div className="flex-1 relative">
                  <input
                    type="text"
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                    placeholder="Type a message..."
                    className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                
                <button className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-lg">
                  <Smile className="h-4 w-4" />
                </button>
                
                <button
                  onClick={handleSendMessage}
                  disabled={!newMessage.trim() || sendMessage.isPending}
                  className="bg-blue-600 text-white p-2 rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <Send className="h-4 w-4" />
                </button>
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <MessageCircle className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No conversation selected</h3>
              <p className="text-gray-500 mb-6">Choose a conversation from the sidebar or start a new one.</p>
              <button
                onClick={() => setShowNewChatModal(true)}
                className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 flex items-center gap-2 mx-auto"
              >
                <Plus className="h-4 w-4" />
                New Conversation
              </button>
            </div>
          </div>
        )}
      </div>

      {/* New Chat Modal */}
      {showNewChatModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-md w-full">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold text-gray-900">New Conversation</h2>
                <button
                  onClick={() => setShowNewChatModal(false)}
                  className="text-gray-400 hover:text-gray-600 text-2xl"
                >
                  ×
                </button>
              </div>
            </div>

            <div className="p-6">
              {/* Chat Type Selection */}
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Conversation Type
                </label>
                <div className="flex gap-2">
                  <button
                    onClick={() => setChatType('direct')}
                    className={`flex-1 py-2 px-4 rounded-lg text-sm font-medium transition-colors ${
                      chatType === 'direct'
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    Direct Message
                  </button>
                  <button
                    onClick={() => setChatType('group')}
                    className={`flex-1 py-2 px-4 rounded-lg text-sm font-medium transition-colors ${
                      chatType === 'group'
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    Group Chat
                  </button>
                </div>
              </div>

              {/* Group Name (only for group chats) */}
              {chatType === 'group' && (
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Group Name
                  </label>
                  <input
                    type="text"
                    value={chatName}
                    onChange={(e) => setChatName(e.target.value)}
                    placeholder="Enter group name..."
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              )}

              {/* User Selection */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {chatType === 'direct' ? 'Select User' : 'Select Members'}
                </label>
                <div className="max-h-40 overflow-y-auto border border-gray-300 rounded-lg">
                  {users.filter(u => u.id !== user?.id).map((u) => (
                    <label
                      key={u.id}
                      className="flex items-center gap-3 p-3 hover:bg-gray-50 cursor-pointer"
                    >
                      <input
                        type={chatType === 'direct' ? 'radio' : 'checkbox'}
                        name={chatType === 'direct' ? 'selectedUser' : undefined}
                        checked={selectedUsers.includes(u.id)}
                        onChange={(e) => {
                          if (chatType === 'direct') {
                            setSelectedUsers(e.target.checked ? [u.id] : []);
                          } else {
                            setSelectedUsers(prev => 
                              e.target.checked 
                                ? [...prev, u.id]
                                : prev.filter(id => id !== u.id)
                            );
                          }
                        }}
                        className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                      />
                      <div className="h-8 w-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white text-sm font-semibold">
                        {(u.firstName || 'U').charAt(0).toUpperCase()}
                      </div>
                      <span className="text-sm text-gray-900">
                        {u.firstName} {u.lastName} ({u.email})
                      </span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => setShowNewChatModal(false)}
                  className="flex-1 border border-gray-300 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  onClick={handleCreateChat}
                  disabled={createConversation.isPending || selectedUsers.length === 0}
                  className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 disabled:opacity-50"
                >
                  {createConversation.isPending ? 'Creating...' : 'Start Chat'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Messages;
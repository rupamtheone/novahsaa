import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '../hooks/useAuth';
import { useToast } from '../hooks/use-toast';
import { isUnauthorizedError } from '../lib/authUtils';
import { apiRequest } from '../lib/queryClient';

const SocialMedia: React.FC = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [filter, setFilter] = useState({ platform: '', status: '', projectId: '' });

  // Fetch social media content and projects
  const { data: content = [], isLoading: contentLoading } = useQuery({
    queryKey: ['/api/social-media'],
    queryFn: () => apiRequest('/api/social-media'),
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => window.location.href = "/api/login", 500);
      }
    }
  });

  const { data: projects = [] } = useQuery({
    queryKey: ['/api/projects'],
    queryFn: () => apiRequest('/api/projects'),
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => window.location.href = "/api/login", 500);
      }
    }
  });

  // Create content mutation
  const createContentMutation = useMutation({
    mutationFn: (contentData: any) => apiRequest('/api/social-media', {
      method: 'POST',
      data: contentData,
    }),
    onSuccess: () => {
      queryClient.invalidateQueries(['/api/social-media']);
      setShowCreateForm(false);
      toast({
        title: "Success",
        description: "Content created successfully",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => window.location.href = "/api/login", 500);
        return;
      }
      toast({
        title: "Error",
        description: error.message || "Failed to create content",
        variant: "destructive",
      });
    }
  });

  // Update content mutation
  const updateContentMutation = useMutation({
    mutationFn: ({ id, ...contentData }: any) => apiRequest(`/api/social-media/${id}`, {
      method: 'PUT',
      data: contentData,
    }),
    onSuccess: () => {
      queryClient.invalidateQueries(['/api/social-media']);
      toast({
        title: "Success",
        description: "Content updated successfully",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => window.location.href = "/api/login", 500);
        return;
      }
      toast({
        title: "Error",
        description: error.message || "Failed to update content",
        variant: "destructive",
      });
    }
  });

  const handleCreateContent = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const contentData = {
      title: formData.get('title'),
      content: formData.get('content'),
      platform: formData.get('platform'),
      projectId: formData.get('projectId') || null,
      scheduledDate: formData.get('scheduledDate') || null,
    };
    createContentMutation.mutate(contentData);
  };

  const handleStatusUpdate = (id: string, status: string) => {
    updateContentMutation.mutate({ id, status });
  };

  // Filter content
  const filteredContent = content.filter((item: any) => {
    if (filter.platform && item.platform !== filter.platform) return false;
    if (filter.status && item.status !== filter.status) return false;
    if (filter.projectId && item.projectId !== filter.projectId) return false;
    return true;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'published': return 'bg-green-100 text-green-800';
      case 'scheduled': return 'bg-blue-100 text-blue-800';
      case 'draft': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPlatformIcon = (platform: string) => {
    switch (platform) {
      case 'instagram': return '📷';
      case 'facebook': return '📘';
      case 'linkedin': return '💼';
      case 'youtube': return '📺';
      case 'twitter': return '🐦';
      default: return '📱';
    }
  };

  if (contentLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-900"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Social Media Planner</h1>
        <button
          onClick={() => setShowCreateForm(!showCreateForm)}
          className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700"
        >
          Create Content
        </button>
      </div>

      {/* Stats */}
      <div className="grid md:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="text-2xl font-bold text-gray-600">{content.length}</div>
          <p className="text-sm font-medium text-gray-500">Total Content</p>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="text-2xl font-bold text-blue-600">
            {content.filter((c: any) => c.status === 'scheduled').length}
          </div>
          <p className="text-sm font-medium text-gray-500">Scheduled</p>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="text-2xl font-bold text-green-600">
            {content.filter((c: any) => c.status === 'published').length}
          </div>
          <p className="text-sm font-medium text-gray-500">Published</p>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="text-2xl font-bold text-gray-600">
            {content.filter((c: any) => c.status === 'draft').length}
          </div>
          <p className="text-sm font-medium text-gray-500">Drafts</p>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg shadow p-4">
        <div className="grid md:grid-cols-3 gap-4">
          <select
            value={filter.platform}
            onChange={(e) => setFilter({ ...filter, platform: e.target.value })}
            className="border rounded-md px-3 py-2"
          >
            <option value="">All Platforms</option>
            <option value="instagram">Instagram</option>
            <option value="facebook">Facebook</option>
            <option value="linkedin">LinkedIn</option>
            <option value="youtube">YouTube</option>
            <option value="twitter">Twitter</option>
          </select>

          <select
            value={filter.status}
            onChange={(e) => setFilter({ ...filter, status: e.target.value })}
            className="border rounded-md px-3 py-2"
          >
            <option value="">All Statuses</option>
            <option value="draft">Draft</option>
            <option value="scheduled">Scheduled</option>
            <option value="published">Published</option>
          </select>

          <select
            value={filter.projectId}
            onChange={(e) => setFilter({ ...filter, projectId: e.target.value })}
            className="border rounded-md px-3 py-2"
          >
            <option value="">All Projects</option>
            {projects.map((project: any) => (
              <option key={project.id} value={project.id}>
                {project.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Create Content Form */}
      {showCreateForm && (
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-lg font-medium mb-4">Create Social Media Content</h2>
          <form onSubmit={handleCreateContent} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Title *
              </label>
              <input
                type="text"
                name="title"
                required
                className="w-full border rounded-md px-3 py-2"
                placeholder="Enter content title"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Content *
              </label>
              <textarea
                name="content"
                rows={4}
                required
                className="w-full border rounded-md px-3 py-2"
                placeholder="Enter your social media content, captions, hashtags..."
              />
            </div>

            <div className="grid md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Platform *
                </label>
                <select name="platform" required className="w-full border rounded-md px-3 py-2">
                  <option value="">Select Platform</option>
                  <option value="instagram">Instagram</option>
                  <option value="facebook">Facebook</option>
                  <option value="linkedin">LinkedIn</option>
                  <option value="youtube">YouTube</option>
                  <option value="twitter">Twitter</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Project
                </label>
                <select name="projectId" className="w-full border rounded-md px-3 py-2">
                  <option value="">No Project</option>
                  {projects.map((project: any) => (
                    <option key={project.id} value={project.id}>
                      {project.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Schedule Date
                </label>
                <input
                  type="datetime-local"
                  name="scheduledDate"
                  className="w-full border rounded-md px-3 py-2"
                />
              </div>
            </div>

            <div className="flex space-x-2">
              <button
                type="submit"
                disabled={createContentMutation.isLoading}
                className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 disabled:opacity-50"
              >
                {createContentMutation.isLoading ? 'Creating...' : 'Create Content'}
              </button>
              <button
                type="button"
                onClick={() => setShowCreateForm(false)}
                className="bg-gray-300 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-400"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Content List */}
      <div className="bg-white rounded-lg shadow">
        <div className="px-6 py-4 border-b border-gray-200">
          <h2 className="text-lg font-medium text-gray-900">Content Calendar</h2>
        </div>
        <div className="p-6">
          {filteredContent.length === 0 ? (
            <p className="text-gray-500 text-center py-8">No content found</p>
          ) : (
            <div className="space-y-4">
              {filteredContent.map((item: any) => (
                <div key={item.id} className="border rounded-lg p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <span className="text-xl">{getPlatformIcon(item.platform)}</span>
                        <h3 className="font-medium text-gray-900">{item.title}</h3>
                        <span className={`px-2 py-1 text-xs rounded-full ${getStatusColor(item.status)}`}>
                          {item.status}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600 mb-3 line-clamp-3">{item.content}</p>
                      <div className="flex items-center justify-between">
                        <div className="text-xs text-gray-500">
                          Created: {new Date(item.createdAt).toLocaleDateString()}
                        </div>
                        {item.scheduledDate && (
                          <div className="text-xs text-blue-600">
                            Scheduled: {new Date(item.scheduledDate).toLocaleString()}
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="flex flex-col space-y-2 ml-4">
                      {item.status === 'draft' && (
                        <button
                          onClick={() => handleStatusUpdate(item.id, 'scheduled')}
                          className="bg-blue-100 text-blue-800 px-3 py-1 rounded text-xs hover:bg-blue-200"
                        >
                          Schedule
                        </button>
                      )}
                      {item.status === 'scheduled' && (
                        <button
                          onClick={() => handleStatusUpdate(item.id, 'published')}
                          className="bg-green-100 text-green-800 px-3 py-1 rounded text-xs hover:bg-green-200"
                        >
                          Mark Published
                        </button>
                      )}
                      <span className="text-xs text-gray-500 capitalize">{item.platform}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Note about mock integration */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <div className="flex items-center">
          <div className="text-blue-600 mr-3">ℹ️</div>
          <div>
            <h3 className="text-sm font-medium text-blue-800">Social Media Integration</h3>
            <p className="text-xs text-blue-600 mt-1">
              This is a content planning interface. Actual posting to social media platforms requires API integration setup.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SocialMedia;

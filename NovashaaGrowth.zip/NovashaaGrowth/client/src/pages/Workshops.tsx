import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '../lib/queryClient';
import { useAuth } from '../hooks/useAuth';
import { useToast } from '../hooks/use-toast';
import { isUnauthorizedError } from '../lib/authUtils';
import { 
  Calendar,
  Clock,
  Users,
  MapPin,
  Video,
  BookOpen,
  Plus,
  Filter,
  Search,
  Eye,
  UserPlus,
  Star,
  Play,
  Download,
  Share2,
  Award,
  CheckCircle,
  AlertCircle,
  TrendingUp,
  Globe,
  Mic,
  Camera,
  Monitor
} from 'lucide-react';

interface Workshop {
  id: string;
  title: string;
  description: string;
  category: string;
  instructor: string;
  dateTime: string;
  duration: number;
  capacity: number;
  registeredCount: number;
  price?: number;
  location?: string;
  isOnline: boolean;
  meetingUrl?: string;
  materials?: string;
  requirements?: string;
  tags?: string;
  status: string;
  createdBy: string;
  createdAt: string;
}

interface WorkshopRegistration {
  id: string;
  workshopId: string;
  userId: string;
  registeredAt: string;
  attended?: boolean;
  rating?: number;
  feedback?: string;
}

const Workshops: React.FC = () => {
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [activeTab, setActiveTab] = useState('browse');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedWorkshop, setSelectedWorkshop] = useState<Workshop | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [workshopForm, setWorkshopForm] = useState({
    title: '',
    description: '',
    category: 'business',
    instructor: '',
    dateTime: '',
    duration: 60,
    capacity: 50,
    price: '',
    location: '',
    isOnline: true,
    meetingUrl: '',
    materials: '',
    requirements: '',
    tags: ''
  });

  // Fetch workshops
  const { data: workshops = [], isLoading: loadingWorkshops } = useQuery<Workshop[]>({
    queryKey: ['/api/workshops', selectedCategory],
    queryFn: async () => {
      try {
        const url = selectedCategory !== 'all' ? `/api/workshops?category=${selectedCategory}` : '/api/workshops';
        return await apiRequest(url);
      } catch (error: any) {
        if (isUnauthorizedError(error)) {
          toast({
            title: "Unauthorized",
            description: "You are logged out. Logging in again...",
            variant: "destructive",
          });
          setTimeout(() => {
            window.location.href = "/api/login";
          }, 500);
        }
        throw error;
      }
    },
  });

  // Fetch user's registrations
  const { data: registrations = [] } = useQuery<WorkshopRegistration[]>({
    queryKey: ['/api/workshop-registrations'],
    queryFn: () => apiRequest('/api/workshop-registrations'),
  });

  // Create workshop mutation
  const createWorkshop = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest('/api/workshops', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...data,
          duration: parseInt(data.duration),
          capacity: parseInt(data.capacity),
          price: data.price ? parseFloat(data.price) : null,
          tags: data.tags ? data.tags.split(',').map((t: string) => t.trim()) : [],
        }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/workshops'] });
      setShowCreateModal(false);
      setWorkshopForm({
        title: '',
        description: '',
        category: 'business',
        instructor: '',
        dateTime: '',
        duration: 60,
        capacity: 50,
        price: '',
        location: '',
        isOnline: true,
        meetingUrl: '',
        materials: '',
        requirements: '',
        tags: ''
      });
      toast({
        title: "Workshop Created!",
        description: "Your workshop has been scheduled successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: "Failed to create workshop.",
        variant: "destructive",
      });
    },
  });

  // Register for workshop mutation
  const registerForWorkshop = useMutation({
    mutationFn: async (workshopId: string) => {
      return await apiRequest(`/api/workshops/${workshopId}/register`, {
        method: 'POST',
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/workshops'] });
      queryClient.invalidateQueries({ queryKey: ['/api/workshop-registrations'] });
      toast({
        title: "Registration Successful!",
        description: "You have been registered for the workshop.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Registration Failed",
        description: "Unable to register for this workshop.",
        variant: "destructive",
      });
    },
  });

  const filteredWorkshops = workshops.filter(workshop =>
    workshop.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    workshop.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
    workshop.instructor.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const categories = [
    { value: 'all', label: 'All Categories' },
    { value: 'business', label: 'Business Strategy' },
    { value: 'marketing', label: 'Marketing' },
    { value: 'technology', label: 'Technology' },
    { value: 'design', label: 'Design' },
    { value: 'finance', label: 'Finance' },
    { value: 'leadership', label: 'Leadership' },
    { value: 'product', label: 'Product Management' },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'upcoming': return 'bg-blue-100 text-blue-800';
      case 'ongoing': return 'bg-green-100 text-green-800';
      case 'completed': return 'bg-gray-100 text-gray-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getCategoryColor = (category: string) => {
    const colors = {
      business: 'bg-blue-100 text-blue-800',
      marketing: 'bg-purple-100 text-purple-800',
      technology: 'bg-green-100 text-green-800',
      design: 'bg-pink-100 text-pink-800',
      finance: 'bg-yellow-100 text-yellow-800',
      leadership: 'bg-indigo-100 text-indigo-800',
      product: 'bg-orange-100 text-orange-800',
    };
    return colors[category as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  const isRegistered = (workshopId: string) => {
    return registrations.some(reg => reg.workshopId === workshopId);
  };

  const formatDuration = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    if (hours > 0) {
      return mins > 0 ? `${hours}h ${mins}m` : `${hours}h`;
    }
    return `${mins}m`;
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Please log in to access Workshops</h1>
          <button 
            onClick={() => window.location.href = '/api/login'}
            className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700"
          >
            Log In
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <BookOpen className="h-8 w-8 text-indigo-600" />
                <h1 className="text-3xl font-bold text-gray-900">Workshops & Webinars</h1>
              </div>
              <p className="text-gray-600">
                Discover and join educational workshops to grow your skills and network with professionals.
              </p>
            </div>
            <button
              onClick={() => setShowCreateModal(true)}
              className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 flex items-center gap-2"
            >
              <Plus className="h-4 w-4" />
              Create Workshop
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex space-x-1 bg-gray-100 rounded-lg p-1 mb-8">
          <button
            onClick={() => setActiveTab('browse')}
            className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
              activeTab === 'browse'
                ? 'bg-white text-indigo-600 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Search className="h-4 w-4 inline mr-2" />
            Browse Workshops
          </button>
          <button
            onClick={() => setActiveTab('my-workshops')}
            className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
              activeTab === 'my-workshops'
                ? 'bg-white text-indigo-600 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Calendar className="h-4 w-4 inline mr-2" />
            My Workshops
          </button>
          <button
            onClick={() => setActiveTab('calendar')}
            className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
              activeTab === 'calendar'
                ? 'bg-white text-indigo-600 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Calendar className="h-4 w-4 inline mr-2" />
            Calendar View
          </button>
        </div>

        {/* Search and Filters */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="md:col-span-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                <input
                  type="text"
                  placeholder="Search workshops by title, instructor, or description..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                />
              </div>
            </div>
            <div>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              >
                {categories.map(cat => (
                  <option key={cat.value} value={cat.value}>{cat.label}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Browse Workshops Tab */}
        {activeTab === 'browse' && (
          <div>
            {loadingWorkshops ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="bg-white rounded-lg shadow-sm p-6 animate-pulse">
                    <div className="h-6 bg-gray-200 rounded mb-4"></div>
                    <div className="h-4 bg-gray-200 rounded mb-3 w-3/4"></div>
                    <div className="h-16 bg-gray-200 rounded mb-4"></div>
                    <div className="flex gap-2">
                      <div className="h-8 bg-gray-200 rounded flex-1"></div>
                      <div className="h-8 bg-gray-200 rounded w-16"></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : filteredWorkshops.length === 0 ? (
              <div className="text-center py-12">
                <BookOpen className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No workshops found</h3>
                <p className="text-gray-500 mb-6">Try adjusting your search criteria or create a new workshop.</p>
                <button
                  onClick={() => setShowCreateModal(true)}
                  className="bg-indigo-600 text-white px-6 py-3 rounded-lg hover:bg-indigo-700 flex items-center gap-2 mx-auto"
                >
                  <Plus className="h-4 w-4" />
                  Create Workshop
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredWorkshops.map((workshop) => (
                  <div key={workshop.id} className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow">
                    <div className="p-6">
                      {/* Header */}
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex-1">
                          <h3 className="font-semibold text-gray-900 mb-2">{workshop.title}</h3>
                          <div className="flex items-center gap-2 mb-2">
                            <span className={`text-xs px-2 py-1 rounded-full ${getCategoryColor(workshop.category)}`}>
                              {workshop.category}
                            </span>
                            <span className={`text-xs px-2 py-1 rounded-full ${getStatusColor(workshop.status)}`}>
                              {workshop.status}
                            </span>
                          </div>
                        </div>
                        {workshop.price && (
                          <div className="text-right">
                            <div className="text-lg font-bold text-indigo-600">${workshop.price}</div>
                          </div>
                        )}
                      </div>

                      {/* Instructor */}
                      <div className="flex items-center gap-2 mb-3">
                        <Users className="h-4 w-4 text-gray-500" />
                        <span className="text-sm text-gray-600">by {workshop.instructor}</span>
                      </div>

                      {/* Description */}
                      <p className="text-gray-600 text-sm mb-4 line-clamp-3">{workshop.description}</p>

                      {/* Details */}
                      <div className="space-y-2 mb-4 text-sm">
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-gray-500" />
                          <span>{new Date(workshop.dateTime).toLocaleDateString()}</span>
                          <Clock className="h-4 w-4 text-gray-500 ml-2" />
                          <span>{new Date(workshop.dateTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                        </div>
                        
                        <div className="flex items-center gap-2">
                          <Clock className="h-4 w-4 text-gray-500" />
                          <span>{formatDuration(workshop.duration)}</span>
                          {workshop.isOnline ? (
                            <>
                              <Video className="h-4 w-4 text-gray-500 ml-2" />
                              <span>Online</span>
                            </>
                          ) : (
                            <>
                              <MapPin className="h-4 w-4 text-gray-500 ml-2" />
                              <span>{workshop.location}</span>
                            </>
                          )}
                        </div>

                        <div className="flex items-center gap-2">
                          <Users className="h-4 w-4 text-gray-500" />
                          <span>{workshop.registeredCount} / {workshop.capacity} registered</span>
                          <div className="flex-1 bg-gray-200 rounded-full h-1 ml-2">
                            <div 
                              className="bg-indigo-600 h-1 rounded-full" 
                              style={{ width: `${(workshop.registeredCount / workshop.capacity) * 100}%` }}
                            ></div>
                          </div>
                        </div>
                      </div>

                      {/* Tags */}
                      {workshop.tags && (
                        <div className="mb-4">
                          <div className="flex flex-wrap gap-1">
                            {JSON.parse(workshop.tags).slice(0, 3).map((tag: string) => (
                              <span
                                key={tag}
                                className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded-full"
                              >
                                {tag}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Actions */}
                      <div className="flex gap-2">
                        <button
                          onClick={() => setSelectedWorkshop(workshop)}
                          className="flex-1 bg-indigo-600 text-white py-2 px-3 rounded-lg hover:bg-indigo-700 text-sm flex items-center justify-center gap-1"
                        >
                          <Eye className="h-4 w-4" />
                          View Details
                        </button>
                        {!isRegistered(workshop.id) && workshop.registeredCount < workshop.capacity ? (
                          <button
                            onClick={() => registerForWorkshop.mutate(workshop.id)}
                            disabled={registerForWorkshop.isPending}
                            className="border border-indigo-600 text-indigo-600 py-2 px-3 rounded-lg hover:bg-indigo-50 text-sm flex items-center justify-center gap-1"
                          >
                            <UserPlus className="h-4 w-4" />
                            {registerForWorkshop.isPending ? 'Registering...' : 'Register'}
                          </button>
                        ) : (
                          <div className="border border-green-600 text-green-600 py-2 px-3 rounded-lg text-sm flex items-center justify-center gap-1">
                            <CheckCircle className="h-4 w-4" />
                            {isRegistered(workshop.id) ? 'Registered' : 'Full'}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* My Workshops Tab */}
        {activeTab === 'my-workshops' && (
          <div>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
              <div className="bg-gradient-to-r from-indigo-500 to-indigo-600 rounded-lg p-6 text-white">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-indigo-100">Registered</p>
                    <p className="text-3xl font-bold">{registrations.length}</p>
                  </div>
                  <Calendar className="h-12 w-12 text-indigo-200" />
                </div>
              </div>
              
              <div className="bg-gradient-to-r from-green-500 to-green-600 rounded-lg p-6 text-white">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-green-100">Attended</p>
                    <p className="text-3xl font-bold">
                      {registrations.filter(r => r.attended).length}
                    </p>
                  </div>
                  <CheckCircle className="h-12 w-12 text-green-200" />
                </div>
              </div>
              
              <div className="bg-gradient-to-r from-purple-500 to-purple-600 rounded-lg p-6 text-white">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-purple-100">Upcoming</p>
                    <p className="text-3xl font-bold">
                      {workshops.filter(w => 
                        isRegistered(w.id) && new Date(w.dateTime) > new Date()
                      ).length}
                    </p>
                  </div>
                  <Clock className="h-12 w-12 text-purple-200" />
                </div>
              </div>
              
              <div className="bg-gradient-to-r from-orange-500 to-orange-600 rounded-lg p-6 text-white">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-orange-100">Certificates</p>
                    <p className="text-3xl font-bold">
                      {registrations.filter(r => r.attended && r.rating).length}
                    </p>
                  </div>
                  <Award className="h-12 w-12 text-orange-200" />
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-semibold mb-4">My Registered Workshops</h3>
              {registrations.length === 0 ? (
                <div className="text-center py-8">
                  <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500">You haven't registered for any workshops yet.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {registrations.map((registration) => {
                    const workshop = workshops.find(w => w.id === registration.workshopId);
                    if (!workshop) return null;
                    
                    return (
                      <div key={registration.id} className="border border-gray-200 rounded-lg p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex-1">
                            <h4 className="font-semibold text-gray-900">{workshop.title}</h4>
                            <p className="text-sm text-gray-600 mb-2">by {workshop.instructor}</p>
                            <div className="flex items-center gap-4 text-sm text-gray-500">
                              <div className="flex items-center gap-1">
                                <Calendar className="h-4 w-4" />
                                <span>{new Date(workshop.dateTime).toLocaleDateString()}</span>
                              </div>
                              <div className="flex items-center gap-1">
                                <Clock className="h-4 w-4" />
                                <span>{new Date(workshop.dateTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                              </div>
                              {workshop.isOnline && (
                                <div className="flex items-center gap-1">
                                  <Video className="h-4 w-4" />
                                  <span>Online</span>
                                </div>
                              )}
                            </div>
                          </div>
                          <div className="flex items-center gap-3">
                            {registration.attended ? (
                              <span className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm">
                                Attended
                              </span>
                            ) : new Date(workshop.dateTime) < new Date() ? (
                              <span className="bg-gray-100 text-gray-800 px-3 py-1 rounded-full text-sm">
                                Missed
                              </span>
                            ) : (
                              <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm">
                                Upcoming
                              </span>
                            )}
                            {workshop.isOnline && workshop.meetingUrl && new Date(workshop.dateTime) > new Date() && (
                              <a
                                href={workshop.meetingUrl}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="bg-indigo-600 text-white px-3 py-1 rounded-lg text-sm hover:bg-indigo-700 flex items-center gap-1"
                              >
                                <Play className="h-3 w-3" />
                                Join
                              </a>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Calendar View Tab */}
        {activeTab === 'calendar' && (
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h3 className="text-lg font-semibold mb-6">Workshop Calendar</h3>
            <div className="text-center py-12">
              <Calendar className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">Calendar view will be implemented with a calendar library.</p>
              <p className="text-gray-400 text-sm mt-2">This would show all workshops in a monthly/weekly calendar format.</p>
            </div>
          </div>
        )}
      </div>

      {/* Workshop Detail Modal */}
      {selectedWorkshop && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-4xl w-full max-h-screen overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-2xl font-bold text-gray-900">{selectedWorkshop.title}</h2>
                  <div className="flex items-center gap-3 mt-2">
                    <span className={`text-sm px-3 py-1 rounded-full ${getCategoryColor(selectedWorkshop.category)}`}>
                      {selectedWorkshop.category}
                    </span>
                    <span className={`text-sm px-3 py-1 rounded-full ${getStatusColor(selectedWorkshop.status)}`}>
                      {selectedWorkshop.status}
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => setSelectedWorkshop(null)}
                  className="text-gray-400 hover:text-gray-600 text-2xl"
                >
                  ×
                </button>
              </div>
            </div>

            <div className="p-6">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Main Content */}
                <div className="lg:col-span-2">
                  <div className="mb-6">
                    <h3 className="text-lg font-semibold mb-3">Description</h3>
                    <p className="text-gray-700">{selectedWorkshop.description}</p>
                  </div>

                  {selectedWorkshop.materials && (
                    <div className="mb-6">
                      <h3 className="text-lg font-semibold mb-3">Materials Provided</h3>
                      <p className="text-gray-700">{selectedWorkshop.materials}</p>
                    </div>
                  )}

                  {selectedWorkshop.requirements && (
                    <div className="mb-6">
                      <h3 className="text-lg font-semibold mb-3">Requirements</h3>
                      <p className="text-gray-700">{selectedWorkshop.requirements}</p>
                    </div>
                  )}

                  {selectedWorkshop.tags && (
                    <div className="mb-6">
                      <h3 className="text-lg font-semibold mb-3">Topics Covered</h3>
                      <div className="flex flex-wrap gap-2">
                        {JSON.parse(selectedWorkshop.tags).map((tag: string) => (
                          <span
                            key={tag}
                            className="bg-indigo-100 text-indigo-800 px-3 py-1 rounded-full text-sm"
                          >
                            {tag}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Sidebar */}
                <div>
                  <div className="bg-gray-50 rounded-lg p-6 mb-6">
                    <h3 className="text-lg font-semibold mb-4">Workshop Details</h3>
                    <div className="space-y-3">
                      <div className="flex items-center gap-3">
                        <Users className="h-5 w-5 text-gray-500" />
                        <div>
                          <div className="font-medium">Instructor</div>
                          <div className="text-sm text-gray-600">{selectedWorkshop.instructor}</div>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <Calendar className="h-5 w-5 text-gray-500" />
                        <div>
                          <div className="font-medium">Date & Time</div>
                          <div className="text-sm text-gray-600">
                            {new Date(selectedWorkshop.dateTime).toLocaleDateString()} at{' '}
                            {new Date(selectedWorkshop.dateTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <Clock className="h-5 w-5 text-gray-500" />
                        <div>
                          <div className="font-medium">Duration</div>
                          <div className="text-sm text-gray-600">{formatDuration(selectedWorkshop.duration)}</div>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        {selectedWorkshop.isOnline ? (
                          <Video className="h-5 w-5 text-gray-500" />
                        ) : (
                          <MapPin className="h-5 w-5 text-gray-500" />
                        )}
                        <div>
                          <div className="font-medium">Location</div>
                          <div className="text-sm text-gray-600">
                            {selectedWorkshop.isOnline ? 'Online' : selectedWorkshop.location}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <Users className="h-5 w-5 text-gray-500" />
                        <div>
                          <div className="font-medium">Capacity</div>
                          <div className="text-sm text-gray-600">
                            {selectedWorkshop.registeredCount} / {selectedWorkshop.capacity} registered
                          </div>
                        </div>
                      </div>

                      {selectedWorkshop.price && (
                        <div className="flex items-center gap-3">
                          <div className="text-2xl font-bold text-indigo-600">${selectedWorkshop.price}</div>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="space-y-3">
                    {!isRegistered(selectedWorkshop.id) && selectedWorkshop.registeredCount < selectedWorkshop.capacity ? (
                      <button
                        onClick={() => registerForWorkshop.mutate(selectedWorkshop.id)}
                        disabled={registerForWorkshop.isPending}
                        className="w-full bg-indigo-600 text-white py-3 px-4 rounded-lg hover:bg-indigo-700 flex items-center justify-center gap-2"
                      >
                        <UserPlus className="h-4 w-4" />
                        {registerForWorkshop.isPending ? 'Registering...' : 'Register for Workshop'}
                      </button>
                    ) : (
                      <div className="w-full bg-green-100 text-green-800 py-3 px-4 rounded-lg flex items-center justify-center gap-2">
                        <CheckCircle className="h-4 w-4" />
                        {isRegistered(selectedWorkshop.id) ? 'Already Registered' : 'Workshop Full'}
                      </div>
                    )}

                    <button className="w-full border border-gray-300 text-gray-700 py-3 px-4 rounded-lg hover:bg-gray-50 flex items-center justify-center gap-2">
                      <Share2 className="h-4 w-4" />
                      Share Workshop
                    </button>

                    {selectedWorkshop.isOnline && selectedWorkshop.meetingUrl && isRegistered(selectedWorkshop.id) && (
                      <a
                        href={selectedWorkshop.meetingUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-full border border-indigo-600 text-indigo-600 py-3 px-4 rounded-lg hover:bg-indigo-50 flex items-center justify-center gap-2"
                      >
                        <Play className="h-4 w-4" />
                        Join Online Session
                      </a>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Create Workshop Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-3xl w-full max-h-screen overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-gray-900">Create New Workshop</h2>
                <button
                  onClick={() => setShowCreateModal(false)}
                  className="text-gray-400 hover:text-gray-600 text-2xl"
                >
                  ×
                </button>
              </div>
            </div>

            <div className="p-6">
              <form onSubmit={(e) => {
                e.preventDefault();
                createWorkshop.mutate(workshopForm);
              }} className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Workshop Title
                    </label>
                    <input
                      type="text"
                      required
                      value={workshopForm.title}
                      onChange={(e) => setWorkshopForm({...workshopForm, title: e.target.value})}
                      placeholder="e.g., Digital Marketing Essentials"
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Category
                    </label>
                    <select
                      value={workshopForm.category}
                      onChange={(e) => setWorkshopForm({...workshopForm, category: e.target.value})}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    >
                      {categories.filter(c => c.value !== 'all').map(cat => (
                        <option key={cat.value} value={cat.value}>{cat.label}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Description
                  </label>
                  <textarea
                    required
                    value={workshopForm.description}
                    onChange={(e) => setWorkshopForm({...workshopForm, description: e.target.value})}
                    placeholder="Describe what participants will learn..."
                    rows={4}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-transparent resize-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Instructor Name
                    </label>
                    <input
                      type="text"
                      required
                      value={workshopForm.instructor}
                      onChange={(e) => setWorkshopForm({...workshopForm, instructor: e.target.value})}
                      placeholder="Your name or instructor name"
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Date & Time
                    </label>
                    <input
                      type="datetime-local"
                      required
                      value={workshopForm.dateTime}
                      onChange={(e) => setWorkshopForm({...workshopForm, dateTime: e.target.value})}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Duration (minutes)
                    </label>
                    <input
                      type="number"
                      required
                      value={workshopForm.duration}
                      onChange={(e) => setWorkshopForm({...workshopForm, duration: parseInt(e.target.value)})}
                      placeholder="60"
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Capacity
                    </label>
                    <input
                      type="number"
                      required
                      value={workshopForm.capacity}
                      onChange={(e) => setWorkshopForm({...workshopForm, capacity: parseInt(e.target.value)})}
                      placeholder="50"
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Price ($) - Optional
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      value={workshopForm.price}
                      onChange={(e) => setWorkshopForm({...workshopForm, price: e.target.value})}
                      placeholder="0.00"
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex items-center gap-3 mb-4">
                    <input
                      type="checkbox"
                      id="isOnline"
                      checked={workshopForm.isOnline}
                      onChange={(e) => setWorkshopForm({...workshopForm, isOnline: e.target.checked})}
                      className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                    />
                    <label htmlFor="isOnline" className="text-sm font-medium text-gray-700">
                      This is an online workshop
                    </label>
                  </div>

                  {workshopForm.isOnline ? (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Meeting URL
                      </label>
                      <input
                        type="url"
                        value={workshopForm.meetingUrl}
                        onChange={(e) => setWorkshopForm({...workshopForm, meetingUrl: e.target.value})}
                        placeholder="https://zoom.us/j/..."
                        className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                      />
                    </div>
                  ) : (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Location
                      </label>
                      <input
                        type="text"
                        required={!workshopForm.isOnline}
                        value={workshopForm.location}
                        onChange={(e) => setWorkshopForm({...workshopForm, location: e.target.value})}
                        placeholder="Street address or venue name"
                        className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                      />
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Tags (comma-separated)
                  </label>
                  <input
                    type="text"
                    value={workshopForm.tags}
                    onChange={(e) => setWorkshopForm({...workshopForm, tags: e.target.value})}
                    placeholder="entrepreneurship, startups, business strategy"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Materials Provided
                    </label>
                    <textarea
                      value={workshopForm.materials}
                      onChange={(e) => setWorkshopForm({...workshopForm, materials: e.target.value})}
                      placeholder="List any materials, slides, or resources included..."
                      rows={3}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-transparent resize-none"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Requirements
                    </label>
                    <textarea
                      value={workshopForm.requirements}
                      onChange={(e) => setWorkshopForm({...workshopForm, requirements: e.target.value})}
                      placeholder="Any prerequisites or required materials..."
                      rows={3}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-transparent resize-none"
                    />
                  </div>
                </div>

                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={() => setShowCreateModal(false)}
                    className="flex-1 border border-gray-300 text-gray-700 py-3 px-4 rounded-lg hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={createWorkshop.isPending}
                    className="flex-1 bg-indigo-600 text-white py-3 px-4 rounded-lg hover:bg-indigo-700 disabled:opacity-50"
                  >
                    {createWorkshop.isPending ? 'Creating...' : 'Create Workshop'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Workshops;
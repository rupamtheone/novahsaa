export interface User {
  id: string;
  email: string | null;
  firstName: string | null;
  lastName: string | null;
  profileImageUrl: string | null;
  role: 'admin' | 'staff' | 'client';
  createdAt: string;
  updatedAt: string;
}

export interface Project {
  id: string;
  name: string;
  description: string | null;
  clientId: string | null;
  status: 'active' | 'completed' | 'paused';
  createdAt: string;
  updatedAt: string;
}

export interface Task {
  id: string;
  title: string;
  description: string | null;
  status: 'pending' | 'in_progress' | 'completed';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  assignedTo: string | null;
  projectId: string | null;
  dueDate: string | null;
  createdBy: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface TaskAttachment {
  id: string;
  taskId: string | null;
  fileName: string;
  filePath: string;
  fileSize: number | null;
  mimeType: string | null;
  uploadedBy: string | null;
  createdAt: string;
}

export interface SocialMediaContent {
  id: string;
  title: string;
  content: string | null;
  platform: 'instagram' | 'facebook' | 'linkedin' | 'youtube' | 'twitter' | null;
  scheduledDate: string | null;
  status: 'draft' | 'scheduled' | 'published';
  projectId: string | null;
  createdBy: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface BrandAsset {
  id: string;
  name: string;
  description: string | null;
  filePath: string;
  fileSize: number | null;
  mimeType: string | null;
  category: 'logo' | 'image' | 'video' | 'document' | null;
  projectId: string | null;
  isApproved: boolean | null;
  uploadedBy: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface Comment {
  id: string;
  content: string;
  entityType: string;
  entityId: string;
  authorId: string | null;
  createdAt: string;
  updatedAt: string;
}

export type FilterState = {
  [key: string]: string;
};

export interface ApiResponse<T> {
  data: T;
  message?: string;
}

export interface ApiError {
  message: string;
  status?: number;
}

# Novashaa - All-in-One Business Platform

## Overview

Novashaa is a comprehensive business management platform designed for startups to manage tasks, campaigns, social media, branding, and staff collaboration. The application supports multiple user roles (admin, staff, client) with role-based access control and features project management, task tracking, social media content planning, and brand asset management.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **React 19** with TypeScript for type safety and modern component architecture
- **Vite** as the build tool and development server with hot module replacement
- **React Router DOM v7** for client-side routing with role-based navigation
- **TanStack React Query v5** for server state management, caching, and data synchronization
- **Tailwind CSS v4** for utility-first styling with custom components
- Component-based architecture with reusable UI components and hooks

### Backend Architecture
- **Express.js** server with TypeScript for API endpoints and middleware
- **Drizzle ORM** for database operations with PostgreSQL schema definitions
- RESTful API design with role-based route protection
- File upload handling with Multer for brand assets and task attachments
- Session-based authentication using Express Session with PostgreSQL store

### Database Architecture
- **PostgreSQL** as the primary database with Neon serverless hosting
- **Drizzle ORM** for type-safe database operations and schema management
- Relational data model with proper foreign key relationships
- Tables: users, projects, tasks, task_attachments, social_media_content, brand_assets, comments, sessions
- Role-based data access patterns (admin sees all, clients see their projects only)

### Authentication System
- **Replit OpenID Connect (OIDC)** integration for user authentication
- **Passport.js** with OpenID Connect strategy for authentication middleware
- Session management with PostgreSQL-backed session store using connect-pg-simple
- Role-based authorization with three tiers: admin, staff, and client
- Secure session handling with HTTP-only cookies and CSRF protection

### File Management
- **Multer** for handling file uploads with size limits (10MB)
- Local file storage with organized directory structure
- File metadata tracking in database (filename, size, mime type)
- Static file serving for uploaded assets

## External Dependencies

### Database Services
- **Neon Database** - Serverless PostgreSQL hosting with connection pooling
- WebSocket support for real-time database connections using the `ws` library

### Authentication Services  
- **Replit OIDC** - OpenID Connect provider for user authentication
- Replit-specific user claims and profile information integration

### Development Tools
- **Drizzle Kit** - Database migration and schema management tool
- **TSX** - TypeScript execution for development and build processes

### UI Libraries
- **Lucide React** - Icon library for consistent iconography
- **Class Variance Authority (CVA)** - For component variant management
- **CLSX** - Utility for conditional CSS class names
- **Tailwind Merge** - For merging Tailwind CSS classes intelligently

### Utility Libraries
- **Memoizee** - Function memoization for performance optimization
- **Autoprefixer** and **PostCSS** - CSS processing and vendor prefixing

### TypeScript Support
- Comprehensive type definitions for all major dependencies
- Custom type definitions in shared schema for database models
- Full-stack type safety from database to UI components
import type { Express } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import path from "path";
import fs from "fs";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";

// Configure multer for file uploads
const uploadDir = 'uploads';
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const upload = multer({
  dest: uploadDir,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Serve uploaded files
  app.use('/uploads', require('express').static('uploads'));

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Projects routes
  app.get('/api/projects', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      let projects;
      if (user?.role === 'admin') {
        projects = await storage.getProjects();
      } else if (user?.role === 'client') {
        projects = await storage.getProjects().then(p => p.filter(proj => proj.clientId === userId));
      } else {
        projects = await storage.getProjects();
      }
      
      res.json(projects);
    } catch (error) {
      console.error("Error fetching projects:", error);
      res.status(500).json({ message: "Failed to fetch projects" });
    }
  });

  app.post('/api/projects', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Only admins can create projects" });
      }
      
      const project = await storage.createProject({
        ...req.body,
        createdAt: new Date(),
        updatedAt: new Date(),
      });
      res.json(project);
    } catch (error) {
      console.error("Error creating project:", error);
      res.status(500).json({ message: "Failed to create project" });
    }
  });

  // Tasks routes
  app.get('/api/tasks', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      const { projectId } = req.query;
      
      let tasks;
      if (user?.role === 'admin') {
        tasks = await storage.getTasks(projectId);
      } else if (user?.role === 'client') {
        // Clients can only see tasks from their projects
        const userProjects = await storage.getProjects().then(p => p.filter(proj => proj.clientId === userId));
        const projectIds = userProjects.map(p => p.id);
        tasks = await storage.getTasks().then(t => t.filter(task => task.projectId && projectIds.includes(task.projectId)));
      } else {
        // Staff can see assigned tasks or all tasks
        tasks = await storage.getTasks(projectId);
      }
      
      res.json(tasks);
    } catch (error) {
      console.error("Error fetching tasks:", error);
      res.status(500).json({ message: "Failed to fetch tasks" });
    }
  });

  app.post('/api/tasks', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const task = await storage.createTask({
        ...req.body,
        createdBy: userId,
        createdAt: new Date(),
        updatedAt: new Date(),
      });
      res.json(task);
    } catch (error) {
      console.error("Error creating task:", error);
      res.status(500).json({ message: "Failed to create task" });
    }
  });

  app.put('/api/tasks/:id', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const task = await storage.updateTask(id, {
        ...req.body,
        updatedAt: new Date(),
      });
      res.json(task);
    } catch (error) {
      console.error("Error updating task:", error);
      res.status(500).json({ message: "Failed to update task" });
    }
  });

  app.delete('/api/tasks/:id', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      await storage.deleteTask(id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting task:", error);
      res.status(500).json({ message: "Failed to delete task" });
    }
  });

  // Task attachments routes
  app.post('/api/tasks/:taskId/attachments', isAuthenticated, upload.single('file'), async (req: any, res) => {
    try {
      const { taskId } = req.params;
      const userId = req.user.claims.sub;
      
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const attachment = await storage.createTaskAttachment({
        taskId,
        fileName: req.file.originalname,
        filePath: req.file.path,
        fileSize: req.file.size,
        mimeType: req.file.mimetype,
        uploadedBy: userId,
      });
      
      res.json(attachment);
    } catch (error) {
      console.error("Error uploading attachment:", error);
      res.status(500).json({ message: "Failed to upload attachment" });
    }
  });

  app.get('/api/tasks/:taskId/attachments', isAuthenticated, async (req: any, res) => {
    try {
      const { taskId } = req.params;
      const attachments = await storage.getTaskAttachments(taskId);
      res.json(attachments);
    } catch (error) {
      console.error("Error fetching attachments:", error);
      res.status(500).json({ message: "Failed to fetch attachments" });
    }
  });

  // Social media content routes
  app.get('/api/social-media', isAuthenticated, async (req: any, res) => {
    try {
      const { projectId } = req.query;
      const content = await storage.getSocialMediaContent(projectId);
      res.json(content);
    } catch (error) {
      console.error("Error fetching social media content:", error);
      res.status(500).json({ message: "Failed to fetch social media content" });
    }
  });

  app.post('/api/social-media', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const content = await storage.createSocialMediaContent({
        ...req.body,
        createdBy: userId,
        createdAt: new Date(),
        updatedAt: new Date(),
      });
      res.json(content);
    } catch (error) {
      console.error("Error creating social media content:", error);
      res.status(500).json({ message: "Failed to create social media content" });
    }
  });

  app.put('/api/social-media/:id', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const content = await storage.updateSocialMediaContent(id, {
        ...req.body,
        updatedAt: new Date(),
      });
      res.json(content);
    } catch (error) {
      console.error("Error updating social media content:", error);
      res.status(500).json({ message: "Failed to update social media content" });
    }
  });

  // Brand assets routes
  app.get('/api/brand-assets', isAuthenticated, async (req: any, res) => {
    try {
      const { projectId } = req.query;
      const assets = await storage.getBrandAssets(projectId);
      res.json(assets);
    } catch (error) {
      console.error("Error fetching brand assets:", error);
      res.status(500).json({ message: "Failed to fetch brand assets" });
    }
  });

  app.post('/api/brand-assets', isAuthenticated, upload.single('file'), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const asset = await storage.createBrandAsset({
        name: req.body.name || req.file.originalname,
        description: req.body.description,
        filePath: req.file.path,
        fileSize: req.file.size,
        mimeType: req.file.mimetype,
        category: req.body.category,
        projectId: req.body.projectId,
        uploadedBy: userId,
      });
      
      res.json(asset);
    } catch (error) {
      console.error("Error uploading brand asset:", error);
      res.status(500).json({ message: "Failed to upload brand asset" });
    }
  });

  app.put('/api/brand-assets/:id', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const asset = await storage.updateBrandAsset(id, {
        ...req.body,
        updatedAt: new Date(),
      });
      res.json(asset);
    } catch (error) {
      console.error("Error updating brand asset:", error);
      res.status(500).json({ message: "Failed to update brand asset" });
    }
  });

  // Comments routes
  app.get('/api/comments', isAuthenticated, async (req: any, res) => {
    try {
      const { entityType, entityId } = req.query;
      const comments = await storage.getComments(entityType, entityId);
      res.json(comments);
    } catch (error) {
      console.error("Error fetching comments:", error);
      res.status(500).json({ message: "Failed to fetch comments" });
    }
  });

  app.post('/api/comments', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const comment = await storage.createComment({
        ...req.body,
        authorId: userId,
        createdAt: new Date(),
        updatedAt: new Date(),
      });
      res.json(comment);
    } catch (error) {
      console.error("Error creating comment:", error);
      res.status(500).json({ message: "Failed to create comment" });
    }
  });

  // Learning Resources API (Startup Growth Hub)
  app.get('/api/learning-resources', isAuthenticated, async (req, res) => {
    try {
      const category = req.query.category as string;
      const resources = await storage.getLearningResources(category);
      res.json(resources);
    } catch (error) {
      console.error('Error fetching learning resources:', error);
      res.status(500).json({ message: 'Failed to fetch learning resources' });
    }
  });

  app.post('/api/learning-resources', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const resourceData = { ...req.body, authorId: userId };
      const resource = await storage.createLearningResource(resourceData);
      res.json(resource);
    } catch (error) {
      console.error('Error creating learning resource:', error);
      res.status(500).json({ message: 'Failed to create learning resource' });
    }
  });

  // AI Business Assistant API
  app.get('/api/ai-suggestions', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const type = req.query.type as string;
      const suggestions = await storage.getAiSuggestions(userId, type);
      res.json(suggestions);
    } catch (error) {
      console.error('Error fetching AI suggestions:', error);
      res.status(500).json({ message: 'Failed to fetch AI suggestions' });
    }
  });

  app.post('/api/ai-suggestions/generate', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { type, prompt, platform, projectId } = req.body;
      
      // Smart AI suggestion generation
      let suggestion = '';
      if (type === 'caption') {
        suggestion = `🚀 ${prompt} #startup #growth #innovation #business`;
      } else if (type === 'hashtag') {
        suggestion = '#startup #business #growth #innovation #tech #entrepreneurship';
      } else if (type === 'content') {
        suggestion = `Exciting insights about ${prompt}! Let's discuss how this can accelerate your business growth. 💡`;
      }

      const aiSuggestion = await storage.createAiSuggestion({
        type,
        prompt,
        suggestion,
        platform,
        userId,
        projectId,
      });
      
      res.json(aiSuggestion);
    } catch (error) {
      console.error('Error generating AI suggestion:', error);
      res.status(500).json({ message: 'Failed to generate AI suggestion' });
    }
  });

  // Freelancer Marketplace API
  app.get('/api/freelancers', isAuthenticated, async (req, res) => {
    try {
      const skills = req.query.skills as string[];
      const freelancers = await storage.getFreelancers(skills);
      res.json(freelancers);
    } catch (error) {
      console.error('Error fetching freelancers:', error);
      res.status(500).json({ message: 'Failed to fetch freelancers' });
    }
  });

  app.post('/api/freelancers', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const freelancerData = { ...req.body, userId };
      const freelancer = await storage.createFreelancer(freelancerData);
      res.json(freelancer);
    } catch (error) {
      console.error('Error creating freelancer profile:', error);
      res.status(500).json({ message: 'Failed to create freelancer profile' });
    }
  });

  app.put('/api/tasks/:taskId/assign/:freelancerId', isAuthenticated, async (req, res) => {
    try {
      const { taskId, freelancerId } = req.params;
      const task = await storage.assignTaskToFreelancer(taskId, freelancerId);
      res.json(task);
    } catch (error) {
      console.error('Error assigning task to freelancer:', error);
      res.status(500).json({ message: 'Failed to assign task to freelancer' });
    }
  });

  // Campaign Management API
  app.get('/api/campaigns', isAuthenticated, async (req, res) => {
    try {
      const projectId = req.query.projectId as string;
      const campaigns = await storage.getCampaigns(projectId);
      res.json(campaigns);
    } catch (error) {
      console.error('Error fetching campaigns:', error);
      res.status(500).json({ message: 'Failed to fetch campaigns' });
    }
  });

  app.post('/api/campaigns', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const campaignData = { ...req.body, createdBy: userId };
      const campaign = await storage.createCampaign(campaignData);
      res.json(campaign);
    } catch (error) {
      console.error('Error creating campaign:', error);
      res.status(500).json({ message: 'Failed to create campaign' });
    }
  });

  app.get('/api/campaigns/:id/milestones', isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const milestones = await storage.getCampaignMilestones(id);
      res.json(milestones);
    } catch (error) {
      console.error('Error fetching campaign milestones:', error);
      res.status(500).json({ message: 'Failed to fetch campaign milestones' });
    }
  });

  app.post('/api/campaigns/:id/milestones', isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const milestoneData = { ...req.body, campaignId: id };
      const milestone = await storage.createCampaignMilestone(milestoneData);
      res.json(milestone);
    } catch (error) {
      console.error('Error creating campaign milestone:', error);
      res.status(500).json({ message: 'Failed to create campaign milestone' });
    }
  });

  // Workshop & Webinar API
  app.get('/api/workshops', isAuthenticated, async (req, res) => {
    try {
      const category = req.query.category as string;
      const workshops = await storage.getWorkshops(category);
      res.json(workshops);
    } catch (error) {
      console.error('Error fetching workshops:', error);
      res.status(500).json({ message: 'Failed to fetch workshops' });
    }
  });

  app.post('/api/workshops', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const workshopData = { ...req.body, createdBy: userId };
      const workshop = await storage.createWorkshop(workshopData);
      res.json(workshop);
    } catch (error) {
      console.error('Error creating workshop:', error);
      res.status(500).json({ message: 'Failed to create workshop' });
    }
  });

  app.post('/api/workshops/:id/register', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      const registration = await storage.registerForWorkshop(id, userId);
      res.json(registration);
    } catch (error) {
      console.error('Error registering for workshop:', error);
      res.status(500).json({ message: 'Failed to register for workshop' });
    }
  });

  // Internal Messaging API
  app.get('/api/messages', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const messages = await storage.getMessages(userId);
      res.json(messages);
    } catch (error) {
      console.error('Error fetching messages:', error);
      res.status(500).json({ message: 'Failed to fetch messages' });
    }
  });

  app.post('/api/messages', isAuthenticated, async (req: any, res) => {
    try {
      const senderId = req.user.claims.sub;
      const messageData = { ...req.body, senderId };
      const message = await storage.createMessage(messageData);
      res.json(message);
    } catch (error) {
      console.error('Error creating message:', error);
      res.status(500).json({ message: 'Failed to create message' });
    }
  });

  // Post Templates API
  app.get('/api/post-templates', isAuthenticated, async (req, res) => {
    try {
      const platform = req.query.platform as string;
      const templates = await storage.getPostTemplates(platform);
      res.json(templates);
    } catch (error) {
      console.error('Error fetching post templates:', error);
      res.status(500).json({ message: 'Failed to fetch post templates' });
    }
  });

  app.post('/api/post-templates', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const templateData = { ...req.body, createdBy: userId };
      const template = await storage.createPostTemplate(templateData);
      res.json(template);
    } catch (error) {
      console.error('Error creating post template:', error);
      res.status(500).json({ message: 'Failed to create post template' });
    }
  });

  // Gamification & Achievements API
  app.get('/api/achievements', isAuthenticated, async (req, res) => {
    try {
      const achievements = await storage.getAchievements();
      res.json(achievements);
    } catch (error) {
      console.error('Error fetching achievements:', error);
      res.status(500).json({ message: 'Failed to fetch achievements' });
    }
  });

  app.get('/api/user-achievements', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const userAchievements = await storage.getUserAchievements(userId);
      res.json(userAchievements);
    } catch (error) {
      console.error('Error fetching user achievements:', error);
      res.status(500).json({ message: 'Failed to fetch user achievements' });
    }
  });

  // Social Media Analytics API
  app.get('/api/social-media/:id/analytics', isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const analytics = await storage.getSocialMediaAnalytics(id);
      res.json(analytics);
    } catch (error) {
      console.error('Error fetching social media analytics:', error);
      res.status(500).json({ message: 'Failed to fetch social media analytics' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

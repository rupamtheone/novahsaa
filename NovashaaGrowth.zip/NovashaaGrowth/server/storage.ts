import {
  users,
  projects,
  tasks,
  taskAttachments,
  socialMediaContent,
  brandAssets,
  comments,
  campaigns,
  campaignMilestones,
  learningResources,
  freelancers,
  freelancerReviews,
  workshops,
  workshopRegistrations,
  messages,
  aiSuggestions,
  socialMediaAnalytics,
  achievements,
  userAchievements,
  postTemplates,
  type User,
  type UpsertUser,
  type Project,
  type Task,
  type TaskAttachment,
  type SocialMediaContent,
  type BrandAsset,
  type Comment,
  type Campaign,
  type CampaignMilestone,
  type LearningResource,
  type Freelancer,
  type FreelancerReview,
  type Workshop,
  type WorkshopRegistration,
  type Message,
  type AiSuggestion,
  type SocialMediaAnalytics,
  type Achievement,
  type UserAchievement,
  type PostTemplate,
} from "../shared/schema";
import { db } from "./db";
import { eq, and, desc, asc } from "drizzle-orm";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Project operations
  getProjects(): Promise<Project[]>;
  getProjectById(id: string): Promise<Project | undefined>;
  createProject(project: Omit<Project, 'id' | 'createdAt' | 'updatedAt'>): Promise<Project>;
  updateProject(id: string, project: Partial<Project>): Promise<Project>;
  
  // Task operations
  getTasks(projectId?: string, assignedTo?: string): Promise<Task[]>;
  getTaskById(id: string): Promise<Task | undefined>;
  createTask(task: Omit<Task, 'id' | 'createdAt' | 'updatedAt'>): Promise<Task>;
  updateTask(id: string, task: Partial<Task>): Promise<Task>;
  deleteTask(id: string): Promise<void>;
  
  // Task attachment operations
  createTaskAttachment(attachment: Omit<TaskAttachment, 'id' | 'createdAt'>): Promise<TaskAttachment>;
  getTaskAttachments(taskId: string): Promise<TaskAttachment[]>;
  deleteTaskAttachment(id: string): Promise<void>;
  
  // Social media content operations
  getSocialMediaContent(projectId?: string): Promise<SocialMediaContent[]>;
  createSocialMediaContent(content: Omit<SocialMediaContent, 'id' | 'createdAt' | 'updatedAt'>): Promise<SocialMediaContent>;
  updateSocialMediaContent(id: string, content: Partial<SocialMediaContent>): Promise<SocialMediaContent>;
  
  // Brand assets operations
  getBrandAssets(projectId?: string): Promise<BrandAsset[]>;
  createBrandAsset(asset: Omit<BrandAsset, 'id' | 'createdAt' | 'updatedAt'>): Promise<BrandAsset>;
  updateBrandAsset(id: string, asset: Partial<BrandAsset>): Promise<BrandAsset>;
  deleteBrandAsset(id: string): Promise<void>;
  
  // Comments operations
  getComments(entityType: string, entityId: string): Promise<Comment[]>;
  createComment(comment: Omit<Comment, 'id' | 'createdAt' | 'updatedAt'>): Promise<Comment>;
  
  // Campaign operations
  getCampaigns(projectId?: string): Promise<Campaign[]>;
  createCampaign(campaign: Omit<Campaign, 'id' | 'createdAt' | 'updatedAt'>): Promise<Campaign>;
  updateCampaign(id: string, updates: Partial<Campaign>): Promise<Campaign>;
  deleteCampaign(id: string): Promise<void>;
  getCampaignMilestones(campaignId: string): Promise<CampaignMilestone[]>;
  createCampaignMilestone(milestone: Omit<CampaignMilestone, 'id' | 'createdAt' | 'updatedAt'>): Promise<CampaignMilestone>;
  updateCampaignMilestone(id: string, updates: Partial<CampaignMilestone>): Promise<CampaignMilestone>;

  // Learning resource operations
  getLearningResources(category?: string): Promise<LearningResource[]>;
  createLearningResource(resource: Omit<LearningResource, 'id' | 'createdAt' | 'updatedAt'>): Promise<LearningResource>;
  updateLearningResource(id: string, updates: Partial<LearningResource>): Promise<LearningResource>;
  deleteLearningResource(id: string): Promise<void>;

  // Freelancer operations
  getFreelancers(skills?: string[]): Promise<Freelancer[]>;
  createFreelancer(freelancer: Omit<Freelancer, 'id' | 'createdAt' | 'updatedAt'>): Promise<Freelancer>;
  updateFreelancer(id: string, updates: Partial<Freelancer>): Promise<Freelancer>;
  getFreelancerReviews(freelancerId: string): Promise<FreelancerReview[]>;
  createFreelancerReview(review: Omit<FreelancerReview, 'id' | 'createdAt'>): Promise<FreelancerReview>;
  assignTaskToFreelancer(taskId: string, freelancerId: string): Promise<Task>;

  // Workshop operations
  getWorkshops(category?: string): Promise<Workshop[]>;
  createWorkshop(workshop: Omit<Workshop, 'id' | 'createdAt' | 'updatedAt'>): Promise<Workshop>;
  updateWorkshop(id: string, updates: Partial<Workshop>): Promise<Workshop>;
  deleteWorkshop(id: string): Promise<void>;
  registerForWorkshop(workshopId: string, userId: string): Promise<WorkshopRegistration>;
  getWorkshopRegistrations(workshopId: string): Promise<WorkshopRegistration[]>;

  // Message operations
  getMessages(userId: string): Promise<Message[]>;
  createMessage(message: Omit<Message, 'id' | 'createdAt'>): Promise<Message>;
  markMessageAsRead(id: string): Promise<void>;

  // AI suggestions operations
  getAiSuggestions(userId: string, type?: string): Promise<AiSuggestion[]>;
  createAiSuggestion(suggestion: Omit<AiSuggestion, 'id' | 'createdAt'>): Promise<AiSuggestion>;
  updateAiSuggestion(id: string, updates: Partial<AiSuggestion>): Promise<AiSuggestion>;

  // Social media analytics operations
  getSocialMediaAnalytics(contentId: string): Promise<SocialMediaAnalytics[]>;
  createSocialMediaAnalytics(analytics: Omit<SocialMediaAnalytics, 'id' | 'recordedAt'>): Promise<SocialMediaAnalytics>;

  // Achievement operations
  getAchievements(): Promise<Achievement[]>;
  getUserAchievements(userId: string): Promise<UserAchievement[]>;
  updateUserProgress(userId: string, achievementId: string, progress: number): Promise<UserAchievement>;
  completeAchievement(userId: string, achievementId: string): Promise<UserAchievement>;

  // Post template operations
  getPostTemplates(platform?: string): Promise<PostTemplate[]>;
  createPostTemplate(template: Omit<PostTemplate, 'id' | 'createdAt' | 'updatedAt'>): Promise<PostTemplate>;
  updatePostTemplate(id: string, updates: Partial<PostTemplate>): Promise<PostTemplate>;
  deletePostTemplate(id: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // User operations (required for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Project operations
  async getProjects(): Promise<Project[]> {
    return await db.select().from(projects).orderBy(desc(projects.createdAt));
  }

  async getProjectById(id: string): Promise<Project | undefined> {
    const [project] = await db.select().from(projects).where(eq(projects.id, id));
    return project;
  }

  async createProject(projectData: Omit<Project, 'id' | 'createdAt' | 'updatedAt'>): Promise<Project> {
    const [project] = await db.insert(projects).values(projectData).returning();
    return project;
  }

  async updateProject(id: string, projectData: Partial<Project>): Promise<Project> {
    const [project] = await db
      .update(projects)
      .set({ ...projectData, updatedAt: new Date() })
      .where(eq(projects.id, id))
      .returning();
    return project;
  }

  // Task operations
  async getTasks(projectId?: string, assignedTo?: string): Promise<Task[]> {
    let query = db.select().from(tasks);
    
    const conditions = [];
    if (projectId) conditions.push(eq(tasks.projectId, projectId));
    if (assignedTo) conditions.push(eq(tasks.assignedTo, assignedTo));
    
    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }
    
    return await query.orderBy(desc(tasks.createdAt));
  }

  async getTaskById(id: string): Promise<Task | undefined> {
    const [task] = await db.select().from(tasks).where(eq(tasks.id, id));
    return task;
  }

  async createTask(taskData: Omit<Task, 'id' | 'createdAt' | 'updatedAt'>): Promise<Task> {
    const [task] = await db.insert(tasks).values(taskData).returning();
    return task;
  }

  async updateTask(id: string, taskData: Partial<Task>): Promise<Task> {
    const [task] = await db
      .update(tasks)
      .set({ ...taskData, updatedAt: new Date() })
      .where(eq(tasks.id, id))
      .returning();
    return task;
  }

  async deleteTask(id: string): Promise<void> {
    await db.delete(tasks).where(eq(tasks.id, id));
  }

  // Task attachment operations
  async createTaskAttachment(attachmentData: Omit<TaskAttachment, 'id' | 'createdAt'>): Promise<TaskAttachment> {
    const [attachment] = await db.insert(taskAttachments).values(attachmentData).returning();
    return attachment;
  }

  async getTaskAttachments(taskId: string): Promise<TaskAttachment[]> {
    return await db.select().from(taskAttachments).where(eq(taskAttachments.taskId, taskId));
  }

  async deleteTaskAttachment(id: string): Promise<void> {
    await db.delete(taskAttachments).where(eq(taskAttachments.id, id));
  }

  // Social media content operations
  async getSocialMediaContent(projectId?: string): Promise<SocialMediaContent[]> {
    let query = db.select().from(socialMediaContent);
    
    if (projectId) {
      query = query.where(eq(socialMediaContent.projectId, projectId));
    }
    
    return await query.orderBy(desc(socialMediaContent.createdAt));
  }

  async createSocialMediaContent(contentData: Omit<SocialMediaContent, 'id' | 'createdAt' | 'updatedAt'>): Promise<SocialMediaContent> {
    const [content] = await db.insert(socialMediaContent).values(contentData).returning();
    return content;
  }

  async updateSocialMediaContent(id: string, contentData: Partial<SocialMediaContent>): Promise<SocialMediaContent> {
    const [content] = await db
      .update(socialMediaContent)
      .set({ ...contentData, updatedAt: new Date() })
      .where(eq(socialMediaContent.id, id))
      .returning();
    return content;
  }

  // Brand assets operations
  async getBrandAssets(projectId?: string): Promise<BrandAsset[]> {
    let query = db.select().from(brandAssets);
    
    if (projectId) {
      query = query.where(eq(brandAssets.projectId, projectId));
    }
    
    return await query.orderBy(desc(brandAssets.createdAt));
  }

  async createBrandAsset(assetData: Omit<BrandAsset, 'id' | 'createdAt' | 'updatedAt'>): Promise<BrandAsset> {
    const [asset] = await db.insert(brandAssets).values(assetData).returning();
    return asset;
  }

  async updateBrandAsset(id: string, assetData: Partial<BrandAsset>): Promise<BrandAsset> {
    const [asset] = await db
      .update(brandAssets)
      .set({ ...assetData, updatedAt: new Date() })
      .where(eq(brandAssets.id, id))
      .returning();
    return asset;
  }

  async deleteBrandAsset(id: string): Promise<void> {
    await db.delete(brandAssets).where(eq(brandAssets.id, id));
  }

  // Comments operations
  async getComments(entityType: string, entityId: string): Promise<Comment[]> {
    return await db
      .select()
      .from(comments)
      .where(and(eq(comments.entityType, entityType), eq(comments.entityId, entityId)))
      .orderBy(asc(comments.createdAt));
  }

  async createComment(commentData: Omit<Comment, 'id' | 'createdAt' | 'updatedAt'>): Promise<Comment> {
    const [comment] = await db.insert(comments).values(commentData).returning();
    return comment;
  }

  // Campaign operations
  async getCampaigns(projectId?: string): Promise<Campaign[]> {
    let query = db.select().from(campaigns);
    if (projectId) {
      query = query.where(eq(campaigns.projectId, projectId));
    }
    return await query.orderBy(desc(campaigns.createdAt));
  }

  async createCampaign(campaignData: Omit<Campaign, 'id' | 'createdAt' | 'updatedAt'>): Promise<Campaign> {
    const [campaign] = await db.insert(campaigns).values(campaignData).returning();
    return campaign;
  }

  async updateCampaign(id: string, campaignData: Partial<Campaign>): Promise<Campaign> {
    const [campaign] = await db
      .update(campaigns)
      .set({ ...campaignData, updatedAt: new Date() })
      .where(eq(campaigns.id, id))
      .returning();
    return campaign;
  }

  async deleteCampaign(id: string): Promise<void> {
    await db.delete(campaigns).where(eq(campaigns.id, id));
  }

  async getCampaignMilestones(campaignId: string): Promise<CampaignMilestone[]> {
    return await db
      .select()
      .from(campaignMilestones)
      .where(eq(campaignMilestones.campaignId, campaignId))
      .orderBy(asc(campaignMilestones.targetDate));
  }

  async createCampaignMilestone(milestoneData: Omit<CampaignMilestone, 'id' | 'createdAt' | 'updatedAt'>): Promise<CampaignMilestone> {
    const [milestone] = await db.insert(campaignMilestones).values(milestoneData).returning();
    return milestone;
  }

  async updateCampaignMilestone(id: string, milestoneData: Partial<CampaignMilestone>): Promise<CampaignMilestone> {
    const [milestone] = await db
      .update(campaignMilestones)
      .set({ ...milestoneData, updatedAt: new Date() })
      .where(eq(campaignMilestones.id, id))
      .returning();
    return milestone;
  }

  // Learning resource operations
  async getLearningResources(category?: string): Promise<LearningResource[]> {
    let query = db.select().from(learningResources).where(eq(learningResources.isPublished, true));
    if (category) {
      query = query.where(and(eq(learningResources.isPublished, true), eq(learningResources.category, category)));
    }
    return await query.orderBy(desc(learningResources.createdAt));
  }

  async createLearningResource(resourceData: Omit<LearningResource, 'id' | 'createdAt' | 'updatedAt'>): Promise<LearningResource> {
    const [resource] = await db.insert(learningResources).values(resourceData).returning();
    return resource;
  }

  async updateLearningResource(id: string, resourceData: Partial<LearningResource>): Promise<LearningResource> {
    const [resource] = await db
      .update(learningResources)
      .set({ ...resourceData, updatedAt: new Date() })
      .where(eq(learningResources.id, id))
      .returning();
    return resource;
  }

  async deleteLearningResource(id: string): Promise<void> {
    await db.delete(learningResources).where(eq(learningResources.id, id));
  }

  // Freelancer operations
  async getFreelancers(skills?: string[]): Promise<Freelancer[]> {
    // For now, simple query - can be enhanced with skill filtering
    return await db.select().from(freelancers).orderBy(desc(freelancers.rating));
  }

  async createFreelancer(freelancerData: Omit<Freelancer, 'id' | 'createdAt' | 'updatedAt'>): Promise<Freelancer> {
    const [freelancer] = await db.insert(freelancers).values(freelancerData).returning();
    return freelancer;
  }

  async updateFreelancer(id: string, freelancerData: Partial<Freelancer>): Promise<Freelancer> {
    const [freelancer] = await db
      .update(freelancers)
      .set({ ...freelancerData, updatedAt: new Date() })
      .where(eq(freelancers.id, id))
      .returning();
    return freelancer;
  }

  async getFreelancerReviews(freelancerId: string): Promise<FreelancerReview[]> {
    return await db
      .select()
      .from(freelancerReviews)
      .where(eq(freelancerReviews.freelancerId, freelancerId))
      .orderBy(desc(freelancerReviews.createdAt));
  }

  async createFreelancerReview(reviewData: Omit<FreelancerReview, 'id' | 'createdAt'>): Promise<FreelancerReview> {
    const [review] = await db.insert(freelancerReviews).values(reviewData).returning();
    return review;
  }

  async assignTaskToFreelancer(taskId: string, freelancerId: string): Promise<Task> {
    const [task] = await db
      .update(tasks)
      .set({ assignedTo: freelancerId, updatedAt: new Date() })
      .where(eq(tasks.id, taskId))
      .returning();
    return task;
  }

  // Workshop operations
  async getWorkshops(category?: string): Promise<Workshop[]> {
    let query = db.select().from(workshops);
    if (category) {
      query = query.where(eq(workshops.category, category));
    }
    return await query.orderBy(asc(workshops.startDate));
  }

  async createWorkshop(workshopData: Omit<Workshop, 'id' | 'createdAt' | 'updatedAt'>): Promise<Workshop> {
    const [workshop] = await db.insert(workshops).values(workshopData).returning();
    return workshop;
  }

  async updateWorkshop(id: string, workshopData: Partial<Workshop>): Promise<Workshop> {
    const [workshop] = await db
      .update(workshops)
      .set({ ...workshopData, updatedAt: new Date() })
      .where(eq(workshops.id, id))
      .returning();
    return workshop;
  }

  async deleteWorkshop(id: string): Promise<void> {
    await db.delete(workshops).where(eq(workshops.id, id));
  }

  async registerForWorkshop(workshopId: string, userId: string): Promise<WorkshopRegistration> {
    const [registration] = await db
      .insert(workshopRegistrations)
      .values({ workshopId, userId })
      .returning();
    return registration;
  }

  async getWorkshopRegistrations(workshopId: string): Promise<WorkshopRegistration[]> {
    return await db
      .select()
      .from(workshopRegistrations)
      .where(eq(workshopRegistrations.workshopId, workshopId));
  }

  // Message operations
  async getMessages(userId: string): Promise<Message[]> {
    return await db
      .select()
      .from(messages)
      .where(eq(messages.receiverId, userId))
      .orderBy(desc(messages.createdAt));
  }

  async createMessage(messageData: Omit<Message, 'id' | 'createdAt'>): Promise<Message> {
    const [message] = await db.insert(messages).values(messageData).returning();
    return message;
  }

  async markMessageAsRead(id: string): Promise<void> {
    await db.update(messages).set({ isRead: true }).where(eq(messages.id, id));
  }

  // AI suggestions operations
  async getAiSuggestions(userId: string, type?: string): Promise<AiSuggestion[]> {
    let query = db.select().from(aiSuggestions).where(eq(aiSuggestions.userId, userId));
    if (type) {
      query = query.where(and(eq(aiSuggestions.userId, userId), eq(aiSuggestions.type, type)));
    }
    return await query.orderBy(desc(aiSuggestions.createdAt));
  }

  async createAiSuggestion(suggestionData: Omit<AiSuggestion, 'id' | 'createdAt'>): Promise<AiSuggestion> {
    const [suggestion] = await db.insert(aiSuggestions).values(suggestionData).returning();
    return suggestion;
  }

  async updateAiSuggestion(id: string, suggestionData: Partial<AiSuggestion>): Promise<AiSuggestion> {
    const [suggestion] = await db
      .update(aiSuggestions)
      .set(suggestionData)
      .where(eq(aiSuggestions.id, id))
      .returning();
    return suggestion;
  }

  // Social media analytics operations
  async getSocialMediaAnalytics(contentId: string): Promise<SocialMediaAnalytics[]> {
    return await db
      .select()
      .from(socialMediaAnalytics)
      .where(eq(socialMediaAnalytics.contentId, contentId))
      .orderBy(desc(socialMediaAnalytics.recordedAt));
  }

  async createSocialMediaAnalytics(analyticsData: Omit<SocialMediaAnalytics, 'id' | 'recordedAt'>): Promise<SocialMediaAnalytics> {
    const [analytics] = await db.insert(socialMediaAnalytics).values(analyticsData).returning();
    return analytics;
  }

  // Achievement operations
  async getAchievements(): Promise<Achievement[]> {
    return await db.select().from(achievements).where(eq(achievements.isActive, true));
  }

  async getUserAchievements(userId: string): Promise<UserAchievement[]> {
    return await db
      .select()
      .from(userAchievements)
      .where(eq(userAchievements.userId, userId));
  }

  async updateUserProgress(userId: string, achievementId: string, progress: number): Promise<UserAchievement> {
    const [userAchievement] = await db
      .insert(userAchievements)
      .values({ userId, achievementId, progress })
      .onConflictDoUpdate({
        target: [userAchievements.userId, userAchievements.achievementId],
        set: { progress },
      })
      .returning();
    return userAchievement;
  }

  async completeAchievement(userId: string, achievementId: string): Promise<UserAchievement> {
    const [userAchievement] = await db
      .update(userAchievements)
      .set({ isCompleted: true, completedAt: new Date() })
      .where(and(eq(userAchievements.userId, userId), eq(userAchievements.achievementId, achievementId)))
      .returning();
    return userAchievement;
  }

  // Post template operations
  async getPostTemplates(platform?: string): Promise<PostTemplate[]> {
    let query = db.select().from(postTemplates);
    if (platform) {
      query = query.where(eq(postTemplates.platform, platform));
    }
    return await query.orderBy(desc(postTemplates.usageCount));
  }

  async createPostTemplate(templateData: Omit<PostTemplate, 'id' | 'createdAt' | 'updatedAt'>): Promise<PostTemplate> {
    const [template] = await db.insert(postTemplates).values(templateData).returning();
    return template;
  }

  async updatePostTemplate(id: string, templateData: Partial<PostTemplate>): Promise<PostTemplate> {
    const [template] = await db
      .update(postTemplates)
      .set({ ...templateData, updatedAt: new Date() })
      .where(eq(postTemplates.id, id))
      .returning();
    return template;
  }

  async deletePostTemplate(id: string): Promise<void> {
    await db.delete(postTemplates).where(eq(postTemplates.id, id));
  }
}

export const storage = new DatabaseStorage();

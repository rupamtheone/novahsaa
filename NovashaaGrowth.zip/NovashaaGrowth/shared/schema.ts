import { sql } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  text,
  integer,
  boolean,
  uuid,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";

// Session storage table (required for Replit Auth)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table (required for Replit Auth)
export const users = pgTable("users", {
  id: varchar("id").primaryKey(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  role: varchar("role").default("staff"), // admin, staff, client
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Projects table
export const projects = pgTable("projects", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  clientId: varchar("client_id").references(() => users.id),
  status: varchar("status").default("active"), // active, completed, paused
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Tasks table
export const tasks = pgTable("tasks", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  status: varchar("status").default("pending"), // pending, in_progress, completed
  priority: varchar("priority").default("medium"), // low, medium, high, urgent
  assignedTo: varchar("assigned_to").references(() => users.id),
  projectId: uuid("project_id").references(() => projects.id),
  dueDate: timestamp("due_date"),
  createdBy: varchar("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Task attachments table
export const taskAttachments = pgTable("task_attachments", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  taskId: uuid("task_id").references(() => tasks.id),
  fileName: varchar("file_name", { length: 255 }).notNull(),
  filePath: varchar("file_path", { length: 500 }).notNull(),
  fileSize: integer("file_size"),
  mimeType: varchar("mime_type"),
  uploadedBy: varchar("uploaded_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

// Social media content table
export const socialMediaContent = pgTable("social_media_content", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  title: varchar("title", { length: 255 }).notNull(),
  content: text("content"),
  platform: varchar("platform"), // instagram, facebook, linkedin, youtube
  scheduledDate: timestamp("scheduled_date"),
  status: varchar("status").default("draft"), // draft, scheduled, published
  projectId: uuid("project_id").references(() => projects.id),
  createdBy: varchar("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Brand assets table
export const brandAssets = pgTable("brand_assets", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  filePath: varchar("file_path", { length: 500 }).notNull(),
  fileSize: integer("file_size"),
  mimeType: varchar("mime_type"),
  category: varchar("category"), // logo, image, video, document
  projectId: uuid("project_id").references(() => projects.id),
  isApproved: boolean("is_approved").default(false),
  uploadedBy: varchar("uploaded_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Comments table for tasks and assets
export const comments = pgTable("comments", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  content: text("content").notNull(),
  entityType: varchar("entity_type").notNull(), // task, asset
  entityId: uuid("entity_id").notNull(),
  authorId: varchar("author_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Campaigns table for advanced campaign management
export const campaigns = pgTable("campaigns", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  projectId: uuid("project_id").references(() => projects.id),
  status: varchar("status").default("active"), // active, completed, paused
  startDate: timestamp("start_date"),
  endDate: timestamp("end_date"),
  budget: integer("budget"),
  spent: integer("spent").default(0),
  roi: varchar("roi"),
  createdBy: varchar("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Campaign milestones table
export const campaignMilestones = pgTable("campaign_milestones", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  campaignId: uuid("campaign_id").references(() => campaigns.id),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  targetDate: timestamp("target_date"),
  completedDate: timestamp("completed_date"),
  status: varchar("status").default("pending"), // pending, in_progress, completed
  progress: integer("progress").default(0), // 0-100
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Learning resources table
export const learningResources = pgTable("learning_resources", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  content: text("content"),
  category: varchar("category"), // marketing, social-media, branding, finance, etc
  type: varchar("type"), // tutorial, guide, video, article
  difficulty: varchar("difficulty").default("beginner"), // beginner, intermediate, advanced
  duration: integer("duration"), // in minutes
  tags: text("tags"), // JSON array of tags
  imageUrl: varchar("image_url"),
  videoUrl: varchar("video_url"),
  isPublished: boolean("is_published").default(false),
  authorId: varchar("author_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Freelancers/marketplace table
export const freelancers = pgTable("freelancers", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id),
  title: varchar("title", { length: 255 }).notNull(),
  bio: text("bio"),
  skills: text("skills"), // JSON array
  hourlyRate: integer("hourly_rate"),
  availability: varchar("availability").default("available"), // available, busy, unavailable
  portfolioUrl: varchar("portfolio_url"),
  experience: integer("experience"), // years
  rating: integer("rating").default(0), // 0-5 stars * 100 (e.g., 450 = 4.5 stars)
  totalReviews: integer("total_reviews").default(0),
  completedProjects: integer("completed_projects").default(0),
  isVerified: boolean("is_verified").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Reviews for freelancers
export const freelancerReviews = pgTable("freelancer_reviews", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  freelancerId: uuid("freelancer_id").references(() => freelancers.id),
  reviewerId: varchar("reviewer_id").references(() => users.id),
  taskId: uuid("task_id").references(() => tasks.id),
  rating: integer("rating").notNull(), // 1-5
  review: text("review"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Workshops and webinars
export const workshops = pgTable("workshops", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  category: varchar("category"),
  instructor: varchar("instructor"),
  startDate: timestamp("start_date"),
  endDate: timestamp("end_date"),
  duration: integer("duration"), // in minutes
  maxParticipants: integer("max_participants"),
  currentParticipants: integer("current_participants").default(0),
  price: integer("price").default(0),
  meetingUrl: varchar("meeting_url"),
  materials: text("materials"), // JSON array of resources
  status: varchar("status").default("scheduled"), // scheduled, ongoing, completed, cancelled
  createdBy: varchar("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Workshop registrations
export const workshopRegistrations = pgTable("workshop_registrations", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  workshopId: uuid("workshop_id").references(() => workshops.id),
  userId: varchar("user_id").references(() => users.id),
  status: varchar("status").default("registered"), // registered, attended, no-show
  paymentStatus: varchar("payment_status").default("pending"), // pending, paid, refunded
  registeredAt: timestamp("registered_at").defaultNow(),
});

// Internal messaging system
export const messages = pgTable("messages", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  senderId: varchar("sender_id").references(() => users.id),
  receiverId: varchar("receiver_id").references(() => users.id),
  subject: varchar("subject", { length: 255 }),
  content: text("content").notNull(),
  isRead: boolean("is_read").default(false),
  entityType: varchar("entity_type"), // task, project, general
  entityId: uuid("entity_id"),
  attachments: text("attachments"), // JSON array of file paths
  createdAt: timestamp("created_at").defaultNow(),
});

// AI suggestions and generated content
export const aiSuggestions = pgTable("ai_suggestions", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  type: varchar("type").notNull(), // caption, hashtag, content, strategy
  prompt: text("prompt"),
  suggestion: text("suggestion").notNull(),
  platform: varchar("platform"), // instagram, facebook, linkedin, etc
  userId: varchar("user_id").references(() => users.id),
  projectId: uuid("project_id").references(() => projects.id),
  isUsed: boolean("is_used").default(false),
  rating: integer("rating"), // user rating of suggestion (1-5)
  createdAt: timestamp("created_at").defaultNow(),
});

// Social media analytics
export const socialMediaAnalytics = pgTable("social_media_analytics", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  contentId: uuid("content_id").references(() => socialMediaContent.id),
  platform: varchar("platform").notNull(),
  reach: integer("reach").default(0),
  impressions: integer("impressions").default(0),
  engagement: integer("engagement").default(0),
  likes: integer("likes").default(0),
  shares: integer("shares").default(0),
  comments: integer("comments").default(0),
  clicks: integer("clicks").default(0),
  saves: integer("saves").default(0),
  followersGained: integer("followers_gained").default(0),
  cost: integer("cost").default(0), // in cents
  roi: varchar("roi"),
  recordedAt: timestamp("recorded_at").defaultNow(),
});

// User achievements and gamification
export const achievements = pgTable("achievements", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  icon: varchar("icon"),
  category: varchar("category"), // tasks, projects, social-media, learning
  type: varchar("type").notNull(), // milestone, streak, completion
  requirement: text("requirement"), // JSON object with criteria
  points: integer("points").default(0),
  badge: varchar("badge"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// User achievement progress
export const userAchievements = pgTable("user_achievements", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id),
  achievementId: uuid("achievement_id").references(() => achievements.id),
  progress: integer("progress").default(0),
  isCompleted: boolean("is_completed").default(false),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Post templates
export const postTemplates = pgTable("post_templates", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  content: text("content").notNull(),
  platform: varchar("platform").notNull(),
  category: varchar("category"), // promotion, engagement, announcement, etc
  variables: text("variables"), // JSON array of placeholder variables
  imageTemplate: varchar("image_template"),
  isPublic: boolean("is_public").default(false),
  createdBy: varchar("created_by").references(() => users.id),
  usageCount: integer("usage_count").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  assignedTasks: many(tasks),
  createdTasks: many(tasks),
  projects: many(projects),
  uploads: many(taskAttachments),
  brandAssets: many(brandAssets),
  socialMediaContent: many(socialMediaContent),
  comments: many(comments),
}));

export const projectsRelations = relations(projects, ({ one, many }) => ({
  client: one(users, {
    fields: [projects.clientId],
    references: [users.id],
  }),
  tasks: many(tasks),
  socialMediaContent: many(socialMediaContent),
  brandAssets: many(brandAssets),
}));

export const tasksRelations = relations(tasks, ({ one, many }) => ({
  assignee: one(users, {
    fields: [tasks.assignedTo],
    references: [users.id],
  }),
  creator: one(users, {
    fields: [tasks.createdBy],
    references: [users.id],
  }),
  project: one(projects, {
    fields: [tasks.projectId],
    references: [projects.id],
  }),
  attachments: many(taskAttachments),
  comments: many(comments),
}));

export const taskAttachmentsRelations = relations(taskAttachments, ({ one }) => ({
  task: one(tasks, {
    fields: [taskAttachments.taskId],
    references: [tasks.id],
  }),
  uploader: one(users, {
    fields: [taskAttachments.uploadedBy],
    references: [users.id],
  }),
}));

export const socialMediaContentRelations = relations(socialMediaContent, ({ one }) => ({
  project: one(projects, {
    fields: [socialMediaContent.projectId],
    references: [projects.id],
  }),
  creator: one(users, {
    fields: [socialMediaContent.createdBy],
    references: [users.id],
  }),
}));

export const brandAssetsRelations = relations(brandAssets, ({ one, many }) => ({
  project: one(projects, {
    fields: [brandAssets.projectId],
    references: [projects.id],
  }),
  uploader: one(users, {
    fields: [brandAssets.uploadedBy],
    references: [users.id],
  }),
  comments: many(comments),
}));

export const commentsRelations = relations(comments, ({ one }) => ({
  author: one(users, {
    fields: [comments.authorId],
    references: [users.id],
  }),
}));

// Additional relations for new tables
export const campaignsRelations = relations(campaigns, ({ one, many }) => ({
  project: one(projects, {
    fields: [campaigns.projectId],
    references: [projects.id],
  }),
  creator: one(users, {
    fields: [campaigns.createdBy],
    references: [users.id],
  }),
  milestones: many(campaignMilestones),
}));

export const campaignMilestonesRelations = relations(campaignMilestones, ({ one }) => ({
  campaign: one(campaigns, {
    fields: [campaignMilestones.campaignId],
    references: [campaigns.id],
  }),
}));

export const learningResourcesRelations = relations(learningResources, ({ one }) => ({
  author: one(users, {
    fields: [learningResources.authorId],
    references: [users.id],
  }),
}));

export const freelancersRelations = relations(freelancers, ({ one, many }) => ({
  user: one(users, {
    fields: [freelancers.userId],
    references: [users.id],
  }),
  reviews: many(freelancerReviews),
}));

export const freelancerReviewsRelations = relations(freelancerReviews, ({ one }) => ({
  freelancer: one(freelancers, {
    fields: [freelancerReviews.freelancerId],
    references: [freelancers.id],
  }),
  reviewer: one(users, {
    fields: [freelancerReviews.reviewerId],
    references: [users.id],
  }),
  task: one(tasks, {
    fields: [freelancerReviews.taskId],
    references: [tasks.id],
  }),
}));

export const workshopsRelations = relations(workshops, ({ one, many }) => ({
  creator: one(users, {
    fields: [workshops.createdBy],
    references: [users.id],
  }),
  registrations: many(workshopRegistrations),
}));

export const workshopRegistrationsRelations = relations(workshopRegistrations, ({ one }) => ({
  workshop: one(workshops, {
    fields: [workshopRegistrations.workshopId],
    references: [workshops.id],
  }),
  user: one(users, {
    fields: [workshopRegistrations.userId],
    references: [users.id],
  }),
}));

export const messagesRelations = relations(messages, ({ one }) => ({
  sender: one(users, {
    fields: [messages.senderId],
    references: [users.id],
  }),
  receiver: one(users, {
    fields: [messages.receiverId],
    references: [users.id],
  }),
}));

export const aiSuggestionsRelations = relations(aiSuggestions, ({ one }) => ({
  user: one(users, {
    fields: [aiSuggestions.userId],
    references: [users.id],
  }),
  project: one(projects, {
    fields: [aiSuggestions.projectId],
    references: [projects.id],
  }),
}));

export const socialMediaAnalyticsRelations = relations(socialMediaAnalytics, ({ one }) => ({
  content: one(socialMediaContent, {
    fields: [socialMediaAnalytics.contentId],
    references: [socialMediaContent.id],
  }),
}));

export const userAchievementsRelations = relations(userAchievements, ({ one }) => ({
  user: one(users, {
    fields: [userAchievements.userId],
    references: [users.id],
  }),
  achievement: one(achievements, {
    fields: [userAchievements.achievementId],
    references: [achievements.id],
  }),
}));

export const postTemplatesRelations = relations(postTemplates, ({ one }) => ({
  creator: one(users, {
    fields: [postTemplates.createdBy],
    references: [users.id],
  }),
}));

export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type Project = typeof projects.$inferSelect;
export type Task = typeof tasks.$inferSelect;
export type TaskAttachment = typeof taskAttachments.$inferSelect;
export type SocialMediaContent = typeof socialMediaContent.$inferSelect;
export type BrandAsset = typeof brandAssets.$inferSelect;
export type Comment = typeof comments.$inferSelect;
export type Campaign = typeof campaigns.$inferSelect;
export type CampaignMilestone = typeof campaignMilestones.$inferSelect;
export type LearningResource = typeof learningResources.$inferSelect;
export type Freelancer = typeof freelancers.$inferSelect;
export type FreelancerReview = typeof freelancerReviews.$inferSelect;
export type Workshop = typeof workshops.$inferSelect;
export type WorkshopRegistration = typeof workshopRegistrations.$inferSelect;
export type Message = typeof messages.$inferSelect;
export type AiSuggestion = typeof aiSuggestions.$inferSelect;
export type SocialMediaAnalytics = typeof socialMediaAnalytics.$inferSelect;
export type Achievement = typeof achievements.$inferSelect;
export type UserAchievement = typeof userAchievements.$inferSelect;
export type PostTemplate = typeof postTemplates.$inferSelect;
